package com.freefire.tournament;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
