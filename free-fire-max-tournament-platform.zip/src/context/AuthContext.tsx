import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { UserProfile } from '../types';
import { checkAdminExists, signOutUser, MASTER_ADMIN_EMAIL } from '../services/authService';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  isBanned: boolean;
  loading: boolean;
  hasAdminAccount: boolean;
  refreshProfile: () => Promise<void>;
  checkAdminStatus: () => Promise<boolean>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  userProfile: null,
  isAdmin: false,
  isBanned: false,
  loading: true,
  hasAdminAccount: true,
  refreshProfile: async () => {},
  checkAdminStatus: async () => true,
  signOut: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [hasAdminAccount, setHasAdminAccount] = useState<boolean>(true);

  const checkAdminStatus = async (): Promise<boolean> => {
    setHasAdminAccount(true);
    return true;
  };

  const handleSignOut = async () => {
    try {
      await signOutUser();
      setCurrentUser(null);
      setUserProfile(null);
    } catch (err) {
      console.warn('Error during sign out:', err);
    }
  };

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);

      if (user) {
        // Listen to live user profile changes in firestore
        const docRef = doc(db, 'users', user.uid);
        unsubscribeProfile = onSnapshot(docRef, (docSnap) => {
          if (docSnap.exists()) {
            const profile = docSnap.data() as UserProfile;
            setUserProfile(profile);
          } else {
            setUserProfile(null);
          }
          setLoading(false);
        }, (error) => {
          console.warn('Profile snapshot notice:', error);
          setLoading(false);
        });
      } else {
        if (unsubscribeProfile) {
          unsubscribeProfile();
          unsubscribeProfile = null;
        }
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const refreshProfile = async () => {
    if (currentUser) {
      const docRef = doc(db, 'users', currentUser.uid);
      const docSnap = await (await import('firebase/firestore')).getDoc(docRef);
      if (docSnap.exists()) {
        setUserProfile(docSnap.data() as UserProfile);
      }
    }
  };

  // Strictly check that the authenticated user is the designated single Master Administrator
  const isMasterAdmin = Boolean(
    currentUser?.email && 
    currentUser.email.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase()
  );

  const isAdmin = isMasterAdmin;
  const isBanned = Boolean(userProfile && (userProfile.status === 'banned' || userProfile.isBanned));

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        isBanned,
        loading,
        hasAdminAccount,
        refreshProfile,
        checkAdminStatus,
        signOut: handleSignOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
