import React, { useState } from 'react';
import { Settings, Save, CheckCircle2, QrCode, Shield, Database, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const AdminSettingsView: React.FC = () => {
  const { userProfile } = useAuth();
  const [upiId, setUpiId] = useState('ffmax.tournaments@okaxis');
  const [upiName, setUpiName] = useState('FREE FIRE MAX ESPORTS ORG');
  const [supportPhone, setSupportPhone] = useState('+91 9876543210');
  const [rulesPreset, setRulesPreset] = useState(
    '1. Emulator strictly banned.\n2. Screen recording mandatory for top 3 survivors.\n3. Custom room credentials must not be shared outside registered team.\n4. Toxic behaviour results in instant DQ.'
  );
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div id="admin-settings-view" className="max-w-3xl space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
          <Settings className="w-6 h-6 text-orange-400" />
          Platform Configurations & Settings
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure official payment gateway parameters, player rules, and system behavior
        </p>
      </div>

      {saved && (
        <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Platform settings updated successfully!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Payment Configuration */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <QrCode className="w-4 h-4 text-emerald-400" />
            UPI Payment Receiver Configuration
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                Official UPI ID (VPA)
              </label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs font-mono text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                Merchant / Account Name
              </label>
              <input
                type="text"
                required
                value={upiName}
                onChange={(e) => setUpiName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Admin Support WhatsApp / Hotline
            </label>
            <input
              type="text"
              required
              value={supportPhone}
              onChange={(e) => setSupportPhone(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
            />
          </div>
        </div>

        {/* Standard Tournament Rules Preset */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-4 h-4 text-orange-400" />
            Standard Competitive Rules Template
          </h3>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Default Tournament Rules (Auto-inserted into new tournaments)
            </label>
            <textarea
              rows={4}
              value={rulesPreset}
              onChange={(e) => setRulesPreset(e.target.value)}
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none resize-none font-mono"
            />
          </div>
        </div>

        {/* Database & Cloud Architecture Stats */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            Cloud Database & Realtime Infrastructure
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Database</span>
              <span className="text-emerald-400 font-bold">Google Cloud Firestore</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Security Rules</span>
              <span className="text-emerald-400 font-bold">Deployed (RBAC Enabled)</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Concurrency</span>
              <span className="text-emerald-400 font-bold">Atomic Transactions</span>
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md shadow-orange-600/30 transition-all flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" /> Save Settings
        </button>
      </form>
    </div>
  );
};
