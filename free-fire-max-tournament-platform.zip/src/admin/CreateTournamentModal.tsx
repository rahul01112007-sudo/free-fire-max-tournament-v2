import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Sparkles, 
  Calendar, 
  Clock, 
  Users, 
  User, 
  DollarSign, 
  CheckCircle2, 
  AlertCircle,
  Gem,
  Plus,
  Trash2,
  Gift,
  Wand2,
  Layers,
  ChevronDown,
  RefreshCw,
  Edit3
} from 'lucide-react';
import { 
  Tournament, 
  TournamentFormat, 
  TournamentStatus, 
  TournamentEntryType,
  PrizeType,
  PrizePosition,
  FREE_FIRE_DIAMOND_PACKAGES,
  DiamondPackage,
  isDiamondPrizeType,
  formatPrizeAmount,
  calculateDeterministicPrizeDistribution,
  getTournamentPrizePositions,
  DEFAULT_DIAMOND_SOLO_PRIZES,
  DEFAULT_DIAMOND_SQUAD_PRIZES
} from '../types';
import { Modal } from '../components/Modal';
import { DiamondPackageSelector } from '../components/DiamondPackageSelector';
import { createTournamentWithMatches, updateTournamentDetails } from '../services/tournamentService';
import { useAuth } from '../context/AuthContext';

interface CreateTournamentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialFormat?: TournamentFormat;
  tournamentToEdit?: Tournament | null;
}

const AVAILABLE_ENTRY_TYPES: { 
  type: TournamentEntryType; 
  title: string; 
  subtitle: string; 
  icon: string; 
  badge: string; 
  badgeStyle: string; 
}[] = [
  {
    type: 'FREE_ADS',
    title: '1. FREE — WATCH 5 REWARDED ADS',
    subtitle: '100% Free entry. Players unlock ticket by watching 5 sponsored video ads.',
    icon: '🎬',
    badge: '100% FREE ENTRY (5 ADS)',
    badgeStyle: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
  },
  {
    type: 'PAID_IN_GAME',
    title: '2. PAID — IN-GAME REWARD',
    subtitle: 'Players pay configured tournament entry fee. Winner receives In-Game Diamond reward (NO cash prize).',
    icon: '💎',
    badge: 'PAID ENTRY • IN-GAME REWARD',
    badgeStyle: 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40'
  },
  {
    type: 'FREE_IN_GAME',
    title: '3. FREE — IN-GAME REWARD',
    subtitle: 'Direct free entry. Winner receives In-Game Free Fire Diamond reward.',
    icon: '🎁',
    badge: 'FREE ENTRY • IN-GAME REWARD',
    badgeStyle: 'bg-purple-950/80 text-purple-300 border-purple-500/40'
  }
];

const AVAILABLE_PRIZE_TYPES: { type: PrizeType; label: string; desc: string; icon: string }[] = [
  { type: 'FREE FIRE DIAMONDS', label: 'Free Fire Diamonds 💎', desc: 'Predefined in-game diamond packages fulfilled directly to winner Free Fire UID', icon: '💎' },
  { type: 'AMAZON GIFT CARD', label: 'Amazon Gift Card', desc: 'Instant 16-digit voucher code delivered directly to winner inbox', icon: '🛒' },
  { type: 'GOOGLE PLAY REDEEM CODE', label: 'Google Play Redeem Code', desc: 'Google Play store redeem code for Free Fire Diamonds or app purchases', icon: '🎮' },
  { type: 'FLIPKART VOUCHER', label: 'Flipkart Voucher', desc: 'E-commerce digital shopping voucher for winners', icon: '🛍️' },
  { type: 'OTHER GIFT CARD', label: 'Other Gift Card', desc: 'Brand or partner digital gift card voucher', icon: '🎁' },
  { type: 'CUSTOM SPONSOR PRIZE', label: 'Custom Sponsor Prize', desc: 'Custom partner merchandise or sponsored voucher', icon: '🏆' },
];

const PRESET_DIAMOND_VALUES = [210, 310, 520, 1060, 2180, 5600, 11500];
const PRESET_PRIZE_VALUES = [500, 1000, 2000, 3000, 5000, 7000, 8000, 10000, 15000, 20000];
const PRESET_ENTRY_FEES = [10, 20, 30, 50, 100, 150, 200];

export const CreateTournamentModal: React.FC<CreateTournamentModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialFormat = 'SOLO',
  tournamentToEdit = null,
}) => {
  const { userProfile } = useAuth();
  const isEditMode = Boolean(tournamentToEdit);

  const [format, setFormat] = useState<TournamentFormat>(tournamentToEdit?.format || initialFormat);
  const [entryType, setEntryType] = useState<TournamentEntryType>(
    tournamentToEdit?.entryType || 'FREE_ADS'
  );
  const [entryFee, setEntryFee] = useState<number>(
    tournamentToEdit?.entryFee || 50
  );
  const [status, setStatus] = useState<TournamentStatus>(tournamentToEdit?.status || 'REGISTRATION_OPEN');
  const [title, setTitle] = useState(
    tournamentToEdit?.title || (
      initialFormat === 'SOLO'
        ? 'FREE FIRE MAX — SOLO SURVIVOR CUP'
        : 'FREE FIRE MAX — SQUAD WARLORDS CUP'
    )
  );
  const [maxParticipants, setMaxParticipants] = useState<number>(
    tournamentToEdit?.maxParticipants || (initialFormat === 'SOLO' ? 528 : 108)
  );
  const [participantsPerMatch, setParticipantsPerMatch] = useState<number>(
    tournamentToEdit?.participantsPerMatch || (initialFormat === 'SOLO' ? 48 : 12)
  );
  const [advancingPerMatch, setAdvancingPerMatch] = useState<number>(
    tournamentToEdit?.advancingPerMatch || 3
  );
  const [adsRequired, setAdsRequired] = useState<number>(
    tournamentToEdit?.adsRequired !== undefined ? tournamentToEdit.adsRequired : 5
  );

  // Prize Pool & Deterministic Engine State
  const [prizeType, setPrizeType] = useState<PrizeType>(tournamentToEdit?.prizeType || 'FREE FIRE DIAMONDS');
  const [totalPrizeValue, setTotalPrizeValue] = useState<number>(() => {
    if (tournamentToEdit) {
      return Number(tournamentToEdit.totalPrizeValue) || Number(tournamentToEdit.prizePool) || 1890;
    }
    return entryType === 'PAID_IN_GAME' || entryType === 'FREE_IN_GAME' ? 1890 : 8000;
  });
  const [prizePositionCount, setPrizePositionCount] = useState<number>(() => {
    if (tournamentToEdit) {
      const positions = getTournamentPrizePositions(tournamentToEdit);
      return Math.max(1, Math.min(10, positions.length || 3));
    }
    return 3;
  });
  const [prizePositions, setPrizePositions] = useState<PrizePosition[]>(() => {
    if (tournamentToEdit) {
      return getTournamentPrizePositions(tournamentToEdit);
    }
    return [
      { rank: 1, position: 1, label: '1st Place (Champion)', amount: 1060, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_1060', diamondPackageLabel: '1060 Diamonds' },
      { rank: 2, position: 2, label: '2nd Place', amount: 520, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_520', diamondPackageLabel: '520 Diamonds' },
      { rank: 3, position: 3, label: '3rd Place', amount: 310, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_310', diamondPackageLabel: '310 Diamonds' },
    ];
  });

  const [activePackageSelectorIndex, setActivePackageSelectorIndex] = useState<number | null>(null);

  const [startDate, setStartDate] = useState(tournamentToEdit?.startDate || new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState(tournamentToEdit?.startTime || '19:00 IST');
  const [description, setDescription] = useState(
    tournamentToEdit?.description || 'Top qualifying survivors advance to the Grand Final for official in-game prizes.'
  );
  const [rules, setRules] = useState(
    tournamentToEdit?.rules || 'Mobile only. No emulators or modifications. Screen recording mandatory for prize validation. Fair play strictly monitored.'
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isDiamonds = isDiamondPrizeType(prizeType);
  const unitSymbol = isDiamonds ? '💎' : '₹';
  const unitName = isDiamonds ? 'Diamonds' : 'INR';

  // Derived Structure Calculations
  const calcQualifierCount = Math.max(1, Math.ceil(maxParticipants / (participantsPerMatch || 1)));
  const calcGrandFinalSlots = calcQualifierCount * (advancingPerMatch || 1);

  // Prize Math & Validation
  const currentPositionsSum = prizePositions.reduce((acc, p) => acc + (Number(p.amount) || 0), 0);
  const prizeDiff = totalPrizeValue - currentPositionsSum;
  const isPrizeBalanced = prizeDiff === 0;
  const hasZeroOrNegativePrizes = prizePositions.some((p) => Number(p.amount) <= 0);
  const isPrizeValid = totalPrizeValue > 0 && prizePositions.length > 0 && isPrizeBalanced && !hasZeroOrNegativePrizes;

  useEffect(() => {
    if (tournamentToEdit) {
      setFormat(tournamentToEdit.format);
      setEntryType(tournamentToEdit.entryType || (tournamentToEdit.entryFee && tournamentToEdit.entryFee > 0 ? 'PAID_IN_GAME' : 'FREE_ADS'));
      setEntryFee(tournamentToEdit.entryFee || 50);
      setStatus(tournamentToEdit.status || 'REGISTRATION_OPEN');
      setTitle(tournamentToEdit.title);
      setMaxParticipants(tournamentToEdit.maxParticipants);
      setParticipantsPerMatch(tournamentToEdit.participantsPerMatch || (tournamentToEdit.format === 'SOLO' ? 48 : 12));
      setAdvancingPerMatch(tournamentToEdit.advancingPerMatch || 3);
      setAdsRequired(tournamentToEdit.adsRequired !== undefined ? tournamentToEdit.adsRequired : 5);
      
      const pType = tournamentToEdit.prizeType || 'FREE FIRE DIAMONDS';
      setPrizeType(pType);
      
      const pos = getTournamentPrizePositions(tournamentToEdit);
      const total = Number(tournamentToEdit.totalPrizeValue) || Number(tournamentToEdit.prizePool) || pos.reduce((a, b) => a + b.amount, 0);
      setTotalPrizeValue(total);
      setPrizePositionCount(pos.length);
      setPrizePositions(pos);
      
      setStartDate(tournamentToEdit.startDate);
      setStartTime(tournamentToEdit.startTime);
      setDescription(tournamentToEdit.description);
      setRules(tournamentToEdit.rules);
      setError(null);
    } else if (isOpen) {
      applyFormatAndEntryDefaults((initialFormat || 'SOLO') as TournamentFormat, 'FREE_ADS');
    }
  }, [tournamentToEdit, isOpen, initialFormat]);

  const applyFormatAndEntryDefaults = (targetFormat: TournamentFormat, targetEntryType: TournamentEntryType) => {
    setFormat(targetFormat);
    setEntryType(targetEntryType);

    const isDiamondMode = targetEntryType === 'PAID_IN_GAME' || targetEntryType === 'FREE_IN_GAME';
    const targetPrizeType: PrizeType = isDiamondMode ? 'FREE FIRE DIAMONDS' : 'AMAZON GIFT CARD';
    const targetTotal = isDiamondMode ? 1890 : (targetFormat === 'SOLO' ? 7000 : 6200);
    const targetCount = 3;

    setPrizeType(targetPrizeType);
    setTotalPrizeValue(targetTotal);
    setPrizePositionCount(targetCount);

    if (isDiamondMode) {
      const defaultPositions: PrizePosition[] = [
        { rank: 1, position: 1, label: '1st Place (Champion)', amount: 1060, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_1060', diamondPackageLabel: '1060 Diamonds' },
        { rank: 2, position: 2, label: '2nd Place', amount: 520, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_520', diamondPackageLabel: '520 Diamonds' },
        { rank: 3, position: 3, label: '3rd Place', amount: 310, prizeType: 'FREE FIRE DIAMONDS', diamondPackageId: 'dia_310', diamondPackageLabel: '310 Diamonds' },
      ];
      setPrizePositions(defaultPositions);
    } else {
      setPrizePositions(calculateDeterministicPrizeDistribution(targetTotal, targetCount, targetPrizeType));
    }

    if (targetEntryType === 'FREE_ADS') {
      setAdsRequired(5);
      setEntryFee(0);
    } else if (targetEntryType === 'PAID_IN_GAME') {
      setAdsRequired(0);
      setEntryFee(50);
    } else {
      setAdsRequired(0);
      setEntryFee(0);
    }

    if (targetFormat === 'SOLO') {
      setTitle(
        targetEntryType === 'PAID_IN_GAME' 
          ? 'FREE FIRE MAX — SOLO DIAMOND CLASH (PAID ENTRY)' 
          : targetEntryType === 'FREE_IN_GAME'
          ? 'FREE FIRE MAX — SOLO FREE DIAMOND CUP'
          : 'FREE FIRE MAX — SOLO SURVIVOR CUP'
      );
      setMaxParticipants(528);
      setParticipantsPerMatch(48);
      setAdvancingPerMatch(3);
      setDescription(
        targetEntryType === 'PAID_IN_GAME'
          ? 'Paid entry solo tournament. Survivors battle for Free Fire In-Game Diamond rewards. Non-cash in-game reward.'
          : '11 Qualifier matches with 48 players each. Top survivors advance to Grand Final.'
      );
    } else {
      setTitle(
        targetEntryType === 'PAID_IN_GAME' 
          ? 'FREE FIRE MAX — SQUAD DIAMOND CLASH (PAID ENTRY)' 
          : targetEntryType === 'FREE_IN_GAME'
          ? 'FREE FIRE MAX — SQUAD FREE DIAMOND CUP'
          : 'FREE FIRE MAX — SQUAD WARLORDS CUP'
      );
      setMaxParticipants(108);
      setParticipantsPerMatch(12);
      setAdvancingPerMatch(3);
      setDescription(
        targetEntryType === 'PAID_IN_GAME'
          ? 'Paid entry squad tournament. Top teams battle for Free Fire In-Game Diamond rewards. Non-cash in-game reward.'
          : '9 Qualifier matches with 12 teams each. Top 3 advance to Semifinals and Grand Final.'
      );
    }
  };

  const handleEntryTypeSelect = (selectedType: TournamentEntryType) => {
    applyFormatAndEntryDefaults(format, selectedType);
  };

  const handleFormatChange = (newFormat: TournamentFormat) => {
    applyFormatAndEntryDefaults(newFormat, entryType);
  };

  const handlePrizeTypeChange = (newPrizeType: PrizeType) => {
    setPrizeType(newPrizeType);
    const isNowDiamonds = isDiamondPrizeType(newPrizeType);
    
    if (isNowDiamonds) {
      const newPositions = prizePositions.map((p, idx) => {
        let matchedPkg = FREE_FIRE_DIAMOND_PACKAGES.find(pkg => pkg.diamonds === p.amount);
        if (!matchedPkg) {
          matchedPkg = idx === 0 ? FREE_FIRE_DIAMOND_PACKAGES[5] : idx === 1 ? FREE_FIRE_DIAMOND_PACKAGES[3] : FREE_FIRE_DIAMOND_PACKAGES[2]; // 1060, 520, 310
        }
        return {
          ...p,
          prizeType: newPrizeType,
          amount: matchedPkg ? matchedPkg.diamonds : p.amount,
          diamondPackageId: matchedPkg?.id,
          diamondPackageLabel: matchedPkg?.label,
        };
      });
      setPrizePositions(newPositions);
      const total = newPositions.reduce((acc, p) => acc + p.amount, 0);
      setTotalPrizeValue(total);
    } else {
      const newPositions = prizePositions.map(p => ({
        ...p,
        prizeType: newPrizeType,
        diamondPackageId: undefined,
        diamondPackageLabel: undefined,
      }));
      setPrizePositions(newPositions);
    }
  };

  const handleAutoDistributePrizes = (targetTotal: number = totalPrizeValue, targetCount: number = prizePositionCount) => {
    if (isDiamondPrizeType(prizeType)) {
      const defaultSolo = [1060, 520, 310, 210, 100, 100, 100, 100, 100, 100];
      const newPositions: PrizePosition[] = [];
      for (let i = 0; i < targetCount; i++) {
        const diamonds = defaultSolo[i] || 100;
        const pkg = FREE_FIRE_DIAMOND_PACKAGES.find(p => p.diamonds === diamonds);
        const rank = i + 1;
        newPositions.push({
          rank,
          position: rank,
          label: rank === 1 ? '1st Place (Champion)' : rank === 2 ? '2nd Place' : rank === 3 ? '3rd Place' : `${rank}th Place`,
          amount: diamonds,
          prizeType,
          diamondPackageId: pkg?.id,
          diamondPackageLabel: pkg?.label || `${diamonds} Diamonds`,
        });
      }
      setPrizePositions(newPositions);
      setPrizePositionCount(newPositions.length);
      const sum = newPositions.reduce((a, b) => a + b.amount, 0);
      setTotalPrizeValue(sum);
    } else {
      const newPositions = calculateDeterministicPrizeDistribution(targetTotal, targetCount, prizeType);
      setPrizePositions(newPositions);
      setPrizePositionCount(newPositions.length);
    }
  };

  const handlePositionCountChange = (newCount: number) => {
    const clampedCount = Math.max(1, Math.min(10, newCount));
    setPrizePositionCount(clampedCount);
    
    if (isDiamondPrizeType(prizeType)) {
      const current = [...prizePositions];
      if (clampedCount > current.length) {
        for (let i = current.length; i < clampedCount; i++) {
          const rank = i + 1;
          const pkg = FREE_FIRE_DIAMOND_PACKAGES[0]; // 100 Diamonds
          current.push({
            rank,
            position: rank,
            label: `${rank}th Place`,
            amount: pkg.diamonds,
            prizeType,
            diamondPackageId: pkg.id,
            diamondPackageLabel: pkg.label,
          });
        }
      } else {
        current.splice(clampedCount);
      }
      setPrizePositions(current);
      setTotalPrizeValue(current.reduce((a, b) => a + b.amount, 0));
    } else {
      const newPositions = calculateDeterministicPrizeDistribution(totalPrizeValue, clampedCount, prizeType);
      setPrizePositions(newPositions);
    }
  };

  const handleTotalPrizeValueChange = (newVal: number) => {
    const val = Math.max(1, newVal);
    setTotalPrizeValue(val);
    if (!isDiamondPrizeType(prizeType)) {
      const newPositions = calculateDeterministicPrizeDistribution(val, prizePositionCount, prizeType);
      setPrizePositions(newPositions);
    }
  };

  const handlePrizeAmountChange = (index: number, val: number) => {
    const next = [...prizePositions];
    next[index].amount = Math.max(0, val);
    setPrizePositions(next);
    if (isDiamondPrizeType(prizeType)) {
      setTotalPrizeValue(next.reduce((a, b) => a + b.amount, 0));
    }
  };

  const handlePrizeLabelChange = (index: number, val: string) => {
    const next = [...prizePositions];
    next[index].label = val;
    setPrizePositions(next);
  };

  const handlePositionPrizeTypeChange = (index: number, newType: PrizeType) => {
    const next = [...prizePositions];
    next[index].prizeType = newType;
    if (isDiamondPrizeType(newType)) {
      const pkg = FREE_FIRE_DIAMOND_PACKAGES.find(p => p.diamonds === next[index].amount) || FREE_FIRE_DIAMOND_PACKAGES[2]; // 310
      next[index].amount = pkg.diamonds;
      next[index].diamondPackageId = pkg.id;
      next[index].diamondPackageLabel = pkg.label;
    }
    setPrizePositions(next);
  };

  const handleSelectDiamondPackageForPosition = (index: number, pkg: DiamondPackage) => {
    const next = [...prizePositions];
    next[index].amount = pkg.diamonds;
    next[index].diamondPackageId = pkg.id;
    next[index].diamondPackageLabel = pkg.label;
    setPrizePositions(next);
    setActivePackageSelectorIndex(null);
    setTotalPrizeValue(next.reduce((a, b) => a + b.amount, 0));
  };

  const handleAddPrizePosition = () => {
    if (prizePositions.length >= 10) return;
    const rank = prizePositions.length + 1;
    let newPos: PrizePosition;
    
    if (isDiamondPrizeType(prizeType)) {
      const pkg = FREE_FIRE_DIAMOND_PACKAGES[0]; // 100 Diamonds
      newPos = {
        rank,
        position: rank,
        label: `${rank}th Place`,
        amount: pkg.diamonds,
        prizeType,
        diamondPackageId: pkg.id,
        diamondPackageLabel: pkg.label,
      };
    } else {
      newPos = {
        rank,
        position: rank,
        label: `${rank}th Place`,
        amount: 500,
        prizeType,
      };
    }
    
    const updated = [...prizePositions, newPos];
    setPrizePositions(updated);
    setPrizePositionCount(updated.length);
    setTotalPrizeValue(updated.reduce((a, b) => a + b.amount, 0));
  };

  const handleRemovePrizePosition = (index: number) => {
    if (prizePositions.length <= 1) return;
    const filtered = prizePositions.filter((_, i) => i !== index);
    const reindexed = filtered.map((p, idx) => ({
      ...p,
      rank: idx + 1,
      position: idx + 1,
      label: p.label.match(/\d+(st|nd|rd|th)/) ? `${idx + 1}${idx === 0 ? 'st' : idx === 1 ? 'nd' : idx === 2 ? 'rd' : 'th'} Place` : p.label,
    }));
    setPrizePositions(reindexed);
    setPrizePositionCount(reindexed.length);
    setTotalPrizeValue(reindexed.reduce((a, b) => a + b.amount, 0));
    if (activePackageSelectorIndex === index) {
      setActivePackageSelectorIndex(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please enter a tournament title.');
      return;
    }

    if (maxParticipants <= 0 || participantsPerMatch <= 0 || advancingPerMatch <= 0) {
      setError('Participants and capacity numbers must be positive integers.');
      return;
    }

    if (entryType === 'PAID_IN_GAME' && (!entryFee || entryFee <= 0)) {
      setError('Please specify a valid entry fee (> ₹0) for Paid Entry tournaments.');
      return;
    }

    if (totalPrizeValue <= 0) {
      setError(`Total Prize Value (${unitName}) must be greater than zero.`);
      return;
    }

    if (!isPrizeBalanced) {
      setError(`Prize distribution mismatch: The sum of prize positions (${unitSymbol}${currentPositionsSum.toLocaleString()}) must equal the total prize value (${unitSymbol}${totalPrizeValue.toLocaleString()}). Difference: ${unitSymbol}${prizeDiff.toLocaleString()}`);
      return;
    }

    if (hasZeroOrNegativePrizes) {
      setError(`Every prize position must have an amount strictly greater than 0.`);
      return;
    }

    const cleanPositions: PrizePosition[] = prizePositions
      .filter((p) => Number(p.amount) > 0)
      .map((p, idx) => {
        const pos: PrizePosition = {
          rank: idx + 1,
          position: idx + 1,
          label: p.label || `${idx + 1}th Place`,
          amount: Number(p.amount),
          prizeType: p.prizeType || prizeType,
        };
        if (p.diamondPackageId) pos.diamondPackageId = p.diamondPackageId;
        if (p.diamondPackageLabel) pos.diamondPackageLabel = p.diamondPackageLabel;
        if (p.customPrizeDetails) pos.customPrizeDetails = p.customPrizeDetails;
        if (p.giftCardType) pos.giftCardType = p.giftCardType;
        return pos;
      });

    try {
      setLoading(true);
      setError(null);

      const actualEntryFee = entryType === 'PAID_IN_GAME' ? Number(entryFee) : 0;
      const actualAdsRequired = entryType === 'FREE_ADS' ? Number(adsRequired) : 0;

      if (isEditMode && tournamentToEdit) {
        await updateTournamentDetails(tournamentToEdit.id, {
          title: title.trim(),
          format,
          entryType,
          entryFee: actualEntryFee,
          status,
          maxParticipants: Number(maxParticipants),
          participantsPerMatch: Number(participantsPerMatch),
          qualifiersCount: calcQualifierCount,
          advancingPerMatch: Number(advancingPerMatch),
          adsRequired: actualAdsRequired,
          prizeType,
          totalPrizeValue,
          prizePool: totalPrizeValue,
          prizePositionCount: cleanPositions.length,
          prizePositions: cleanPositions,
          startDate,
          startTime,
          description: description.trim(),
          rules: rules.trim(),
        });
      } else {
        await createTournamentWithMatches({
          title: title.trim(),
          game: 'FREE FIRE MAX',
          format,
          entryType,
          entryFee: actualEntryFee,
          adsRequired: actualAdsRequired,
          status,
          maxParticipants: Number(maxParticipants),
          participantsPerMatch: Number(participantsPerMatch),
          qualifiersCount: calcQualifierCount,
          advancingPerMatch: Number(advancingPerMatch),
          prizeType,
          totalPrizeValue,
          prizePool: totalPrizeValue,
          prizePositionCount: cleanPositions.length,
          prizePositions: cleanPositions,
          startDate,
          startTime,
          description: description.trim(),
          rules: rules.trim(),
          createdBy: userProfile?.displayName || 'Admin',
        });
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to save tournament. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="create-tournament-modal"
      isOpen={isOpen}
      onClose={onClose}
      title={isEditMode ? 'Edit Free Fire Tournament & Bracket' : 'Create Official Free Fire Tournament'}
      subtitle="Configure mode, qualification circuit capacity, rewarded ad rules & prize reward positions"
      maxWidth="3xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6 py-2">
        {error && (
          <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {/* ENTRY REQUIREMENT TYPE SELECTION */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
            Tournament Entry & Monetization Model <span className="text-orange-500">*</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
            {AVAILABLE_ENTRY_TYPES.map((et) => {
              const isSelected = entryType === et.type;
              return (
                <button
                  key={et.type}
                  type="button"
                  id={`entry-type-${et.type.toLowerCase().replace(/_/g, '-')}`}
                  onClick={() => handleEntryTypeSelect(et.type)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-slate-900 border-orange-500 text-white shadow-lg ring-1 ring-orange-500/50'
                      : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-base">{et.icon}</span>
                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border ${et.badgeStyle}`}>
                        {et.badge}
                      </span>
                    </div>
                    <span className="text-xs font-bold block text-white">{et.title}</span>
                    <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{et.subtitle}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Highlight Banner based on selected entry type */}
        {entryType === 'PAID_IN_GAME' && (
          <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-cyan-200 text-xs space-y-2">
            <div className="flex items-center gap-2">
              <Gem className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="font-bold text-cyan-300">
                PAID ENTRY + NON-CASH IN-GAME DIAMOND REWARD
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Players pay the configured entry fee (₹{entryFee}). Winner receives official Free Fire In-Game Diamonds top-up. 
              <strong> Strict policy:</strong> There is NO cash prize, NO winning money, NO cash wallet balance, and NO cash withdrawal.
            </p>
          </div>
        )}

        {entryType === 'FREE_IN_GAME' && (
          <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/40 text-purple-200 text-xs flex items-center gap-2">
            <Gift className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="text-[11px] text-slate-300">
              <strong>FREE DIAMOND TOURNAMENT:</strong> Zero entry fee. Winners receive direct Free Fire In-Game Diamonds top-up to their verified UID.
            </span>
          </div>
        )}

        {/* Format Select (SOLO vs SQUAD) */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
            Tournament Format & Game Mode
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
            <button
              type="button"
              id="format-select-solo"
              onClick={() => handleFormatChange('SOLO')}
              className={`p-3 rounded-xl border flex items-center gap-3 transition-all text-left cursor-pointer ${
                format === 'SOLO'
                  ? 'bg-amber-950/40 border-amber-500 text-white shadow-md shadow-amber-950/30 ring-1 ring-amber-500/50'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${format === 'SOLO' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800'}`}>
                <User className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold block truncate">SOLO SURVIVOR</span>
                <span className="text-[10px] text-slate-400">48 Players/Match</span>
              </div>
            </button>

            <button
              type="button"
              id="format-select-squad"
              onClick={() => handleFormatChange('SQUAD')}
              className={`p-3 rounded-xl border flex items-center gap-3 transition-all text-left cursor-pointer ${
                format === 'SQUAD'
                  ? 'bg-purple-950/40 border-purple-500 text-white shadow-md shadow-purple-950/30 ring-1 ring-purple-500/50'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${format === 'SQUAD' ? 'bg-purple-500 text-white font-bold' : 'bg-slate-800'}`}>
                <Users className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold block truncate">SQUAD WARLORDS</span>
                <span className="text-[10px] text-slate-400">12 Teams/Match</span>
              </div>
            </button>
          </div>
        </div>

        {/* Title and Lifecycle Status */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Tournament Title <span className="text-orange-500">*</span>
            </label>
            <input
              id="create-tourn-title-input"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. FREE FIRE MAX — SOLO SURVIVOR CUP"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Tournament Status
            </label>
            <select
              id="create-tourn-status-select"
              value={status}
              onChange={(e) => setStatus(e.target.value as TournamentStatus)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-bold"
            >
              <option value="UPCOMING">UPCOMING</option>
              <option value="REGISTRATION_OPEN">REGISTRATION OPEN</option>
              <option value="REGISTRATION_CLOSED">REGISTRATION CLOSED</option>
              <option value="ONGOING">ONGOING (LIVE)</option>
              <option value="COMPLETED">COMPLETED</option>
              <option value="CANCELLED">CANCELLED</option>
            </select>
          </div>
        </div>

        {/* ENTRY FEE & ADS SETTINGS */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-cyan-400" />
              Entry Fee & Requirement Settings
            </span>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/50 px-2 py-0.5 rounded border border-cyan-500/30">
              {entryType === 'PAID_IN_GAME' ? `Paid Fee: ₹${entryFee}` : entryType === 'FREE_ADS' ? `5 Video Ads` : `Free Entry`}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {entryType === 'PAID_IN_GAME' ? (
              <div className="sm:col-span-2 space-y-2">
                <label className="block text-xs font-semibold text-slate-300">
                  Player Tournament Entry Fee (₹) <span className="text-cyan-400">*</span>
                </label>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                  <div className="relative w-full sm:max-w-xs">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-400 font-bold text-sm">₹</span>
                    <input
                      id="create-tourn-entry-fee"
                      type="number"
                      required
                      min={1}
                      value={entryFee}
                      onChange={(e) => setEntryFee(Number(e.target.value))}
                      className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-900 border border-cyan-500/50 text-white font-mono font-bold text-sm outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {PRESET_ENTRY_FEES.map((fee) => (
                      <button
                        key={fee}
                        type="button"
                        onClick={() => setEntryFee(fee)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-all ${
                          entryFee === fee
                            ? 'bg-cyan-500 text-slate-950 font-extrabold'
                            : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        ₹{fee}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-slate-400">
                  Players pay this exact amount at registration. Snapshot of player Free Fire UID is captured.
                </p>
              </div>
            ) : entryType === 'FREE_ADS' ? (
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Rewarded Ads Required <span className="text-emerald-400">*</span>
                </label>
                <input
                  id="create-tourn-ads-required"
                  type="number"
                  required
                  min={1}
                  max={10}
                  value={adsRequired}
                  onChange={(e) => setAdsRequired(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-emerald-500/40 text-xs font-bold text-emerald-400 outline-none focus:border-emerald-400 font-mono"
                />
                <span className="text-[10px] text-emerald-500 mt-0.5 block">Standard: 5 Ads</span>
              </div>
            ) : (
              <div className="sm:col-span-2 text-xs text-slate-400">
                Direct free entry tournament with no ads and no fees.
              </div>
            )}
          </div>
        </div>

        {/* DYNAMIC BRACKET & CAPACITY CALCULATOR */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-orange-400" />
              Dynamic Tournament Structure & Capacity
            </span>
            <span className="text-[11px] font-mono text-orange-400 bg-orange-950/50 px-2 py-0.5 rounded border border-orange-500/30">
              {calcQualifierCount} Qualifiers → {calcGrandFinalSlots} Finalists
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Total Capacity <span className="text-orange-500">*</span>
              </label>
              <input
                id="create-tourn-capacity"
                type="number"
                required
                min={1}
                value={maxParticipants}
                onChange={(e) => setMaxParticipants(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-orange-500 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">{format === 'SOLO' ? 'Total Players' : 'Total Teams'}</span>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Capacity Per Match <span className="text-orange-500">*</span>
              </label>
              <input
                id="create-tourn-match-capacity"
                type="number"
                required
                min={1}
                value={participantsPerMatch}
                onChange={(e) => setParticipantsPerMatch(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-orange-500 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">{format === 'SOLO' ? 'e.g. 48 players' : 'e.g. 12 squads'}</span>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Advancing Per Match <span className="text-orange-500">*</span>
              </label>
              <input
                id="create-tourn-advancing"
                type="number"
                required
                min={1}
                value={advancingPerMatch}
                onChange={(e) => setAdvancingPerMatch(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-orange-500 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">Top survivors to final</span>
            </div>
          </div>
        </div>

        {/* REWARD & PRIZE DELIVERY TYPE */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-amber-400" />
              Reward & Prize Delivery Type
            </span>
            <span className="text-[10px] text-cyan-400 font-bold bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30">
              NON-CASH IN-GAME REWARD
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {AVAILABLE_PRIZE_TYPES.map((pt) => (
              <button
                key={pt.type}
                type="button"
                id={`prize-type-${pt.type.toLowerCase().replace(/_/g, '-')}`}
                onClick={() => handlePrizeTypeChange(pt.type)}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  prizeType === pt.type
                    ? 'bg-amber-950/50 border-amber-500 text-white shadow ring-1 ring-amber-500/40'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-sm">{pt.icon}</span>
                  <span className="text-xs font-bold">{pt.label}</span>
                </div>
                <span className="text-[10px] text-slate-400 line-clamp-2">{pt.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* PRIZE POSITIONS & REWARDS */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <div>
                <h4 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-300">
                  PRIZE POSITIONS & REWARDS
                </h4>
                <p className="text-[11px] text-slate-400">
                  {isDiamonds 
                    ? 'Select predefined Free Fire Diamond packages for each winner rank (100–11,500 💎).'
                    : 'Configure position rewards and values for official tournament fulfillment.'}
                </p>
              </div>
            </div>

            <button
              type="button"
              id="auto-distribute-btn"
              onClick={() => handleAutoDistributePrizes(totalPrizeValue, prizePositionCount)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold transition-all cursor-pointer self-start sm:self-auto"
            >
              <Wand2 className="w-3.5 h-3.5 text-amber-400" />
              Auto-Distribute
            </button>
          </div>

          {/* Value and Positions Controller */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-slate-900/90 rounded-xl border border-slate-800">
            {/* Total Prize Pool Input */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Total Reward Value ({unitName})</span>
                <span className="text-[10px] text-amber-400 font-mono font-normal">Sum of all positions</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-400 font-bold text-sm">{unitSymbol}</span>
                <input
                  id="total-prize-value-input"
                  type="number"
                  required
                  min={1}
                  step={1}
                  value={totalPrizeValue}
                  onChange={(e) => handleTotalPrizeValueChange(Number(e.target.value))}
                  placeholder={isDiamonds ? '1890' : '5000'}
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 text-sm font-extrabold text-white outline-none font-mono"
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex flex-wrap gap-1 mt-2">
                {(isDiamonds ? PRESET_DIAMOND_VALUES : PRESET_PRIZE_VALUES).slice(0, 6).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleTotalPrizeValueChange(preset)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                      totalPrizeValue === preset
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {isDiamonds ? `${preset} 💎` : `₹${preset >= 1000 ? `${preset / 1000}k` : preset}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Number of Prize Positions */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Number of Prize Positions</span>
                <span className="text-[10px] text-orange-400 font-mono font-normal">1 to 10 Winner Ranks</span>
              </label>
              <div className="flex items-center gap-2">
                <select
                  id="prize-positions-count-select"
                  value={prizePositionCount}
                  onChange={(e) => handlePositionCountChange(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-400 text-xs font-bold text-white outline-none font-mono"
                >
                  <option value={1}>1 Position (1st Place Champion Only)</option>
                  <option value={2}>2 Positions (1st, 2nd Place)</option>
                  <option value={3}>3 Positions (1st, 2nd, 3rd Place)</option>
                  <option value={4}>4 Positions (1st to 4th Place)</option>
                  <option value={5}>5 Positions (1st to 5th Place)</option>
                  <option value={6}>6 Positions (1st to 6th Place)</option>
                  <option value={7}>7 Positions (1st to 7th Place)</option>
                  <option value={8}>8 Positions (1st to 8th Place)</option>
                  <option value={9}>9 Positions (1st to 9th Place)</option>
                  <option value={10}>10 Positions (1st to 10th Place)</option>
                </select>
              </div>

              {/* Quick Count Stepper Badges */}
              <div className="flex items-center gap-1 mt-2 overflow-x-auto no-scrollbar py-0.5">
                {[1, 2, 3, 4, 5, 6, 7, 8, 10].map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => handlePositionCountChange(cnt)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                      prizePositionCount === cnt
                        ? 'bg-orange-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cnt}P
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Realtime Live Validation Status Card */}
          <div
            id="prize-validation-status"
            className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs transition-all ${
              isPrizeValid
                ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                : prizeDiff > 0
                ? 'bg-amber-950/60 border-amber-500/50 text-amber-300'
                : 'bg-rose-950/70 border-rose-500/60 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2 font-medium">
              {isPrizeValid ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <div>
                {isPrizeValid ? (
                  <span>
                    <strong>Balanced:</strong> All {unitSymbol}{totalPrizeValue.toLocaleString()} allocated across {prizePositions.length} active positions.
                  </span>
                ) : prizeDiff > 0 ? (
                  <span>
                    <strong>Remaining to Allocate:</strong> {unitSymbol}{prizeDiff.toLocaleString()} needs to be assigned across positions.
                  </span>
                ) : (
                  <span>
                    <strong>Budget Exceeded:</strong> Positions exceed total budget by {unitSymbol}{Math.abs(prizeDiff).toLocaleString()}.
                  </span>
                )}
                {hasZeroOrNegativePrizes && (
                  <div className="text-[11px] text-rose-300 mt-0.5">
                    ⚠️ Positions with 0 amount are not allowed.
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3 font-mono text-[11px] self-end sm:self-auto">
              <span className="text-slate-400">Sum: <strong className="text-white">{unitSymbol}{currentPositionsSum.toLocaleString()}</strong></span>
              <span className="text-slate-400">Target: <strong className="text-amber-400">{unitSymbol}{totalPrizeValue.toLocaleString()}</strong></span>
            </div>
          </div>

          {/* Dynamic Prize Positions Rows */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1">
              <span>Position & Label</span>
              <span>Reward Package / Value</span>
            </div>

            {prizePositions.map((pos, idx) => {
              const posIsDiamonds = isDiamondPrizeType(pos.prizeType || prizeType);
              const isSelectorOpen = activePackageSelectorIndex === idx;

              return (
                <div
                  key={idx}
                  id={`prize-pos-row-${idx + 1}`}
                  className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 hover:border-slate-700 transition-colors space-y-3"
                >
                  {/* Top Bar: Rank badge + Custom label + Actions */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                        pos.position === 1 ? 'bg-amber-500 text-slate-950' :
                        pos.position === 2 ? 'bg-slate-300 text-slate-950' :
                        pos.position === 3 ? 'bg-orange-600 text-white' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        #{pos.position}
                      </div>

                      <input
                        type="text"
                        value={pos.label}
                        onChange={(e) => handlePrizeLabelChange(idx, e.target.value)}
                        placeholder={`e.g. ${pos.position === 1 ? '1st Place (Champion)' : `${pos.position}th Place`}`}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-amber-400"
                      />
                    </div>

                    {prizePositions.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemovePrizePosition(idx)}
                        className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-950/40 cursor-pointer transition-colors shrink-0"
                        title="Remove position"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Reward Configuration for this Position */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-800/60">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                        Reward Type
                      </label>
                      <select
                        value={pos.prizeType || prizeType}
                        onChange={(e) => handlePositionPrizeTypeChange(idx, e.target.value as PrizeType)}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-amber-400"
                      >
                        {AVAILABLE_PRIZE_TYPES.map((pt) => (
                          <option key={pt.type} value={pt.type}>
                            {pt.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                        {posIsDiamonds ? 'Diamond Package Selection' : 'Reward Value (₹)'}
                      </label>

                      {posIsDiamonds ? (
                        <button
                          type="button"
                          id={`select-diamond-pkg-btn-${idx}`}
                          onClick={() => setActivePackageSelectorIndex(isSelectorOpen ? null : idx)}
                          className="w-full px-3 py-1.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/50 text-cyan-200 text-xs font-bold flex items-center justify-between transition-all cursor-pointer"
                        >
                          <span className="flex items-center gap-1.5">
                            <Gem className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{pos.amount || 0} Diamonds Package</span>
                          </span>
                          <ChevronDown className={`w-3.5 h-3.5 text-cyan-400 transition-transform ${isSelectorOpen ? 'rotate-180' : ''}`} />
                        </button>
                      ) : (
                        <div className="relative">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">₹</span>
                          <input
                            type="number"
                            min={1}
                            value={pos.amount}
                            onChange={(e) => handlePrizeAmountChange(idx, Number(e.target.value))}
                            className={`w-full pl-6 pr-2.5 py-1.5 rounded-lg bg-slate-950 border text-xs font-bold outline-none text-right font-mono ${
                              Number(pos.amount) <= 0 ? 'border-rose-500 text-rose-300' : 'border-slate-800 text-white focus:border-amber-400'
                            }`}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Inline Diamond Package Selector when active */}
                  {posIsDiamonds && isSelectorOpen && (
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-cyan-500/30 animate-in fade-in slide-in-from-top-2 duration-200">
                      <DiamondPackageSelector
                        id={`diamond-selector-pos-${idx}`}
                        selectedDiamonds={pos.amount}
                        selectedPackageId={pos.diamondPackageId}
                        onSelect={(pkg) => handleSelectDiamondPackageForPosition(idx, pkg)}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-1">
            {prizePositions.length < 10 && (
              <button
                type="button"
                id="add-prize-position-btn"
                onClick={handleAddPrizePosition}
                className="inline-flex items-center gap-1 text-[11px] bg-slate-900 hover:bg-slate-800 text-amber-400 border border-amber-500/30 px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all"
              >
                <Plus className="w-3.5 h-3.5" /> Add #{prizePositions.length + 1} Position
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                applyFormatAndEntryDefaults(format, entryType);
              }}
              className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 cursor-pointer ml-auto"
            >
              <RefreshCw className="w-3 h-3" /> Reset Defaults
            </button>
          </div>
        </div>

        {/* SCHEDULE: START DATE & START TIME */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Start Date <span className="text-orange-500">*</span>
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="create-tourn-start-date"
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-medium"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Start Time & Timezone <span className="text-orange-500">*</span>
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="create-tourn-start-time"
                type="text"
                required
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                placeholder="e.g. 19:00 IST / 7:00 PM"
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-medium"
              />
            </div>
          </div>
        </div>

        {/* DESCRIPTION & RULES */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Tournament Description
            </label>
            <textarea
              id="create-tourn-desc"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Briefly describe the championship and stage schedule..."
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Official Competitive Rules
            </label>
            <textarea
              id="create-tourn-rules"
              rows={2}
              value={rules}
              onChange={(e) => setRules(e.target.value)}
              placeholder="e.g. Mobile device only. Screen recording mandatory for top 3 finalists. Fair play strictly enforced."
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none resize-none font-mono text-[11px]"
            />
          </div>
        </div>

        {/* FORM ACTIONS */}
        <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-3 pt-3 border-t border-slate-800/80">
          <button
            type="button"
            id="cancel-create-tourn-btn"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
          >
            CANCEL
          </button>

          <button
            type="submit"
            id="submit-create-tourn-btn"
            disabled={loading || !isPrizeValid}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 via-amber-600 to-yellow-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : isEditMode ? (
              <Edit3 className="w-4 h-4" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span>{isEditMode ? 'UPDATE TOURNAMENT' : 'SAVE & PUBLISH TOURNAMENT'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
