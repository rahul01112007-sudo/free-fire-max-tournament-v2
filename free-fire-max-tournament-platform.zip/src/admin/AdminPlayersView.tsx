import React, { useState, useEffect } from 'react';
import { Users, Search, Ban, CheckCircle2, UserCheck, Shield, Mail, Phone, Gamepad2, AlertTriangle, ShieldAlert } from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { UserProfile } from '../types';
import { banPlayer, unbanPlayer } from '../services/authService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { BanPlayerModal } from '../components/BanPlayerModal';
import { useAuth } from '../context/AuthContext';

export const AdminPlayersView: React.FC = () => {
  const { userProfile: adminProfile } = useAuth();
  const [players, setPlayers] = useState<UserProfile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [playerToBan, setPlayerToBan] = useState<UserProfile | null>(null);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'BANNED'>('ALL');

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'users'), orderBy('createdAt', 'desc')),
      (snap) => {
        const list: UserProfile[] = [];
        snap.forEach((d) => list.push(d.data() as UserProfile));
        setPlayers(list);
      }
    );
    return () => unsub();
  }, []);

  const handleOpenBanModal = (player: UserProfile) => {
    setPlayerToBan(player);
  };

  const handleConfirmBan = async (uid: string, reason: string) => {
    try {
      setProcessingId(uid);
      await banPlayer(uid, reason, adminProfile?.displayName || 'Tournament Administrator');
    } catch (e) {
      console.error('Error banning player:', e);
      throw e;
    } finally {
      setProcessingId(null);
    }
  };

  const handleUnban = async (uid: string) => {
    try {
      setProcessingId(uid);
      await unbanPlayer(uid);
    } catch (e) {
      console.error('Error unbanning player:', e);
    } finally {
      setProcessingId(null);
    }
  };

  const filtered = players.filter((p) => {
    const isBanned = p.status === 'banned' || p.isBanned;
    if (statusFilter === 'ACTIVE' && isBanned) return false;
    if (statusFilter === 'BANNED' && !isBanned) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      p.displayName?.toLowerCase().includes(q) ||
      p.email?.toLowerCase().includes(q) ||
      p.ign?.toLowerCase().includes(q) ||
      p.freeFireUid?.includes(q) ||
      p.phone?.includes(q) ||
      p.banReason?.toLowerCase().includes(q)
    );
  });

  return (
    <div id="admin-players-view" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-orange-400" />
            Registered Players & Esports Roster
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit player profiles, Free Fire UIDs, phone numbers, and manage competitive bans
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="w-full sm:w-36 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Statuses ({players.length})</option>
            <option value="ACTIVE">Active ({players.filter((p) => p.status !== 'banned' && !p.isBanned).length})</option>
            <option value="BANNED">Banned ({players.filter((p) => p.status === 'banned' || p.isBanned).length})</option>
          </select>

          <div className="w-full sm:w-64">
            <input
              id="players-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search IGN, Name, UID, Phone..."
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
            />
          </div>
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          id="no-players-found"
          title="No players found."
          description="Player accounts created via Free Fire tournament registration will be listed here."
        />
      ) : (
        <>
          {/* Mobile Card List (< md) */}
          <div className="block md:hidden space-y-3">
            {filtered.map((player) => {
              const isBanned = player.status === 'banned' || player.isBanned;

              return (
                <div
                  key={player.uid}
                  className={`p-4 rounded-xl border space-y-3 shadow-lg ${
                    isBanned 
                      ? 'bg-red-950/20 border-red-500/40' 
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2.5">
                    <div className="min-w-0 flex-1">
                      <span className="font-bold text-white block text-sm truncate">
                        {player.displayName || 'Player'}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono block truncate">
                        {player.email}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <StatusBadge status={player.role.toUpperCase()} className="text-[9px] py-0" />
                      <StatusBadge status={isBanned ? 'BANNED' : 'ACTIVE'} className="text-[9px] py-0" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                    <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block font-sans">IGN</span>
                      <span className="font-bold text-amber-400 font-sans block truncate">{player.ign || '-'}</span>
                    </div>
                    <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block font-sans">Free Fire UID</span>
                      <span className="text-cyan-400 font-bold block truncate">{player.freeFireUid || '-'}</span>
                    </div>
                    <div className="col-span-2 p-2 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase block font-sans">WhatsApp / Phone</span>
                      <span className="text-slate-300 block truncate">{player.phone || '-'}</span>
                    </div>
                  </div>

                  {isBanned && player.banReason && (
                    <div className="p-2.5 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-300">
                      <span className="font-bold block text-[10px] text-red-400 uppercase">Ban Reason:</span>
                      "{player.banReason}"
                    </div>
                  )}

                  {player.role !== 'admin' && (
                    <div className="pt-1">
                      {isBanned ? (
                        <button
                          disabled={processingId === player.uid}
                          onClick={() => handleUnban(player.uid)}
                          className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all min-h-[44px] flex items-center justify-center cursor-pointer shadow-md shadow-emerald-600/20"
                        >
                          {processingId === player.uid ? 'Unbanning...' : 'Unban Player & Restore Access'}
                        </button>
                      ) : (
                        <button
                          disabled={processingId === player.uid}
                          onClick={() => handleOpenBanModal(player)}
                          className="w-full py-2.5 bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-700/60 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[44px] cursor-pointer"
                        >
                          <Ban className="w-4 h-4" /> Ban Player
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Desktop Table (md and above) */}
          <div className="hidden md:block overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Player</th>
                  <th className="py-3 px-3">In-Game Name (IGN)</th>
                  <th className="py-3 px-3">Free Fire UID</th>
                  <th className="py-3 px-3">WhatsApp / Phone</th>
                  <th className="py-3 px-3">Role</th>
                  <th className="py-3 px-3">Status / Sanction</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filtered.map((player) => {
                  const isBanned = player.status === 'banned' || player.isBanned;

                  return (
                    <tr key={player.uid} className={`transition-colors ${isBanned ? 'bg-red-950/10 hover:bg-red-950/20' : 'hover:bg-slate-800/30'}`}>
                      <td className="py-3 px-4">
                        <span className="font-sans font-bold text-white block">
                          {player.displayName || 'Player'}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {player.email}
                        </span>
                      </td>

                      <td className="py-3 px-3 font-sans font-bold text-amber-400">
                        {player.ign || '-'}
                      </td>

                      <td className="py-3 px-3 text-cyan-400 font-bold">
                        {player.freeFireUid || '-'}
                      </td>

                      <td className="py-3 px-3 text-slate-400 text-[11px]">
                        {player.phone || '-'}
                      </td>

                      <td className="py-3 px-3">
                        <StatusBadge status={player.role.toUpperCase()} className="text-[9px] py-0" />
                      </td>

                      <td className="py-3 px-3">
                        <div className="space-y-0.5">
                          <StatusBadge status={isBanned ? 'BANNED' : 'ACTIVE'} className="text-[9px] py-0" />
                          {isBanned && player.banReason && (
                            <span className="text-[10px] text-red-400 font-sans block truncate max-w-[140px]" title={player.banReason}>
                              "{player.banReason}"
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-sans">
                        {player.role !== 'admin' && (
                          isBanned ? (
                            <button
                              disabled={processingId === player.uid}
                              onClick={() => handleUnban(player.uid)}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow cursor-pointer"
                            >
                              {processingId === player.uid ? 'Unbanning...' : 'Unban Player'}
                            </button>
                          ) : (
                            <button
                              disabled={processingId === player.uid}
                              onClick={() => handleOpenBanModal(player)}
                              className="px-3 py-1.5 bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-700/60 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ml-auto cursor-pointer"
                            >
                              <Ban className="w-3 h-3" /> Ban Player
                            </button>
                          )
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Ban Player Modal */}
      <BanPlayerModal
        isOpen={Boolean(playerToBan)}
        onClose={() => setPlayerToBan(null)}
        player={playerToBan}
        onConfirmBan={handleConfirmBan}
      />
    </div>
  );
};

