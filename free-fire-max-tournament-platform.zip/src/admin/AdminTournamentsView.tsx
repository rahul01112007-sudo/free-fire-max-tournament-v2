import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Plus, 
  Trash2, 
  Calendar, 
  Clock, 
  DollarSign, 
  Users, 
  User, 
  Flame, 
  Sparkles, 
  Edit3, 
  Award, 
  AlertTriangle, 
  AlertCircle, 
  X, 
  Gift, 
  Gem,
  RotateCcw,
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';
import { 
  Tournament, 
  TournamentStatus, 
  getTournamentPrizePositions, 
  formatPrizeAmount, 
  formatEntryFeeDisplay, 
  getPrizePoolLabel, 
  isDiamondPrizeType,
  normalizeEntryType 
} from '../types';
import { listenTournaments, updateTournamentStatus, deleteTournament } from '../services/tournamentService';
import { cancelTournamentWithRefunds } from '../services/refundService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { Modal } from '../components/Modal';
import { CreateTournamentModal } from './CreateTournamentModal';
import { useAuth } from '../context/AuthContext';

interface AdminTournamentsViewProps {
  onNavigateToHistory?: () => void;
}

export const AdminTournamentsView: React.FC<AdminTournamentsViewProps> = ({ onNavigateToHistory }) => {
  const { userProfile } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingTourn, setEditingTourn] = useState<Tournament | null>(null);
  
  // Hard Delete state
  const [tournToDelete, setTournToDelete] = useState<Tournament | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Cancel & Refund state
  const [tournToCancel, setTournToCancel] = useState<Tournament | null>(null);
  const [cancelReason, setCancelReason] = useState('Tournament cancelled mid-way by administrator. Full refunds issued to all joined players.');
  const [isCancelling, setIsCancelling] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = listenTournaments((list) => {
      setTournaments(list);
    });
    return () => unsub();
  }, []);

  const handleStatusChange = async (id: string, newStatus: TournamentStatus) => {
    await updateTournamentStatus(id, newStatus);
  };

  const confirmDeleteTournament = async () => {
    if (!tournToDelete) return;
    setDeleteError(null);
    setIsDeleting(true);
    try {
      await deleteTournament(tournToDelete.id);
      setTournToDelete(null);
    } catch (e: any) {
      console.error('Delete tournament failed:', e);
      setDeleteError(e?.message || 'Failed to delete tournament from Firestore. Please verify admin privileges.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleExecuteCancellation = async (tournament: Tournament) => {
    setIsCancelling(true);
    setCancelError(null);
    try {
      await cancelTournamentWithRefunds({
        tournamentId: tournament.id,
        cancellationReason: cancelReason.trim() || 'Tournament cancelled mid-way by administrator.',
        adminName: userProfile?.displayName || 'Admin Desk',
      });
      setTournToCancel(null);
      setTournToDelete(null);
      if (onNavigateToHistory) {
        onNavigateToHistory();
      }
    } catch (e: any) {
      console.error('Failed to cancel tournament:', e);
      setCancelError(e?.message || 'Failed to cancel tournament. Please try again.');
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div id="admin-tournaments-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Trophy className="w-6 h-6 text-orange-400" />
            Tournament Management & Brackets
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Create, edit prize distribution (1st–5th), manage registration statuses, and configure tournament match pipelines
          </p>
        </div>

        <button
          id="btn-admin-add-tournament"
          onClick={() => {
            setEditingTourn(null);
            setIsCreateOpen(true);
          }}
          className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Create Tournament
        </button>
      </div>

      {tournaments.length === 0 ? (
        <EmptyState
          id="no-admin-tournaments"
          title="No tournaments created yet."
          description="Create your first Free Fire MAX tournament to generate match brackets, prize allocations, and open registrations."
          actionText="Create Tournament"
          onAction={() => {
            setEditingTourn(null);
            setIsCreateOpen(true);
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tournaments.map((tourn) => {
            const prizePositions = getTournamentPrizePositions(tourn);
            const totalVal = Number(tourn.totalPrizeValue) || Number(tourn.prizePool) || prizePositions.reduce((a, b) => a + b.amount, 0);

            return (
              <div
                key={tourn.id}
                id={`admin-tourn-card-${tourn.id}`}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <StatusBadge status={tourn.format} />
                      <StatusBadge status={tourn.status} />
                    </div>
                    <div className="flex items-center gap-1">
                      {tourn.status !== 'CANCELLED' && tourn.status !== 'COMPLETED' && (
                        <button
                          id={`cancel-refund-btn-${tourn.id}`}
                          onClick={() => {
                            setCancelError(null);
                            setCancelReason('Tournament cancelled mid-way by administrator. Full refunds issued to joined players.');
                            setTournToCancel(tourn);
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold cursor-pointer"
                          title="Cancel Tournament & Refund Players"
                        >
                          <RotateCcw className="w-4 h-4 text-rose-400" />
                          <span className="hidden xl:inline text-[11px] text-rose-300">Refunds</span>
                        </button>
                      )}
                      <button
                        id={`edit-tourn-btn-${tourn.id}`}
                        onClick={() => {
                          setEditingTourn(tourn);
                          setIsCreateOpen(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-950/40 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold cursor-pointer"
                        title="Edit Tournament & Prizes"
                      >
                        <Edit3 className="w-4 h-4" />
                        <span className="hidden sm:inline text-[11px]">Edit</span>
                      </button>
                      <button
                        id={`del-tourn-btn-${tourn.id}`}
                        onClick={() => {
                          setDeleteError(null);
                          setTournToDelete(tourn);
                        }}
                        className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer"
                        title="Delete Tournament"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-white leading-tight">
                    {tourn.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                    {tourn.description}
                  </p>
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-3 gap-2 p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 block font-semibold uppercase">{getPrizePoolLabel(tourn.prizeType || tourn.rewardType)}</span>
                    <span className="font-extrabold text-amber-400">
                      {formatPrizeAmount(totalVal, tourn.prizeType || tourn.rewardType)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-semibold uppercase">ENTRY FEE</span>
                    <span className={`font-extrabold ${normalizeEntryType(tourn.entryType, tourn.entryFee) === 'PAID_IN_GAME' ? 'text-cyan-400' : 'text-emerald-400'}`}>
                      {formatEntryFeeDisplay(tourn)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-semibold uppercase">REGISTERED</span>
                    <span className="font-extrabold text-emerald-400">{tourn.registeredCount} / {tourn.maxParticipants}</span>
                  </div>
                </div>

                {/* Dynamic Prize Distribution */}
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                      {isDiamondPrizeType(tourn.prizeType || tourn.rewardType) ? (
                        <>
                          <Gem className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="text-cyan-300">Free Fire Diamonds</span>
                        </>
                      ) : (
                        <>
                          <Gift className="w-3.5 h-3.5" />
                          <span>{(tourn.prizeType || tourn.rewardType || 'AMAZON GIFT CARD').replace(/_/g, ' ')}</span>
                        </>
                      )}
                      <span className="text-slate-500 font-normal">({prizePositions.length} Tiers)</span>
                    </span>
                    <span className="font-mono text-slate-400 font-bold">
                      Total: {formatPrizeAmount(totalVal, tourn.prizeType || tourn.rewardType)}
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
                    {prizePositions.map((p, idx) => (
                      <div
                        key={idx}
                        className={`flex-1 min-w-[70px] rounded-lg p-1.5 border text-center ${
                          p.position === 1 ? 'bg-amber-950/50 border-amber-500/40 text-amber-300' :
                          p.position === 2 ? 'bg-slate-900 border-slate-700 text-slate-200' :
                          p.position === 3 ? 'bg-orange-950/40 border-orange-500/30 text-orange-300' :
                          'bg-slate-950 border-slate-800 text-slate-300'
                        }`}
                      >
                        <span className="text-[9px] text-slate-400 font-sans block font-bold truncate">
                          {p.label.split(' ')[0] || `#${p.position}`}
                        </span>
                        <span className="font-bold text-white">
                          {formatPrizeAmount(p.amount, p.prizeType || tourn.prizeType || tourn.rewardType)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status Switcher Bar */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Change Registration / Match Lifecycle Status:
                  </span>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'ONGOING', 'COMPLETED', 'CANCELLED'] as TournamentStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => handleStatusChange(tourn.id, st)}
                        className={`py-1 rounded-lg text-[10px] font-bold uppercase transition-all cursor-pointer ${
                          tourn.status === st
                            ? 'bg-orange-600 text-white'
                            : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        {st.replace('REGISTRATION_', '').replace('_', ' ')}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {tournToDelete && (
        <Modal
          id="delete-tournament-modal"
          isOpen={true}
          onClose={() => {
            if (!isDeleting) {
              setTournToDelete(null);
              setDeleteError(null);
            }
          }}
          title="Delete Tournament?"
          subtitle="This operation is permanent and cannot be undone."
          maxWidth="md"
        >
          <div className="space-y-4">
            {deleteError && (
              <div id="delete-tourn-error" className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{deleteError}</span>
              </div>
            )}

            {/* Tournament Details Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 uppercase font-semibold">Tournament Name:</span>
                <span className="text-xs font-bold text-white truncate max-w-[200px] sm:max-w-[260px]">
                  {tournToDelete.title}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 uppercase font-semibold">Format:</span>
                <StatusBadge status={tournToDelete.format} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 uppercase font-semibold">Registered Players / Teams:</span>
                <span className="text-xs font-bold text-emerald-400">
                  {tournToDelete.registeredCount} / {tournToDelete.maxParticipants}
                </span>
              </div>
            </div>

            {/* Warning Message */}
            <div className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
              tournToDelete.registeredCount > 0
                ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
            }`}>
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <div className="space-y-1.5 leading-relaxed">
                <p className="font-semibold text-rose-200">
                  {tournToDelete.registeredCount > 0 
                    ? `Warning: ${tournToDelete.registeredCount} player(s) joined this tournament!`
                    : 'Warning: Associated matches and registrations will be removed.'}
                </p>
                <p className="text-[11px] opacity-90">
                  {tournToDelete.registeredCount > 0
                    ? 'Hard deleting will erase all player rosters and transaction UTRs, preventing automated refunds. We strongly recommend using "Cancel & Refund" instead so you can return entry fees to players!'
                    : 'Deleting this tournament will permanently wipe its qualifier & final match brackets, seat allocations, room credentials, and player registrations from Firestore. Other tournaments will not be affected.'}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-2">
              {tournToDelete.registeredCount > 0 && (
                <button
                  id="btn-switch-to-cancel-refund"
                  type="button"
                  disabled={isDeleting}
                  onClick={() => {
                    const t = tournToDelete;
                    setTournToDelete(null);
                    setTournToCancel(t);
                    setCancelReason('Tournament cancelled mid-way by administrator. Full refunds issued to joined players.');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-bold uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Cancel & Move to Refunds Desk
                </button>
              )}

              <div className="flex items-center justify-end gap-2 ml-auto">
                <button
                  id="btn-cancel-delete-tournament"
                  type="button"
                  disabled={isDeleting}
                  onClick={() => {
                    setTournToDelete(null);
                    setDeleteError(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  id="btn-confirm-delete-tournament"
                  type="button"
                  disabled={isDeleting}
                  onClick={confirmDeleteTournament}
                  className="px-4 py-2.5 rounded-xl bg-red-950 hover:bg-red-900 border border-red-700/60 text-red-300 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  title="Permanently erase all data"
                >
                  {isDeleting ? (
                    <>
                      <span className="inline-block w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Deleting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      Erase Records
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Cancel Tournament & Prepare Refunds Modal */}
      {tournToCancel && (
        <Modal
          id="cancel-tournament-modal"
          isOpen={true}
          onClose={() => {
            if (!isCancelling) setTournToCancel(null);
          }}
          title="Cancel Tournament Mid-Way & Queue Refunds"
          subtitle="Safely stop the tournament while protecting joined players' entry fees"
          maxWidth="md"
        >
          <div className="space-y-4">
            {cancelError && (
              <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{cancelError}</span>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Tournament:</span>
                <span className="font-bold text-white truncate max-w-[200px]">{tournToCancel.title}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Registered Players:</span>
                <span className="font-bold text-emerald-400">{tournToCancel.registeredCount} joined</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Entry Fee:</span>
                <span className="font-bold text-cyan-400">{formatEntryFeeDisplay(tournToCancel)}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-amber-200">
                  Player-First Refund Protection:
                </p>
                <p className="text-[11px] text-amber-300/80">
                  Player registrations and verified payment records will be preserved and queued on the <strong>Tournament History & Refunds Desk</strong>. Registrations previously denied/rejected by admin for fake payments are automatically excluded.
                </p>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                Reason for Cancellation (Visible to Players) <span className="text-rose-400">*</span>
              </label>
              <textarea
                id="input-cancellation-reason"
                rows={3}
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Explain why the tournament was cancelled (e.g., Garena server maintenance, technical outage)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isCancelling}
                onClick={() => setTournToCancel(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase transition-colors cursor-pointer"
              >
                Go Back
              </button>

              <button
                id="btn-confirm-cancel-tournament"
                type="button"
                disabled={isCancelling}
                onClick={() => handleExecuteCancellation(tournToCancel)}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-rose-600/30 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isCancelling ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Cancelling...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    Confirm & Queue Refunds
                  </>
                )}
              </button>
            </div>
          </div>
        </Modal>
      )}

      <CreateTournamentModal
        isOpen={isCreateOpen}
        tournamentToEdit={editingTourn}
        onClose={() => {
          setIsCreateOpen(false);
          setEditingTourn(null);
        }}
        onSuccess={() => {
          setIsCreateOpen(false);
          setEditingTourn(null);
        }}
      />
    </div>
  );
};
