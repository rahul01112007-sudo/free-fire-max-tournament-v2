import React, { useState, useEffect } from 'react';
import { Trophy, Plus, Trash2, CheckCircle2, Sparkles, AlertCircle, Save, Award, RefreshCw, Gift, Gem } from 'lucide-react';
import { Tournament, TournamentMatch, ResultWinner, MatchStage, getTournamentPrizePositions, formatPrizeAmount, isDiamondPrizeType } from '../types';
import { listenTournaments } from '../services/tournamentService';
import { listenTournamentMatches } from '../services/matchService';
import { publishMatchResult } from '../services/resultService';
import { useAuth } from '../context/AuthContext';

export const AdminResultsView: React.FC = () => {
  const { userProfile } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournId, setSelectedTournId] = useState<string>('');
  const [matches, setMatches] = useState<TournamentMatch[]>([]);
  const [selectedMatchId, setSelectedMatchId] = useState<string>('');

  const [stage, setStage] = useState<MatchStage>('QUALIFIER');
  const [notes, setNotes] = useState('');
  const [winners, setWinners] = useState<ResultWinner[]>([
    { rank: 1, participantId: 'p1', name: 'Winner 1', ffUid: '', ign: '', kills: 5, placementPoints: 12, totalPoints: 20, prizeAmount: 0, qualified: true },
    { rank: 2, participantId: 'p2', name: 'Winner 2', ffUid: '', ign: '', kills: 3, placementPoints: 9, totalPoints: 15, prizeAmount: 0, qualified: true },
    { rank: 3, participantId: 'p3', name: 'Winner 3', ffUid: '', ign: '', kills: 2, placementPoints: 8, totalPoints: 12, prizeAmount: 0, qualified: true },
    { rank: 4, participantId: 'p4', name: 'Winner 4', ffUid: '', ign: '', kills: 1, placementPoints: 7, totalPoints: 10, prizeAmount: 0, qualified: false },
    { rank: 5, participantId: 'p5', name: 'Winner 5', ffUid: '', ign: '', kills: 0, placementPoints: 6, totalPoints: 8, prizeAmount: 0, qualified: false },
  ]);

  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const unsub = listenTournaments((list) => {
      setTournaments(list);
      if (list.length > 0 && !selectedTournId) {
        setSelectedTournId(list[0].id);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!selectedTournId) {
      setMatches([]);
      setSelectedMatchId('');
      return;
    }

    const unsub = listenTournamentMatches(selectedTournId, (matchList) => {
      setMatches(matchList);
      if (matchList.length > 0 && !selectedMatchId) {
        setSelectedMatchId(matchList[0].id);
      }
    });
    return () => unsub();
  }, [selectedTournId]);

  const selectedTourn = tournaments.find((t) => t.id === selectedTournId);
  const selectedMatch = matches.find((m) => m.id === selectedMatchId);
  const prizePositions = getTournamentPrizePositions(selectedTourn);
  const totalPrizeVal = Number(selectedTourn?.totalPrizeValue) || Number(selectedTourn?.prizePool) || prizePositions.reduce((a, b) => a + b.amount, 0);

  // Apply tournament prize distribution to ranks based on tournament positions
  const handleApplyPrizeDistribution = () => {
    if (!selectedTourn) return;
    const positions = getTournamentPrizePositions(selectedTourn);
    const updated = winners.map((w) => {
      const matchPos = positions.find((p) => p.position === w.rank);
      const prize = matchPos ? matchPos.amount : 0;
      return { ...w, prizeAmount: prize };
    });
    setWinners(updated);
  };

  const handleAddWinnerRow = () => {
    const nextRank = winners.length + 1;
    let prize = 0;
    if (selectedTourn) {
      const matchPos = prizePositions.find((p) => p.position === nextRank);
      if (matchPos) prize = matchPos.amount;
    }
    setWinners([
      ...winners,
      { rank: nextRank, participantId: `p${nextRank}`, name: '', ffUid: '', ign: '', kills: 0, placementPoints: 0, totalPoints: 0, prizeAmount: prize, qualified: false },
    ]);
  };

  const handleRemoveWinnerRow = (idx: number) => {
    setWinners(winners.filter((_, i) => i !== idx));
  };

  const handleUpdateWinner = (index: number, field: keyof ResultWinner, value: any) => {
    const updated = [...winners];
    updated[index] = { ...updated[index], [field]: value };
    setWinners(updated);
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTournId || !selectedMatchId) {
      setFeedback('Please select a tournament and match.');
      return;
    }

    if (winners.length === 0 || !winners[0].ign.trim()) {
      setFeedback('Please fill out at least the #1 rank winner details.');
      return;
    }

    try {
      setLoading(true);
      setFeedback(null);

      await publishMatchResult({
        tournamentId: selectedTournId,
        tournamentTitle: selectedTourn?.title || 'Tournament',
        matchId: selectedMatchId,
        matchName: selectedMatch?.name || 'Match',
        format: selectedTourn?.format || 'SOLO',
        stage,
        winners: winners.filter((w) => w.ign.trim().length > 0),
        notes: notes.trim(),
        publishedBy: userProfile?.displayName || 'Admin',
      });

      setFeedback('MATCH RESULTS PUBLISHED SUCCESSFULLY! Visible on the public Leaderboards.');
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      console.error(err);
      setFeedback(`Publish failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="admin-results-view" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            Match Results & Finalists Advancement Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Input match standings, award kills/points, allocate 1st–5th tournament prizes, mark advancing finalists, and publish official leaderboards
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3.5 rounded-xl bg-orange-950/70 border border-orange-500/40 text-orange-200 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      <form onSubmit={handlePublish} className="space-y-6">
        {/* Tournament & Match Selection */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-slate-900 rounded-2xl border border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Tournament
            </label>
            <select
              value={selectedTournId}
              onChange={(e) => setSelectedTournId(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none"
            >
              {tournaments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.format} • Pool: ₹{t.prizePool.toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Match
            </label>
            <select
              value={selectedMatchId}
              onChange={(e) => setSelectedMatchId(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none"
            >
              {matches.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Tournament Stage
            </label>
            <select
              value={stage}
              onChange={(e) => setStage(e.target.value as MatchStage)}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none"
            >
              <option value="QUALIFIER">Qualifier Match (Top 3 Advance)</option>
              <option value="SEMIFINAL">Semifinal Match</option>
              <option value="FINAL">Grand Final (Prize Winners 1st–5th)</option>
            </select>
          </div>
        </div>

        {/* Selected Tournament Prize Distribution Reference Banner */}
        {selectedTourn && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {isDiamondPrizeType(selectedTourn.prizeType || selectedTourn.rewardType) ? (
                  <Gem className="w-4 h-4 text-cyan-400" />
                ) : (
                  <Gift className="w-4 h-4 text-amber-400" />
                )}
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Tournament Official Rewards: {selectedTourn.title} ({formatPrizeAmount(totalPrizeVal, selectedTourn.prizeType || selectedTourn.rewardType)} • {(selectedTourn.prizeType || selectedTourn.rewardType || 'FREE FIRE DIAMONDS').replace(/_/g, ' ')})
                </span>
              </div>
              <button
                type="button"
                onClick={handleApplyPrizeDistribution}
                className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" /> Auto-Fill Configured Prizes
              </button>
            </div>

            <div className="flex flex-wrap gap-2 text-center text-xs font-mono">
              {prizePositions.map((pos, idx) => (
                <div
                  key={idx}
                  className={`flex-1 min-w-[90px] p-2 rounded-lg border ${
                    pos.position === 1 ? 'bg-amber-950/50 border-amber-500/40' :
                    pos.position === 2 ? 'bg-slate-900 border-slate-700' :
                    pos.position === 3 ? 'bg-orange-950/40 border-orange-500/30' :
                    'bg-slate-900 border-slate-800'
                  }`}
                >
                  <span className="text-[10px] text-amber-400 block font-sans font-bold truncate">
                    {pos.position === 1 ? '🥇 1st Place' : pos.position === 2 ? '🥈 2nd Place' : pos.position === 3 ? '🥉 3rd Place' : `🎖️ #${pos.position}`}
                  </span>
                  <span className="font-extrabold text-white">
                    {formatPrizeAmount(pos.amount, pos.prizeType || selectedTourn.prizeType || selectedTourn.rewardType)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Winners / Standings Table */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Leaderboard & Survivor Standings
            </h3>
            <button
              type="button"
              onClick={handleAddWinnerRow}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold flex items-center gap-1 border border-slate-700 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> Add Player Row
            </button>
          </div>

          <div className="space-y-2.5">
            {winners.map((winner, idx) => (
              <div
                key={idx}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2.5 sm:space-y-0 sm:grid sm:grid-cols-8 sm:gap-2 sm:items-center"
              >
                {/* Mobile top bar with Rank and Actions */}
                <div className="flex sm:hidden items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Rank</span>
                    <input
                      type="number"
                      value={winner.rank}
                      onChange={(e) => handleUpdateWinner(idx, 'rank', Number(e.target.value))}
                      className="w-12 p-1 rounded bg-slate-900 border border-slate-800 text-center font-bold text-amber-400 outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-3">
                    <label className="inline-flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={winner.qualified}
                        onChange={(e) => handleUpdateWinner(idx, 'qualified', e.target.checked)}
                        className="accent-emerald-500 w-3.5 h-3.5"
                      />
                      <span className="text-[11px] font-bold text-emerald-400">Qualify</span>
                    </label>
                    {winners.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveWinnerRow(idx)}
                        className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Desktop Rank input */}
                <div className="hidden sm:block">
                  <label className="block text-[10px] text-slate-500 uppercase">Rank</label>
                  <input
                    type="number"
                    value={winner.rank}
                    onChange={(e) => handleUpdateWinner(idx, 'rank', Number(e.target.value))}
                    className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-center font-bold text-amber-400 outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-1 sm:col-span-2">
                  <label className="block text-[10px] text-slate-500 uppercase">In-Game Name (IGN)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. VIP_SNIPER"
                    value={winner.ign}
                    onChange={(e) => handleUpdateWinner(idx, 'ign', e.target.value)}
                    className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 font-bold text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 uppercase">Free Fire UID</label>
                  <input
                    type="text"
                    placeholder="109283..."
                    value={winner.ffUid}
                    onChange={(e) => handleUpdateWinner(idx, 'ffUid', e.target.value)}
                    className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 font-mono text-slate-300 outline-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 sm:contents">
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase">Kills</label>
                    <input
                      type="number"
                      value={winner.kills}
                      onChange={(e) => handleUpdateWinner(idx, 'kills', Number(e.target.value))}
                      className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-center text-red-400 font-bold outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase">Points</label>
                    <input
                      type="number"
                      value={winner.totalPoints}
                      onChange={(e) => handleUpdateWinner(idx, 'totalPoints', Number(e.target.value))}
                      className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-center text-amber-300 font-bold outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase">Prize (₹)</label>
                    <input
                      type="number"
                      value={winner.prizeAmount || 0}
                      onChange={(e) => handleUpdateWinner(idx, 'prizeAmount', Number(e.target.value))}
                      className="w-full p-1.5 rounded bg-slate-900 border border-slate-800 text-center text-emerald-400 font-bold outline-none"
                    />
                  </div>
                </div>

                {/* Desktop Qualify and Delete */}
                <div className="hidden sm:flex items-center justify-center gap-2 pt-0">
                  <label className="inline-flex items-center gap-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={winner.qualified}
                      onChange={(e) => handleUpdateWinner(idx, 'qualified', e.target.checked)}
                      className="accent-emerald-500"
                    />
                    <span className="text-[10px] font-bold text-emerald-400">Qualify</span>
                  </label>
                  {winners.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveWinnerRow(idx)}
                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Notes & Publish */}
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
            Admin Match Notes
          </label>
          <textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Top 3 qualified for Grand Final. Top 5 winners awarded official tournament prizes."
            className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none resize-none"
          />

          <button
            id="publish-results-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Trophy className="w-4 h-4" />
            )}
            {loading ? 'Publishing Results to Firestore...' : 'PUBLISH MATCH RESULTS & ADVANCE FINALISTS'}
          </button>
        </div>
      </form>
    </div>
  );
};
