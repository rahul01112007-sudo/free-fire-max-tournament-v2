import React, { useState, useEffect } from 'react';
import { 
  Headphones, 
  Search, 
  Filter, 
  MessageSquare, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  User, 
  ShieldCheck, 
  ChevronRight, 
  ArrowLeft,
  X,
  FileText,
  Copy,
  Edit3,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { 
  SupportTicket, 
  SupportCategory, 
  SupportTicketStatus 
} from '../types';
import { 
  listenAllSupportTickets, 
  addTicketMessage, 
  updateTicketStatus 
} from '../services/supportService';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';

export const AdminSupportView: React.FC = () => {
  const { userProfile } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  // Detail Modal / Conversation State
  const [replyMessage, setReplyMessage] = useState<string>('');
  const [adminNotes, setAdminNotes] = useState<string>('');
  const [selectedNewStatus, setSelectedNewStatus] = useState<SupportTicketStatus>('IN REVIEW');
  const [submittingReply, setSubmittingReply] = useState<boolean>(false);
  const [updatingStatus, setUpdatingStatus] = useState<boolean>(false);

  useEffect(() => {
    const unsub = listenAllSupportTickets((list) => {
      setTickets(list);
      if (selectedTicket) {
        const fresh = list.find((t) => t.id === selectedTicket.id);
        if (fresh) {
          setSelectedTicket(fresh);
          setAdminNotes(fresh.adminNotes || '');
          setSelectedNewStatus(fresh.status);
        }
      }
    });
    return () => unsub();
  }, [selectedTicket?.id]);

  const handleSelectTicket = (t: SupportTicket) => {
    setSelectedTicket(t);
    setAdminNotes(t.adminNotes || '');
    setSelectedNewStatus(t.status);
    setReplyMessage('');
  };

  const handleCopyUid = (uid: string) => {
    navigator.clipboard.writeText(uid);
    setCopiedUid(uid);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const handleSendAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyMessage.trim()) return;

    try {
      setSubmittingReply(true);
      await addTicketMessage(
        selectedTicket.id,
        userProfile?.uid || 'admin',
        userProfile?.displayName || 'Tournament Administrator',
        'admin',
        replyMessage.trim(),
        selectedNewStatus
      );
      setReplyMessage('');
    } catch (err) {
      console.error('Error submitting admin reply:', err);
    } finally {
      setSubmittingReply(false);
    }
  };

  const handleSaveStatusAndNotes = async () => {
    if (!selectedTicket) return;

    try {
      setUpdatingStatus(true);
      await updateTicketStatus(
        selectedTicket.id,
        selectedNewStatus,
        adminNotes,
        userProfile?.displayName || 'Tournament Administrator'
      );
    } catch (err) {
      console.error('Error updating ticket status/notes:', err);
    } finally {
      setUpdatingStatus(false);
    }
  };

  const filteredTickets = tickets.filter((t) => {
    if (statusFilter !== 'ALL' && t.status !== statusFilter) return false;
    if (categoryFilter !== 'ALL' && t.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchId = t.ticketId?.toLowerCase().includes(q);
      const matchName = t.playerName?.toLowerCase().includes(q);
      const matchUid = t.freeFireUid?.includes(q);
      const matchSub = t.subject?.toLowerCase().includes(q);
      const matchMsg = t.message?.toLowerCase().includes(q);
      return matchId || matchName || matchUid || matchSub || matchMsg;
    }
    return true;
  });

  const getStatusBadge = (status: SupportTicketStatus) => {
    switch (status) {
      case 'OPEN':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-bold">
            OPEN
          </span>
        );
      case 'IN REVIEW':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] font-bold">
            IN REVIEW
          </span>
        );
      case 'RESOLVED':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
            RESOLVED
          </span>
        );
      case 'CLOSED':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold">
            CLOSED
          </span>
        );
    }
  };

  return (
    <div id="admin-support-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Headphones className="w-6 h-6 text-orange-400" />
            Support Desk & Player Disputes
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Resolve player tickets, anti-cheat disputes, payment verification inquiries, and in-game diamond delivery issues
          </p>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-center">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-slate-400 font-sans block">TOTAL TICKETS</span>
          <span className="text-lg font-black text-white">{tickets.length}</span>
        </div>
        <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30">
          <span className="text-[10px] text-amber-400 font-sans block">OPEN REQUESTS</span>
          <span className="text-lg font-black text-amber-400">
            {tickets.filter((t) => t.status === 'OPEN').length}
          </span>
        </div>
        <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30">
          <span className="text-[10px] text-cyan-400 font-sans block">IN REVIEW</span>
          <span className="text-lg font-black text-cyan-400">
            {tickets.filter((t) => t.status === 'IN REVIEW').length}
          </span>
        </div>
        <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
          <span className="text-[10px] text-emerald-400 font-sans block">RESOLVED</span>
          <span className="text-lg font-black text-emerald-400">
            {tickets.filter((t) => t.status === 'RESOLVED').length}
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <input
            type="text"
            id="admin-support-search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Ticket ID, Player Name, FF UID, Subject..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>

        <div>
          <select
            id="admin-support-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="OPEN">OPEN Only</option>
            <option value="IN REVIEW">IN REVIEW</option>
            <option value="RESOLVED">RESOLVED</option>
            <option value="CLOSED">CLOSED</option>
          </select>
        </div>

        <div>
          <select
            id="admin-support-category-filter"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Categories</option>
            <option value="Tournament Issue">Tournament Issue</option>
            <option value="Match/Room Issue">Match/Room Issue</option>
            <option value="Entry/Payment Issue">Entry/Payment Issue</option>
            <option value="Prize/Reward Issue">Prize/Reward Issue</option>
            <option value="Cheating Report">Cheating Report</option>
            <option value="Account Issue">Account Issue</option>
            <option value="Technical Problem">Technical Problem</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      {/* Selected Ticket Modal / View */}
      {selectedTicket && (
        <div className="rounded-2xl sm:rounded-3xl bg-slate-900 border border-orange-500/40 p-4 sm:p-7 shadow-2xl space-y-6">
          <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-black text-orange-400">
                  {selectedTicket.ticketId}
                </span>
                {getStatusBadge(selectedTicket.status)}
                <span className="text-xs text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {selectedTicket.category}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mt-1">
                {selectedTicket.subject}
              </h3>
            </div>

            <button
              onClick={() => setSelectedTicket(null)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Player & Ticket Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[10px] font-sans">PLAYER NAME</span>
              <span className="text-white font-bold truncate block">{selectedTicket.playerName}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-sans">FREE FIRE UID</span>
              <div className="flex items-center gap-1">
                <span className="text-cyan-400 font-bold">{selectedTicket.freeFireUid || '-'}</span>
                {selectedTicket.freeFireUid && (
                  <button
                    onClick={() => handleCopyUid(selectedTicket.freeFireUid)}
                    className="text-slate-500 hover:text-cyan-400 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                )}
                {copiedUid === selectedTicket.freeFireUid && (
                  <span className="text-[9px] text-emerald-400 font-sans">Copied!</span>
                )}
              </div>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-sans">TOURNAMENT / MATCH</span>
              <span className="text-amber-400 font-sans truncate block">
                {selectedTicket.tournamentTitle || selectedTicket.matchName || 'General Support'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-sans">CREATED TIME</span>
              <span className="text-slate-300">
                {new Date(selectedTicket.createdAt).toLocaleString(undefined, {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>
          </div>

          {/* Conversation Thread */}
          <div className="space-y-3 max-h-[350px] overflow-y-auto p-1 pr-2">
            {selectedTicket.messages?.map((msg, idx) => {
              const isAdmin = msg.senderRole === 'admin';

              return (
                <div
                  key={msg.id || idx}
                  className={`p-3.5 rounded-2xl border ${
                    isAdmin
                      ? 'bg-orange-950/30 border-orange-500/40 ml-4 sm:ml-8'
                      : 'bg-slate-950/80 border-slate-800 mr-4 sm:mr-8'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">
                        {msg.senderName} {isAdmin && <span className="text-orange-400 font-normal text-[10px]">(Staff)</span>}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(msg.createdAt).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {msg.message}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Admin Control Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
            {/* Status & Internal Notes */}
            <div className="space-y-3 p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Manage Ticket Status & Notes
              </h4>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Update Ticket Status</label>
                <select
                  value={selectedNewStatus}
                  onChange={(e) => setSelectedNewStatus(e.target.value as SupportTicketStatus)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none cursor-pointer"
                >
                  <option value="OPEN">OPEN</option>
                  <option value="IN REVIEW">IN REVIEW</option>
                  <option value="RESOLVED">RESOLVED</option>
                  <option value="CLOSED">CLOSED</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Internal Staff Notes (Admin Only)</label>
                <textarea
                  rows={2}
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Private staff notes, anti-cheat decision notes, refund ref..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder:text-slate-600 outline-none resize-none"
                />
              </div>

              <button
                type="button"
                onClick={handleSaveStatusAndNotes}
                disabled={updatingStatus}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                {updatingStatus ? 'Updating Status...' : 'Save Status & Internal Notes'}
              </button>
            </div>

            {/* Official Reply Box */}
            <form onSubmit={handleSendAdminReply} className="space-y-3 p-4 rounded-2xl bg-orange-950/20 border border-orange-500/30">
              <h4 className="text-xs font-bold text-orange-400 uppercase tracking-wider flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5" />
                Reply Directly to Player
              </h4>
              <textarea
                rows={4}
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder="Compose message to the player. They will see this response inside their Support Team portal..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none resize-none"
              />
              <button
                type="submit"
                disabled={submittingReply || !replyMessage.trim()}
                className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-40 text-white text-xs font-extrabold uppercase tracking-wider rounded-xl shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {submittingReply ? 'Sending Response...' : 'Send Response & Update Ticket'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Tickets List Table */}
      {filteredTickets.length === 0 ? (
        <EmptyState
          id="no-admin-tickets-empty"
          title="No support tickets matching filter."
          description="Player questions, dispute tickets and anti-cheat appeals will appear here in real-time."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Ticket ID</th>
                <th className="py-3 px-3">Player & Free Fire UID</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-4">Subject & Latest Message</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Created</th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredTickets.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-bold text-orange-400 font-mono">
                    {t.ticketId}
                  </td>
                  <td className="py-3 px-3 font-sans">
                    <div className="font-bold text-white">{t.playerName}</div>
                    <div className="text-[11px] text-cyan-400 font-mono">
                      UID: {t.freeFireUid || '-'}
                    </div>
                  </td>
                  <td className="py-3 px-3 font-sans">
                    <span className="text-[11px] text-slate-300 font-medium bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {t.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans max-w-xs">
                    <div className="font-semibold text-slate-200 truncate">{t.subject}</div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      {t.messages?.[t.messages.length - 1]?.message || t.message}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-center">
                    {getStatusBadge(t.status)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400 text-[11px] font-sans">
                    {new Date(t.createdAt).toLocaleString(undefined, {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => handleSelectTicket(t)}
                      className="px-3 py-1 rounded-lg bg-orange-600/20 hover:bg-orange-600 text-orange-400 hover:text-white border border-orange-500/30 text-xs font-bold font-sans transition-colors cursor-pointer"
                    >
                      Open & Reply
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
