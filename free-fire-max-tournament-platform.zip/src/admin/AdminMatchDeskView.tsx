import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  Key, 
  Lock, 
  Unlock, 
  Save, 
  Users, 
  User, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Send,
  Eye,
  Phone,
  DollarSign
} from 'lucide-react';
import { Tournament, TournamentMatch, Registration, RoomCredentials, formatRegistrationEntryTicket, formatTournamentEntryBadge, formatPrizeAmount } from '../types';
import { listenTournaments } from '../services/tournamentService';
import { listenTournamentMatches, updateMatchStatus, updateMatchDetails } from '../services/matchService';
import { listenMatchRegistrations } from '../services/registrationService';
import { 
  saveRoomCredentials, 
  releaseRoomCredentials, 
  lockRoomCredentials, 
  listenRoomCredentials 
} from '../services/roomService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const AdminMatchDeskView: React.FC = () => {
  const { userProfile } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournId, setSelectedTournId] = useState<string>('');
  const [matches, setMatches] = useState<TournamentMatch[]>([]);
  const [selectedMatchId, setSelectedMatchId] = useState<string>('');
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [roomData, setRoomData] = useState<RoomCredentials | null>(null);

  // Form states for Room Credentials
  const [roomIdInput, setRoomIdInput] = useState('');
  const [roomPassInput, setRoomPassInput] = useState('');
  const [customRulesInput, setCustomRulesInput] = useState('');
  const [savingRoom, setSavingRoom] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // 1. Listen to tournaments
  useEffect(() => {
    const unsub = listenTournaments((list) => {
      setTournaments(list);
      if (list.length > 0 && !selectedTournId) {
        setSelectedTournId(list[0].id);
      }
    });
    return () => unsub();
  }, []);

  // 2. Listen to matches for selected tournament
  useEffect(() => {
    if (!selectedTournId) {
      setMatches([]);
      setSelectedMatchId('');
      return;
    }

    const unsub = listenTournamentMatches(selectedTournId, (matchList) => {
      setMatches(matchList);
      if (matchList.length > 0) {
        // Keep selection if exists, else select first
        if (!selectedMatchId || !matchList.some((m) => m.id === selectedMatchId)) {
          setSelectedMatchId(matchList[0].id);
        }
      } else {
        setSelectedMatchId('');
      }
    });

    return () => unsub();
  }, [selectedTournId]);

  // 3. Listen to registrations for selected match
  useEffect(() => {
    if (!selectedMatchId) {
      setRegistrations([]);
      return;
    }

    const unsub = listenMatchRegistrations(selectedMatchId, (regList) => {
      setRegistrations(regList);
    });

    return () => unsub();
  }, [selectedMatchId]);

  // 4. Listen to room credentials for selected match
  useEffect(() => {
    if (!selectedMatchId) {
      setRoomData(null);
      setRoomIdInput('');
      setRoomPassInput('');
      setCustomRulesInput('');
      return;
    }

    const unsub = listenRoomCredentials(selectedMatchId, (data) => {
      setRoomData(data);
      if (data) {
        setRoomIdInput(data.roomId || '');
        setRoomPassInput(data.roomPassword || '');
        setCustomRulesInput(data.customRules || '');
      }
    });

    return () => unsub();
  }, [selectedMatchId]);

  const selectedTourn = tournaments.find((t) => t.id === selectedTournId);
  const selectedMatch = matches.find((m) => m.id === selectedMatchId);

  const handleSaveCredentials = async () => {
    if (!selectedMatchId || !selectedTournId) return;

    try {
      setSavingRoom(true);
      setFeedback(null);
      await saveRoomCredentials({
        matchId: selectedMatchId,
        tournamentId: selectedTournId,
        matchName: selectedMatch?.name,
        roomId: roomIdInput,
        roomPassword: roomPassInput,
        customRules: customRulesInput,
        adminName: userProfile?.displayName || 'Admin',
      });
      setFeedback('Room credentials saved successfully to Firestore!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (e: any) {
      console.error(e);
      setFeedback(`Error: ${e.message}`);
    } finally {
      setSavingRoom(false);
    }
  };

  const handleReleaseRoom = async () => {
    if (!selectedMatchId) return;
    if (!roomIdInput.trim() || !roomPassInput.trim()) {
      setFeedback('Please enter and save Room ID & Password before releasing to players.');
      return;
    }

    try {
      setSavingRoom(true);
      await saveRoomCredentials({
        matchId: selectedMatchId,
        tournamentId: selectedTournId,
        matchName: selectedMatch?.name,
        roomId: roomIdInput,
        roomPassword: roomPassInput,
        customRules: customRulesInput,
        adminName: userProfile?.displayName || 'Admin',
      });
      await releaseRoomCredentials(selectedMatchId, userProfile?.displayName || 'Admin');
      setFeedback('ROOM RELEASED LIVE! All registered players can now see the Room ID & Password.');
      setTimeout(() => setFeedback(null), 4000);
    } catch (e: any) {
      console.error(e);
      setFeedback(`Error releasing room: ${e.message}`);
    } finally {
      setSavingRoom(false);
    }
  };

  const handleLockRoom = async () => {
    if (!selectedMatchId) return;
    try {
      setSavingRoom(true);
      await lockRoomCredentials(selectedMatchId, userProfile?.displayName || 'Admin');
      setFeedback('Room locked. Credentials are now hidden from players.');
      setTimeout(() => setFeedback(null), 3000);
    } catch (e: any) {
      console.error(e);
    } finally {
      setSavingRoom(false);
    }
  };

  const handleStatusChange = async (newStatus: any) => {
    if (!selectedMatchId) return;
    await updateMatchStatus(selectedMatchId, newStatus);
  };

  return (
    <div id="admin-match-desk-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Key className="w-6 h-6 text-orange-400" />
            Admin Match Desk & Custom Room Dispatch
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage real tournament qualifier matches, seat maps, and realtime custom room credentials
          </p>
        </div>
      </div>

      {/* 1. Tournament Selector */}
      {tournaments.length === 0 ? (
        <EmptyState
          id="no-tournaments-match-desk"
          title="No tournaments found."
          description="Create a tournament first from the Admin Dashboard or Tournament Desk to begin assigning matches and seats."
        />
      ) : (
        <div className="space-y-6">
          <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
              1. Select Active Tournament
            </label>
            <select
              id="admin-match-desk-tourn-select"
              value={selectedTournId}
              onChange={(e) => setSelectedTournId(e.target.value)}
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-sm font-semibold text-white outline-none"
            >
              {tournaments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.format} • {t.registeredCount}/{t.maxParticipants} Registered)
                </option>
              ))}
            </select>
          </div>

          {/* 2. Match Selector Bar */}
          {matches.length > 0 && (
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                2. Select Qualifier / Final Match
              </label>
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
                {matches.map((m) => {
                  const isSelected = m.id === selectedMatchId;
                  const isLocked = m.status === 'LOCKED';
                  const isRoomLive = m.roomStatus === 'RELEASED';

                  return (
                    <button
                      key={m.id}
                      id={`match-btn-${m.id}`}
                      onClick={() => setSelectedMatchId(m.id)}
                      className={`shrink-0 px-4 py-2.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-orange-950/60 border-orange-500 text-white ring-1 ring-orange-500/50'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-white">
                          {m.name}
                        </span>
                        {isRoomLive && (
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[11px]">
                        <span className="font-mono font-bold text-amber-400">
                          {m.currentCount} / {m.capacity}
                        </span>
                        <StatusBadge status={m.status} className="text-[9px] py-0 px-1.5" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {selectedMatch && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: CUSTOM ROOM CREDENTIALS DESK */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-orange-600/20 text-orange-400 flex items-center justify-center">
                      <Key className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        CUSTOM ROOM CREDENTIALS
                      </h3>
                      <span className="text-[11px] text-slate-400">
                        {selectedMatch.name}
                      </span>
                    </div>
                  </div>

                  <StatusBadge 
                    status={roomData?.status === 'RELEASED' ? 'RELEASED' : 'ROOM_LOCKED'} 
                  />
                </div>

                {feedback && (
                  <div className="p-3 rounded-xl bg-orange-950/60 border border-orange-500/40 text-orange-200 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{feedback}</span>
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                      Free Fire Room ID
                    </label>
                    <input
                      id="admin-room-id-input"
                      type="text"
                      value={roomIdInput}
                      onChange={(e) => setRoomIdInput(e.target.value)}
                      placeholder="e.g. 7829104"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-sm font-mono font-bold text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                      Room Password
                    </label>
                    <input
                      id="admin-room-pass-input"
                      type="text"
                      value={roomPassInput}
                      onChange={(e) => setRoomPassInput(e.target.value)}
                      placeholder="e.g. 9988"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-sm font-mono font-bold text-amber-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                      Room Joining Rules / Notes
                    </label>
                    <textarea
                      id="admin-room-rules-input"
                      rows={2}
                      value={customRulesInput}
                      onChange={(e) => setCustomRulesInput(e.target.value)}
                      placeholder="No emulator, No hack, Default gun attributes."
                      className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none resize-none"
                    />
                  </div>

                  {/* Room Actions */}
                  <div className="space-y-2 pt-2">
                    <button
                      id="admin-save-room-btn"
                      disabled={savingRoom}
                      onClick={handleSaveCredentials}
                      className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-700 transition-all flex items-center justify-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5" />
                      SAVE ROOM CREDENTIALS
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        id="admin-release-room-btn"
                        disabled={savingRoom}
                        onClick={handleReleaseRoom}
                        className="py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-1.5"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        RELEASE ROOM
                      </button>

                      <button
                        id="admin-lock-room-btn"
                        disabled={savingRoom}
                        onClick={handleLockRoom}
                        className="py-2.5 bg-slate-950 hover:bg-slate-800 disabled:opacity-50 text-slate-300 font-bold rounded-xl text-xs uppercase tracking-wider border border-slate-800 transition-all flex items-center justify-center gap-1.5"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        LOCK ROOM
                      </button>
                    </div>
                  </div>
                </div>

                {/* Match Status Controller */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Match Operational Status
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {['WAITING', 'ACTIVE', 'FULL', 'LOCKED', 'COMPLETED'].map((st) => (
                      <button
                        key={st}
                        onClick={() => handleStatusChange(st)}
                        className={`py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all ${
                          selectedMatch.status === st
                            ? 'bg-orange-600 text-white'
                            : 'bg-slate-900 text-slate-400 hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right 2 Columns: REAL SEAT MAP & ALLOCATED PLAYERS */}
              <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Users className="w-4 h-4 text-amber-400" />
                      Live Allocated Seats ({registrations.length} / {selectedMatch.capacity})
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Realtime Firestore seat allocations matching player verification desks
                    </p>
                  </div>

                  <span className="text-xs font-mono font-bold text-orange-400 bg-orange-600/10 px-3 py-1 rounded-full border border-orange-500/30">
                    {selectedMatch.capacity - registrations.length} Seats Vacant
                  </span>
                </div>

                {/* Player Seat Table */}
                {registrations.length === 0 ? (
                  <EmptyState
                    id="no-registrations-for-match"
                    title="No players allocated to this match yet."
                    description="As players or squad teams register in this tournament, the system automatically fills seats sequentially in real-time."
                  />
                ) : (
                  <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 bg-slate-900/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          <th className="py-2.5 px-3 w-16 text-center">Seat #</th>
                          <th className="py-2.5 px-3">Player / Squad</th>
                          <th className="py-2.5 px-3">Free Fire UID</th>
                          <th className="py-2.5 px-3">IGN</th>
                          <th className="py-2.5 px-3">Contact</th>
                          <th className="py-2.5 px-3">Entry / Ticket</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono">
                        {registrations.map((reg) => (
                          <tr key={reg.id} className="hover:bg-slate-900/60 transition-colors">
                            <td className="py-2.5 px-3 text-center">
                              <span className="inline-block px-2 py-0.5 rounded bg-orange-600/20 text-orange-400 font-extrabold border border-orange-500/30">
                                #{reg.seatNumber}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-sans font-bold text-white">
                              {reg.format === 'SOLO' ? reg.playerName : reg.teamName}
                            </td>
                            <td className="py-2.5 px-3 text-slate-300">
                              {reg.freeFireUid}
                            </td>
                            <td className="py-2.5 px-3 text-amber-400 font-sans font-semibold">
                              {reg.ign}
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                              {reg.phone}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-900 text-slate-200 border border-slate-700 text-[10px] font-sans font-bold">
                                {formatRegistrationEntryTicket(reg, selectedTourn)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
