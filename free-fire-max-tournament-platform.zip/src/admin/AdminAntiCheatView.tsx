import React, { useState, useEffect } from 'react';
import { ShieldAlert, CheckCircle2, XCircle, AlertTriangle, ExternalLink, Ban, UserX } from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { AntiCheatReport, ReportStatus } from '../types';
import { updateReportStatus } from '../services/antiCheatService';
import { banPlayer } from '../services/authService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const AdminAntiCheatView: React.FC = () => {
  const { userProfile } = useAuth();
  const [reports, setReports] = useState<AntiCheatReport[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'antiCheatReports'), orderBy('createdAt', 'desc')),
      (snap) => {
        const list: AntiCheatReport[] = [];
        snap.forEach((d) => list.push(d.data() as AntiCheatReport));
        setReports(list);
      }
    );
    return () => unsub();
  }, []);

  const handleUpdateStatus = async (reportId: string, status: ReportStatus) => {
    const notes = window.prompt('Admin resolution notes:', 'Report reviewed by admin desk.');
    if (notes === null) return;

    try {
      setProcessingId(reportId);
      await updateReportStatus(reportId, status, notes, userProfile?.displayName || 'Admin');
    } catch (e) {
      console.error(e);
    } finally {
      setProcessingId(null);
    }
  };

  const handleBanReportedPlayer = async (report: AntiCheatReport) => {
    const reason = window.prompt(`Confirm ban for player "${report.suspectIgn || report.suspectFfUid}":`, `Cheating violation reported in ${report.matchName}`);
    if (reason === null) return;

    try {
      setProcessingId(report.id);
      // Update report status
      await updateReportStatus(report.id, 'BANNED', `Player banned by ${userProfile?.displayName || 'Admin'} for: ${reason}`, userProfile?.displayName || 'Admin');
      alert(`Player ${report.suspectIgn || report.suspectFfUid} marked as banned in anti-cheat desk.`);
    } catch (e) {
      console.error(e);
    } finally {
      setProcessingId(null);
    }
  };

  const filteredReports = reports.filter((r) => {
    if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
    return true;
  });

  return (
    <div id="admin-anticheat-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-red-500" />
            Anti-Cheat & Fair Play Investigation Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit player rule violations, headshot aimbot video proof links, and enforce competitive bans
          </p>
        </div>

        <select
          id="anticheat-status-filter"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none"
        >
          <option value="ALL">All Reports ({reports.length})</option>
          <option value="PENDING">PENDING</option>
          <option value="UNDER_REVIEW">UNDER REVIEW</option>
          <option value="BANNED">BANNED</option>
          <option value="DISMISSED">DISMISSED</option>
        </select>
      </div>

      {filteredReports.length === 0 ? (
        <EmptyState
          id="no-anticheat-reports"
          title="No anti-cheat reports found."
          description="Reports filed by players regarding suspected hackers or emulator usage will appear here for investigation."
        />
      ) : (
        <div className="space-y-4">
          {filteredReports.map((report) => (
            <div
              key={report.id}
              id={`report-card-${report.id}`}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-red-950 text-red-400 border border-red-800">
                      {report.reason.replace('_', ' ')}
                    </span>
                    <StatusBadge status={report.status} />
                  </div>
                  <h3 className="text-sm font-bold text-white">
                    Suspect: <span className="text-red-400">{report.suspectIgn || 'Unknown IGN'}</span> (UID: {report.suspectFfUid})
                  </h3>
                  <p className="text-xs text-slate-400">
                    Match: {report.matchName} • {report.tournamentTitle}
                  </p>
                </div>

                <div className="text-right text-xs text-slate-400 font-mono">
                  Reported by: <span className="text-slate-200">{report.reporterName || 'Player'}</span>
                  <span className="block text-[10px] text-slate-500">
                    {new Date(report.createdAt).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs text-slate-300">
                <span className="font-semibold text-slate-200 block mb-1">Reporter Testimony:</span>
                {report.description}
              </div>

              {/* Evidence Link */}
              {report.evidenceUrl && (
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400 font-semibold">Video Evidence:</span>
                  <a
                    href={report.evidenceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-orange-400 hover:text-orange-300 font-semibold inline-flex items-center gap-1"
                  >
                    Open Clip / Drive Link <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              {report.adminNotes && (
                <div className="p-2.5 rounded-lg bg-orange-950/30 border border-orange-500/30 text-xs text-orange-200">
                  <span className="font-bold text-orange-400">Admin Notes:</span> {report.adminNotes}
                </div>
              )}

              {/* Actions Bar */}
              <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    disabled={processingId === report.id}
                    onClick={() => handleUpdateStatus(report.id, 'UNDER_REVIEW')}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700 transition-all"
                  >
                    Mark Under Review
                  </button>
                  <button
                    disabled={processingId === report.id}
                    onClick={() => handleUpdateStatus(report.id, 'DISMISSED')}
                    className="px-3 py-1.5 bg-slate-950 hover:bg-slate-800 text-slate-400 rounded-lg text-xs font-semibold border border-slate-800 transition-all"
                  >
                    Dismiss (False Alarm)
                  </button>
                </div>

                <button
                  id={`ban-suspect-btn-${report.id}`}
                  disabled={processingId === report.id}
                  onClick={() => handleBanReportedPlayer(report)}
                  className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-red-600/30 transition-all"
                >
                  <Ban className="w-3.5 h-3.5" />
                  BAN SUSPECT PLAYER
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
