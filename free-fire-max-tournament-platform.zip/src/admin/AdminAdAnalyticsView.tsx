import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  BarChart3, 
  Ticket, 
  CheckCircle2, 
  Clock, 
  Users, 
  Trophy, 
  TrendingUp, 
  ShieldCheck, 
  Sliders,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase/config';
import { AdEntryProgress, Tournament } from '../types';
import { listenTournaments } from '../services/tournamentService';
import { EmptyState } from '../components/EmptyState';

export const AdminAdAnalyticsView: React.FC = () => {
  const [adProgressList, setAdProgressList] = useState<AdEntryProgress[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);

  // Configurable eCPM for estimated ad revenue (Clearly marked ESTIMATE ONLY)
  const [ecpmEstimateUsd, setEcpmEstimateUsd] = useState<number>(3.5); // $3.50 per 1000 ads
  const [usdToInrRate, setUsdToInrRate] = useState<number>(85); // 1 USD = 85 INR

  useEffect(() => {
    // Listen to all adEntryProgress documents in Firestore
    const unsubAd = onSnapshot(
      collection(db, 'adEntryProgress'),
      (snap) => {
        const list: AdEntryProgress[] = [];
        snap.forEach((doc) => {
          list.push(doc.data() as AdEntryProgress);
        });
        setAdProgressList(list);
        setLoading(false);
      },
      (err) => {
        console.warn('Ad progress listener notice:', err.message);
        setLoading(false);
      }
    );

    const unsubTourn = listenTournaments((list) => {
      setTournaments(list);
    });

    return () => {
      unsubAd();
      unsubTourn();
    };
  }, []);

  // Compute Live Metrics from adEntryProgress
  const totalVerifiedAds = adProgressList.reduce((acc, p) => acc + (p.adsCompleted || 0), 0);
  const totalTicketsUnlocked = adProgressList.filter((p) => p.entryUnlocked || (p.adsCompleted || 0) >= (p.adsRequired || 5)).length;
  const totalTicketsUsed = adProgressList.filter((p) => p.ticketStatus === 'USED').length;
  const activeUnusedTickets = totalTicketsUnlocked - totalTicketsUsed;
  const unfinishedSessions = adProgressList.filter((p) => !p.entryUnlocked && (p.adsCompleted || 0) < (p.adsRequired || 5)).length;

  // Estimated Revenue Calculation: (Total Ads / 1000) * eCPM
  const estimatedRevenueUsd = (totalVerifiedAds / 1000) * ecpmEstimateUsd;
  const estimatedRevenueInr = estimatedRevenueUsd * usdToInrRate;

  // Group by Tournament
  const tournMap: Record<string, { title: string; totalAds: number; completedCount: number; usedCount: number }> = {};
  tournaments.forEach((t) => {
    tournMap[t.id] = { title: t.title, totalAds: 0, completedCount: 0, usedCount: 0 };
  });

  adProgressList.forEach((p) => {
    if (!tournMap[p.tournamentId]) {
      tournMap[p.tournamentId] = {
        title: `Tournament #${p.tournamentId.substring(0, 6)}`,
        totalAds: 0,
        completedCount: 0,
        usedCount: 0,
      };
    }
    tournMap[p.tournamentId].totalAds += p.adsCompleted || 0;
    if (p.entryUnlocked || (p.adsCompleted || 0) >= (p.adsRequired || 5)) {
      tournMap[p.tournamentId].completedCount += 1;
    }
    if (p.ticketStatus === 'USED') {
      tournMap[p.tournamentId].usedCount += 1;
    }
  });

  return (
    <div id="admin-ad-analytics-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Tv className="w-6 h-6 text-orange-400" />
            Rewarded Ad Economics & Entry Analytics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time verification metrics, 5-ad entry unlock rate, ticket lifecycle & simulated ad network yield
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-orange-950/60 border border-orange-500/40 text-xs text-orange-300 font-bold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-orange-400" />
            Anti-Fraud SSV Verified
          </span>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Total Verified Ads
          </span>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono flex items-center gap-2">
            <Tv className="w-6 h-6 text-orange-400" />
            {totalVerifiedAds.toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 block">
            Completed rewarded ad impressions
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Tickets Generated (5 Ads)
          </span>
          <div className="text-2xl sm:text-3xl font-black text-amber-400 font-mono flex items-center gap-2">
            <Ticket className="w-6 h-6 text-amber-400" />
            {totalTicketsUnlocked}
          </div>
          <span className="text-[10px] text-slate-500 block">
            {activeUnusedTickets} active & ready to register
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            Tickets Consumed
          </span>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            {totalTicketsUsed}
          </div>
          <span className="text-[10px] text-slate-500 block">
            1 ticket = 1 tournament seat
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            In-Progress Ad Flows
          </span>
          <div className="text-2xl sm:text-3xl font-black text-slate-300 font-mono flex items-center gap-2">
            <Clock className="w-6 h-6 text-blue-400" />
            {unfinishedSessions}
          </div>
          <span className="text-[10px] text-slate-500 block">
            Players currently at 1..4 ads watched
          </span>
        </div>
      </div>

      {/* Configurable Ad Revenue Estimator Box (ESTIMATE ONLY) */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Configurable Ad Network Revenue Modeling
              </h3>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black">
                ESTIMATE ONLY
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live estimated ad revenue based on your Google AdMob / Unity Ads configured average eCPM rate.
            </p>
          </div>

          <div className="text-left sm:text-right">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block">
              Estimated Total Ad Yield
            </span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">
              ₹{estimatedRevenueInr.toFixed(2)}{' '}
              <span className="text-xs font-semibold text-slate-400 font-sans">
                (${estimatedRevenueUsd.toFixed(2)} USD)
              </span>
            </span>
          </div>
        </div>

        {/* eCPM Rate Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-1 text-xs">
          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold block flex items-center justify-between">
              <span>Configurable Network eCPM ($):</span>
              <span className="font-mono text-orange-400 font-bold">${ecpmEstimateUsd.toFixed(2)}</span>
            </label>
            <input
              type="range"
              min="0.5"
              max="15.0"
              step="0.1"
              value={ecpmEstimateUsd}
              onChange={(e) => setEcpmEstimateUsd(parseFloat(e.target.value))}
              className="w-full accent-orange-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">
              Typical Rewarded Video eCPM: $2.50 – $6.00
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold block flex items-center justify-between">
              <span>Exchange Rate (1 USD to INR):</span>
              <span className="font-mono text-emerald-400 font-bold">₹{usdToInrRate}</span>
            </label>
            <input
              type="range"
              min="75"
              max="95"
              step="1"
              value={usdToInrRate}
              onChange={(e) => setUsdToInrRate(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">
              Calculates gross INR earnings for organizer prize budgeting
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
              Per-Player Unlock Value
            </span>
            <div className="text-base font-extrabold text-white font-mono">
              ₹{((5 / 1000) * ecpmEstimateUsd * usdToInrRate).toFixed(2)}{' '}
              <span className="text-[11px] text-slate-400 font-sans font-normal">(for 5 ads)</span>
            </div>
            <span className="text-[9px] text-slate-500 block">
              Assists organizer in determining healthy tournament prize pools.
            </span>
          </div>
        </div>
      </div>

      {/* Tournament Ad Breakdown Table */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Trophy className="w-4 h-4 text-orange-400" />
          Rewarded Ads Breakdown by Tournament
        </h3>

        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Tournament</th>
                <th className="py-3 px-3 text-center">Verified Ads Watched</th>
                <th className="py-3 px-3 text-center">Tickets Unlocked</th>
                <th className="py-3 px-3 text-center">Tickets Used</th>
                <th className="py-3 px-4 text-right">Est. Ad Revenue</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {Object.entries(tournMap).map(([tournId, item]) => {
                const tournRev = ((item.totalAds / 1000) * ecpmEstimateUsd * usdToInrRate).toFixed(2);
                return (
                  <tr key={tournId} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-sans font-bold text-white">
                      {item.title}
                    </td>
                    <td className="py-3 px-3 text-center text-orange-400 font-bold text-sm">
                      {item.totalAds}
                    </td>
                    <td className="py-3 px-3 text-center text-amber-400 font-bold">
                      {item.completedCount}
                    </td>
                    <td className="py-3 px-3 text-center text-emerald-400 font-bold">
                      {item.usedCount}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-400 font-extrabold">
                      ₹{tournRev}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
