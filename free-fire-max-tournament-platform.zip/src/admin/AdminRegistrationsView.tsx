import React, { useState, useEffect } from 'react';
import { 
  ClipboardList, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Filter, 
  User, 
  Users, 
  Check, 
  X, 
  Phone, 
  Gamepad2, 
  ExternalLink, 
  Ticket, 
  Tv, 
  Gem, 
  DollarSign, 
  Copy, 
  Clock, 
  CreditCard,
  KeyRound,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Registration, Tournament } from '../types';
import { listenTournaments } from '../services/tournamentService';
import { 
  confirmPlayerPayment, 
  rejectPlayerPayment, 
  getPaymentRestrictions 
} from '../services/paymentService';
import { Modal } from '../components/Modal';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const AdminRegistrationsView: React.FC = () => {
  const { userProfile } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournId, setSelectedTournId] = useState<string>('ALL');
  const [formatFilter, setFormatFilter] = useState<'ALL' | 'SOLO' | 'SQUAD'>('ALL');
  const [entryTypeFilter, setEntryTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Security Confirmation Modal for Roster Desk
  const [confirmTargetReg, setConfirmTargetReg] = useState<Registration | null>(null);
  const [securityPinInput, setSecurityPinInput] = useState('');
  const [certChecked, setCertChecked] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);

  useEffect(() => {
    const unsubRegs = onSnapshot(
      query(collection(db, 'registrations'), orderBy('createdAt', 'desc')),
      (snap) => {
        const list: Registration[] = [];
        snap.forEach((d) => list.push(d.data() as Registration));
        setRegistrations(list);
      }
    );

    const unsubTourn = listenTournaments((list) => {
      setTournaments(list);
    });

    return () => {
      unsubRegs();
      unsubTourn();
    };
  }, []);

  const handleCopyUid = (uid: string) => {
    navigator.clipboard.writeText(uid);
    setCopiedUid(uid);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const handleInitiateConfirm = (reg: Registration) => {
    const restrictions = getPaymentRestrictions();
    if (restrictions.requireSecurityPin || restrictions.requireBankStatementCheckbox) {
      setConfirmTargetReg(reg);
      setSecurityPinInput('');
      setCertChecked(false);
      setModalError(null);
    } else {
      executeQuickConfirm(reg.id);
    }
  };

  const executeQuickConfirm = async (regId: string) => {
    try {
      setProcessingId(regId);
      const adminName = userProfile?.displayName || 'Admin Desk';
      await confirmPlayerPayment(regId, adminName, 'Confirmed via Roster Desk');
      setConfirmTargetReg(null);
    } catch (err: any) {
      console.error(err);
      setModalError(err.message || 'Failed to confirm payment.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleModalConfirmSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmTargetReg) return;
    const restrictions = getPaymentRestrictions();

    if (restrictions.requireBankStatementCheckbox && !certChecked) {
      setModalError('Please check the bank verification certification box.');
      return;
    }

    if (restrictions.requireSecurityPin) {
      if (!securityPinInput.trim()) {
        setModalError('Please enter the Admin Security PIN.');
        return;
      }
      if (securityPinInput.trim() !== restrictions.securityPin.trim()) {
        setModalError('Incorrect Admin Security PIN.');
        return;
      }
    }

    await executeQuickConfirm(confirmTargetReg.id);
  };

  const handleQuickReject = async (regId: string) => {
    try {
      setProcessingId(regId);
      const adminName = userProfile?.displayName || 'Admin Desk';
      await rejectPlayerPayment(regId, adminName, 'Rejected via Roster Desk');
    } catch (err) {
      console.error(err);
    } finally {
      setProcessingId(null);
    }
  };

  const filteredRegistrations = registrations.filter((reg) => {
    if (selectedTournId !== 'ALL' && reg.tournamentId !== selectedTournId) return false;
    if (formatFilter !== 'ALL' && reg.format !== formatFilter) return false;
    if (entryTypeFilter !== 'ALL') {
      const regEntryType = reg.entryType || (reg.entryFeePaid && reg.entryFeePaid > 0 ? 'PAID_IN_GAME' : 'FREE_ADS');
      if (regEntryType !== entryTypeFilter) return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = reg.playerName?.toLowerCase().includes(q);
      const matchIgn = reg.ign?.toLowerCase().includes(q);
      const matchUid = reg.freeFireUid?.includes(q);
      const matchTeam = reg.teamName?.toLowerCase().includes(q);
      const matchTxn = reg.paymentTransactionId?.toLowerCase().includes(q) || reg.utrNumber?.toLowerCase().includes(q);
      return matchName || matchIgn || matchUid || matchTeam || matchTxn;
    }
    return true;
  });

  return (
    <div id="admin-registrations-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <ClipboardList className="w-6 h-6 text-orange-400" />
            Roster & Tournament Entries Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit player Free Fire UID snapshots, seat allocation numbers, paid entry transactions, and rewarded-ad ticket admissions
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="sm:col-span-1">
          <input
            id="admin-reg-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Player IGN, FF UID, Team, Txn ID..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>

        <div>
          <select
            id="admin-reg-tourn-filter"
            value={selectedTournId}
            onChange={(e) => setSelectedTournId(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Tournaments</option>
            {tournaments.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} ({t.format})
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            id="admin-reg-entry-type-filter"
            value={entryTypeFilter}
            onChange={(e) => setEntryTypeFilter(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Entry Models</option>
            <option value="PAID_IN_GAME">Paid Entry (In-Game Rewards)</option>
            <option value="FREE_ADS">Free (5 Rewarded Ads)</option>
            <option value="FREE_IN_GAME">Free In-Game Diamonds</option>
          </select>
        </div>

        <div>
          <select
            id="admin-reg-format-filter"
            value={formatFilter}
            onChange={(e) => setFormatFilter(e.target.value as any)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Formats (Solo & Squad)</option>
            <option value="SOLO">Solo Entries Only</option>
            <option value="SQUAD">Squad Entries Only</option>
          </select>
        </div>
      </div>

      {/* Registrations Table */}
      {filteredRegistrations.length === 0 ? (
        <EmptyState
          id="no-registrations-admin-empty"
          title="No registrations found."
          description="Player and squad registrations unlocked via 5-ad tickets or paid entries will appear here with automatic seat allocations."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Player / Squad & UID Snapshot</th>
                <th className="py-3 px-3">Tournament</th>
                <th className="py-3 px-3">Allocated Match</th>
                <th className="py-3 px-3 text-center">Seat / Slot #</th>
                <th className="py-3 px-3">Entry & Payment Verification</th>
                <th className="py-3 px-4 text-right">Registration Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredRegistrations.map((reg) => {
                const regEntryType = reg.entryType || (reg.entryFeePaid && reg.entryFeePaid > 0 ? 'PAID_IN_GAME' : 'FREE_ADS');
                const isPaid = regEntryType === 'PAID_IN_GAME';
                const paymentStatus = reg.paymentStatus || 'PENDING';
                const isPendingPaid = isPaid && paymentStatus === 'PENDING';

                return (
                  <tr key={reg.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-sans font-bold text-white leading-tight">
                        {reg.format === 'SOLO' ? reg.playerName : reg.teamName}
                      </div>
                      <div className="text-[11px] text-amber-400 font-sans">
                        IGN: {reg.ign}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>FF UID: <strong className="text-cyan-400 font-mono">{reg.freeFireUid}</strong></span>
                        {reg.freeFireUid && (
                          <button
                            type="button"
                            onClick={() => handleCopyUid(reg.freeFireUid)}
                            className="p-0.5 rounded text-slate-500 hover:text-cyan-300 cursor-pointer"
                            title="Copy UID"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        )}
                        {copiedUid === reg.freeFireUid && (
                          <span className="text-[9px] text-emerald-400 font-sans">Copied!</span>
                        )}
                      </div>
                      {reg.phone && (
                        <div className="text-[10px] text-slate-500 font-sans">
                          Phone: {reg.phone}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <span className="font-semibold text-slate-200 block truncate max-w-[180px]">
                        {reg.tournamentTitle}
                      </span>
                      <StatusBadge status={reg.format} className="text-[9px] py-0 mt-0.5" />
                    </td>

                    <td className="py-3 px-3 font-sans font-semibold text-orange-400">
                      {reg.matchName}
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className="inline-block px-2.5 py-0.5 rounded bg-orange-600/20 text-orange-400 font-bold border border-orange-500/30">
                        #{reg.seatNumber}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      {isPaid ? (
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold text-[10px]">
                              <Gem className="w-3 h-3 text-cyan-400" />
                              PAID (₹{reg.entryFeePaid || 50})
                            </span>
                            {paymentStatus === 'VERIFIED' && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold">
                                <CheckCircle2 className="w-2.5 h-2.5" /> VERIFIED
                              </span>
                            )}
                            {paymentStatus === 'PENDING' && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[9px] font-bold">
                                <Clock className="w-2.5 h-2.5" /> PENDING
                              </span>
                            )}
                            {paymentStatus === 'REJECTED' && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[9px] font-bold">
                                <XCircle className="w-2.5 h-2.5" /> REJECTED
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block truncate max-w-[150px]">
                            UTR: {reg.paymentTransactionId || reg.utrNumber || 'Verified'}
                          </span>

                          {/* Quick Admin Action if Pending */}
                          {isPendingPaid && (
                            <div className="flex items-center gap-1 pt-1">
                              <button
                                type="button"
                                disabled={processingId === reg.id}
                                onClick={() => handleInitiateConfirm(reg)}
                                className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] flex items-center gap-0.5 cursor-pointer disabled:opacity-50"
                              >
                                <Check className="w-2.5 h-2.5" /> Confirm
                              </button>
                              <button
                                type="button"
                                disabled={processingId === reg.id}
                                onClick={() => handleQuickReject(reg.id)}
                                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-rose-900 text-rose-400 border border-rose-500/30 font-bold text-[10px] flex items-center gap-0.5 cursor-pointer disabled:opacity-50"
                              >
                                <X className="w-2.5 h-2.5" /> Reject
                              </button>
                            </div>
                          )}
                        </div>
                      ) : regEntryType === 'FREE_IN_GAME' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/40 font-bold text-[10px]">
                          <Gem className="w-3 h-3 text-purple-400" /> Free Diamonds Entry
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold text-[10px]">
                          <Ticket className="w-3 h-3" /> 5-Ad Ticket Verified
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right text-slate-400 font-sans text-[11px]">
                      {new Date(reg.createdAt).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Security Confirmation Authorization Modal */}
      {confirmTargetReg && (
        <Modal
          id="admin-roster-confirm-security-modal"
          isOpen={Boolean(confirmTargetReg)}
          onClose={() => setConfirmTargetReg(null)}
          title="Authorize Payment Confirmation"
          subtitle={`Security authorization required for ${confirmTargetReg.playerName} (${confirmTargetReg.ign})`}
          maxWidth="md"
        >
          <form onSubmit={handleModalConfirmSubmit} className="space-y-4 py-1">
            {modalError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{modalError}</span>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1.5">
              <div className="flex items-center justify-between font-bold">
                <span className="text-slate-300">{confirmTargetReg.tournamentTitle}</span>
                <span className="text-emerald-400 font-mono text-sm">₹{confirmTargetReg.entryFeePaid || 50}</span>
              </div>
              <div className="text-slate-400">
                Player: <strong className="text-white">{confirmTargetReg.playerName}</strong> (IGN: {confirmTargetReg.ign})
              </div>
              <div className="text-slate-400 font-mono">
                UTR / Reference: <strong className="text-cyan-300">{confirmTargetReg.utrNumber || confirmTargetReg.paymentTransactionId}</strong>
              </div>
            </div>

            {getPaymentRestrictions().requireBankStatementCheckbox && (
              <div className="p-3 rounded-xl border bg-slate-900 border-slate-800">
                <label className="flex items-start gap-2 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={certChecked}
                    onChange={(e) => setCertChecked(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <span className="text-slate-300 text-[11px]">
                    I certify that I have verified the credit of ₹{confirmTargetReg.entryFeePaid || 50} in our official bank/UPI account.
                  </span>
                </label>
              </div>
            )}

            {getPaymentRestrictions().requireSecurityPin && (
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Enter Admin Security PIN: *</span>
                </label>
                <input
                  type="password"
                  maxLength={10}
                  value={securityPinInput}
                  onChange={(e) => setSecurityPinInput(e.target.value)}
                  placeholder="Enter 4-digit PIN..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 text-xs font-mono font-bold tracking-widest text-white outline-none"
                  required
                />
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setConfirmTargetReg(null)}
                disabled={Boolean(processingId)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={Boolean(processingId)}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Authorize & Confirm</span>
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

