import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Lock, 
  Mail, 
  KeyRound, 
  AlertTriangle, 
  ArrowLeft, 
  Flame, 
  Clock, 
  CheckCircle2,
  Eye,
  EyeOff,
  ShieldOff
} from 'lucide-react';
import { 
  signInUser, 
  signOutUser, 
  resetUserPassword, 
  MASTER_ADMIN_EMAIL 
} from '../services/authService';
import { 
  getAdminLockoutStatus, 
  recordAdminFailedAttempt, 
  clearAdminLockout, 
  MAX_FAILED_ATTEMPTS, 
  AdminLockoutStatus 
} from '../services/adminSecurityService';

interface AdminLoginPageProps {
  onLoginSuccess: () => void;
  onGoToPlayerPortal: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({
  onLoginSuccess,
  onGoToPlayerPortal,
}) => {
  const [email, setEmail] = useState<string>(MASTER_ADMIN_EMAIL);
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Password reset mode
  const [resetMode, setResetMode] = useState<boolean>(false);
  const [resetLoading, setResetLoading] = useState<boolean>(false);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  // Security lockout state
  const [lockout, setLockout] = useState<AdminLockoutStatus>(getAdminLockoutStatus());

  // Real-time 1-second countdown ticker for 5-minute lockout
  useEffect(() => {
    const checkLockout = () => {
      const status = getAdminLockoutStatus();
      setLockout(status);
    };

    checkLockout();
    const interval = setInterval(checkLockout, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatCountdown = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResetSuccess(null);

    // If currently locked out, strictly deny submission
    const currentLockout = getAdminLockoutStatus();
    if (currentLockout.isLocked) {
      setLockout(currentLockout);
      setError(`Security lockout active. Please wait ${formatCountdown(currentLockout.remainingSeconds)} before trying again.`);
      return;
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Password reset flow
    if (resetMode) {
      if (normalizedEmail !== MASTER_ADMIN_EMAIL.toLowerCase()) {
        setError(`Password reset is only authorized for the Master Administrator account (${MASTER_ADMIN_EMAIL}).`);
        return;
      }
      try {
        setResetLoading(true);
        await resetUserPassword(normalizedEmail);
        setResetSuccess(`Password reset email has been dispatched to ${normalizedEmail}. Please check your inbox or spam folder.`);
      } catch (err: any) {
        setError(err.message || 'Failed to dispatch password reset email.');
      } finally {
        setResetLoading(false);
      }
      return;
    }

    // Strict validation against single hardcoded master admin account
    if (normalizedEmail !== MASTER_ADMIN_EMAIL.toLowerCase()) {
      const updatedLock = recordAdminFailedAttempt();
      setLockout(updatedLock);
      if (updatedLock.isLocked) {
        setError(`Security Lockout Triggered: 3 consecutive failed login attempts. Access to Admin Login is locked for 5 minutes.`);
      } else {
        setError(`Access Denied: Only the Master Administrator account (${MASTER_ADMIN_EMAIL}) is authorized to access the Admin Panel. (${updatedLock.failedAttempts}/${MAX_FAILED_ATTEMPTS} failed attempts. ${updatedLock.attemptsRemaining} remaining before 5-minute lockout).`);
      }
      return;
    }

    try {
      setLoading(true);
      const { profile } = await signInUser(normalizedEmail, password);

      if (profile.role !== 'admin' || normalizedEmail !== MASTER_ADMIN_EMAIL.toLowerCase()) {
        await signOutUser();
        const updatedLock = recordAdminFailedAttempt();
        setLockout(updatedLock);
        if (updatedLock.isLocked) {
          setError(`Security Lockout Triggered: 3 failed attempts. Access to Admin Login is locked for 5 minutes.`);
        } else {
          setError(`Access Denied: Authenticated account does not possess Master Administrator authority. (${updatedLock.failedAttempts}/${MAX_FAILED_ATTEMPTS} attempts).`);
        }
        return;
      }

      if (profile.status !== 'active') {
        await signOutUser();
        setError('Administrator access has been suspended. Please contact tournament oversight.');
        return;
      }

      // Successful login clears any prior failed attempt counter
      clearAdminLockout();
      setLockout(getAdminLockoutStatus());
      onLoginSuccess();
    } catch (err: any) {
      const updatedLock = recordAdminFailedAttempt();
      setLockout(updatedLock);

      if (updatedLock.isLocked) {
        setError(`Security Lockout Triggered: 3 consecutive failed login attempts. Admin login is locked for 5 minutes (${formatCountdown(updatedLock.remainingSeconds)} remaining).`);
      } else {
        const remaining = updatedLock.attemptsRemaining;
        setError(
          `Invalid administrator credentials. (${updatedLock.failedAttempts}/${MAX_FAILED_ATTEMPTS} failed attempts. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining before a 5-minute security lockout).`
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="admin-login-page" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-4 selection:bg-red-600 selection:text-white relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md relative z-10">
        {/* Top Back to Player Portal Button */}
        <div className="mb-4 flex items-center justify-between">
          <button
            id="btn-back-to-player"
            type="button"
            onClick={onGoToPlayerPortal}
            className="text-xs font-semibold text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer py-1.5 px-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Player Esports Portal</span>
          </button>

          <span className="text-[11px] font-mono text-red-400 bg-red-950/80 px-2.5 py-1 rounded-lg border border-red-500/30 uppercase font-bold tracking-wider">
            RESTRICTED ROUTE: /admin
          </span>
        </div>

        {/* Card */}
        <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-red-950/30 space-y-6">
          {/* Header */}
          <div className="text-center space-y-2">
            <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-tr from-red-600 via-orange-600 to-amber-500 p-0.5 shadow-xl shadow-red-600/30 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Flame className="w-7 h-7 text-red-500" />
              </div>
            </div>

            <div>
              <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-white">
                Admin Control Desk
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Free Fire MAX Tournament Operations & Anti-Cheat
              </p>
            </div>

            {/* Single Hardcoded Admin Notice */}
            <div className="mt-3 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Single Authorized Admin: <strong className="text-slate-200 font-mono">{MASTER_ADMIN_EMAIL}</strong>
              </span>
            </div>
          </div>

          {/* 5-Minute Lockout Alert Banner */}
          {lockout.isLocked && (
            <div id="admin-lockout-banner" className="p-4 rounded-2xl bg-gradient-to-br from-rose-950/90 via-red-950/80 to-slate-950 border-2 border-rose-500 text-rose-200 text-xs space-y-2.5 shadow-lg shadow-rose-900/40 animate-pulse">
              <div className="flex items-center gap-2 font-bold text-rose-400 uppercase tracking-wider text-[11px]">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Security Lockout Enforced</span>
              </div>
              <p className="leading-relaxed">
                <strong className="text-white">3 consecutive failed login attempts</strong> were recorded. To prevent unauthorized access, administrative sign-in has been temporarily locked for 5 minutes.
              </p>
              <div className="flex items-center justify-between pt-1 border-t border-rose-900/60 text-xs">
                <span className="flex items-center gap-1.5 text-rose-300 font-semibold">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  Time remaining:
                </span>
                <span className="font-mono text-base font-black text-white bg-rose-900/80 px-2.5 py-0.5 rounded-lg border border-rose-500/50">
                  {formatCountdown(lockout.remainingSeconds)}
                </span>
              </div>
            </div>
          )}

          {/* Warning Banner if 1 or 2 failed attempts */}
          {!lockout.isLocked && lockout.failedAttempts > 0 && (
            <div id="admin-attempt-warning-banner" className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="leading-snug">
                Warning: <strong>{lockout.failedAttempts} of {MAX_FAILED_ATTEMPTS}</strong> failed attempts. Admin login will be locked for 5 minutes upon {MAX_FAILED_ATTEMPTS} failures.
              </span>
            </div>
          )}

          {/* Error Message */}
          {error && !lockout.isLocked && (
            <div id="admin-login-error" className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              <span className="leading-relaxed">{error}</span>
            </div>
          )}

          {/* Password Reset Success */}
          {resetSuccess && (
            <div id="admin-reset-success" className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <span className="leading-relaxed">{resetSuccess}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleFormSubmit} className="space-y-4">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Authorized Admin Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="admin-login-email-input"
                  type="email"
                  required
                  disabled={lockout.isLocked || loading || resetLoading}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="rahul01112007@gmail.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/90 border border-slate-800 focus:border-red-500 focus:ring-1 focus:ring-red-500 text-sm text-white font-mono placeholder:text-slate-600 outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                Hardcoded master account. External emails will be rejected.
              </p>
            </div>

            {/* Password Field */}
            {!resetMode && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    Administrator Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setResetMode(true);
                    }}
                    className="text-[11px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="admin-login-password-input"
                    type={showPassword ? 'text' : 'password'}
                    required
                    disabled={lockout.isLocked || loading}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-950/90 border border-slate-800 focus:border-red-500 focus:ring-1 focus:ring-red-500 text-sm text-white placeholder:text-slate-600 outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-2">
              {resetMode ? (
                <div className="space-y-2">
                  <button
                    id="btn-admin-send-reset"
                    type="submit"
                    disabled={resetLoading || lockout.isLocked}
                    className="w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-amber-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {resetLoading ? (
                      <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <KeyRound className="w-4 h-4" />
                    )}
                    <span>{resetLoading ? 'Sending Reset Email...' : 'Send Password Reset Link'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setResetMode(false);
                      setError(null);
                    }}
                    className="w-full py-2 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    Back to Admin Sign In
                  </button>
                </div>
              ) : (
                <button
                  id="btn-admin-submit-login"
                  type="submit"
                  disabled={loading || lockout.isLocked || !password}
                  className={`w-full py-3 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 ${
                    lockout.isLocked
                      ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
                      : 'bg-gradient-to-r from-red-600 via-orange-600 to-amber-600 hover:from-red-500 hover:to-amber-500 shadow-red-600/30 cursor-pointer'
                  }`}
                >
                  {loading ? (
                    <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : lockout.isLocked ? (
                    <ShieldOff className="w-4 h-4" />
                  ) : (
                    <ShieldCheck className="w-4 h-4" />
                  )}
                  <span>
                    {loading
                      ? 'Verifying Master Credentials...'
                      : lockout.isLocked
                      ? `LOCKED (${formatCountdown(lockout.remainingSeconds)})`
                      : 'AUTHENTICATE MASTER ADMIN'}
                  </span>
                </button>
              )}
            </div>
          </form>

          {/* Security Assurance Footer */}
          <div className="pt-2 border-t border-slate-800 text-center space-y-1">
            <p className="text-[10px] text-slate-500">
              Administrative registration is permanently disabled. No public signups exist.
            </p>
            <p className="text-[10px] text-slate-600">
              Free Fire MAX Esports Security Protocol • End-to-End Encrypted Session
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
