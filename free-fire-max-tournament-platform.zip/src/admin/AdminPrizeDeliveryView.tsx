import React, { useState, useEffect } from 'react';
import { 
  Gift, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Filter, 
  ShieldCheck, 
  ShieldAlert, 
  AlertCircle, 
  Send, 
  Check, 
  Clock, 
  Award,
  ExternalLink,
  Phone,
  Mail,
  User,
  Sparkles,
  Gem,
  Copy
} from 'lucide-react';
import { PrizeDelivery, PrizeDeliveryStatus, PrizeType, formatPrizeAmount, isDiamondPrizeType, FREE_FIRE_DIAMOND_PACKAGES } from '../types';
import { 
  listenAllPrizeDeliveries, 
  markWinnerEligibleForPrize, 
  markPrizeAsSent, 
  updatePrizeDeliveryStatus 
} from '../services/prizeDeliveryService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { Modal } from '../components/Modal';
import { useAuth } from '../context/AuthContext';

export const AdminPrizeDeliveryView: React.FC = () => {
  const { userProfile } = useAuth();
  const [deliveries, setDeliveries] = useState<PrizeDelivery[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);
  
  // Deliver Modal State
  const [selectedDelivery, setSelectedDelivery] = useState<PrizeDelivery | null>(null);
  const [isDeliverModalOpen, setIsDeliverModalOpen] = useState(false);
  const [deliveryRef, setDeliveryRef] = useState('');
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [recipientContact, setRecipientContact] = useState('');
  const [adminNote, setAdminNote] = useState('');
  const [hasVerifiedWinner, setHasVerifiedWinner] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const unsub = listenAllPrizeDeliveries((list) => {
      setDeliveries(list);
    });
    return () => unsub();
  }, []);

  const handleCopyUid = (uid: string) => {
    navigator.clipboard.writeText(uid);
    setCopiedUid(uid);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const handleOpenDeliverModal = (del: PrizeDelivery) => {
    setSelectedDelivery(del);
    setDeliveryRef(del.deliveryReference || '');
    setDeliveryDate(del.deliveryDate || new Date().toISOString().split('T')[0]);
    setRecipientContact(del.winnerEmail || del.winnerPhone || '');
    setAdminNote(del.adminNotes || '');
    setHasVerifiedWinner(false);
    setFeedback(null);
    setIsDeliverModalOpen(true);
  };

  const handleApproveAntiCheat = async (del: PrizeDelivery) => {
    try {
      setActionLoading(true);
      await markWinnerEligibleForPrize(del.id, userProfile?.displayName || 'Admin');
      setFeedback(`Winner ${del.winnerIgn} cleared and marked ELIGIBLE FOR PRIZE.`);
      setTimeout(() => setFeedback(null), 3500);
    } catch (e: any) {
      console.error(e);
      setFeedback(`Error: ${e.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleConfirmSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDelivery) return;

    if (!hasVerifiedWinner) {
      setFeedback('You must confirm that you have verified this winner and prize.');
      return;
    }

    if (!deliveryRef.trim()) {
      setFeedback('Please provide a delivery reference or voucher / top-up order ID.');
      return;
    }

    try {
      setActionLoading(true);
      await markPrizeAsSent(selectedDelivery.id, {
        deliveryReference: deliveryRef.trim(),
        deliveryDate,
        recipientEmail: recipientContact.includes('@') ? recipientContact.trim() : undefined,
        recipientPhone: !recipientContact.includes('@') ? recipientContact.trim() : undefined,
        adminNotes: adminNote.trim(),
        adminName: userProfile?.displayName || 'Admin',
      });

      setIsDeliverModalOpen(false);
      setSelectedDelivery(null);
      setFeedback(`Reward marked as DELIVERED/SENT for ${selectedDelivery.winnerIgn}!`);
      setTimeout(() => setFeedback(null), 4000);
    } catch (e: any) {
      console.error(e);
      setFeedback(`Send error: ${e.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const filtered = deliveries.filter((d) => {
    if (statusFilter !== 'ALL' && d.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchIgn = d.winnerIgn?.toLowerCase().includes(q);
      const matchUid = d.winnerFfUid?.includes(q);
      const matchTourn = d.tournamentTitle?.toLowerCase().includes(q);
      const matchRef = d.deliveryReference?.toLowerCase().includes(q);
      return matchIgn || matchUid || matchTourn || matchRef;
    }
    return true;
  });

  const totalDiamonds = deliveries
    .filter((d) => isDiamondPrizeType(d.prizeType))
    .reduce((acc, d) => acc + (Number(d.prizeValue) || 0), 0);

  const totalCashEquivalent = deliveries
    .filter((d) => !isDiamondPrizeType(d.prizeType))
    .reduce((acc, d) => acc + (Number(d.prizeValue) || 0), 0);

  const pendingCount = deliveries.filter((d) => d.status !== 'SENT' && d.status !== 'CLAIMED').length;

  return (
    <div id="admin-prize-delivery-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Gift className="w-6 h-6 text-amber-400" />
            Prize Delivery & In-Game Diamond Fulfillment Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit verified tournament winners, review anti-cheat clearance, and manually dispatch In-Game Diamonds & digital gift cards
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {totalDiamonds > 0 && (
            <div className="px-3 py-1.5 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-xs flex items-center gap-1.5">
              <Gem className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-300">Diamonds Pool: </span>
              <span className="font-mono font-bold text-cyan-200">{totalDiamonds.toLocaleString()} 💎</span>
            </div>
          )}
          {totalCashEquivalent > 0 && (
            <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <span className="text-slate-400">Gift Cards Total: </span>
              <span className="font-mono font-bold text-amber-400">₹{totalCashEquivalent.toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2 shadow-lg">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2">
          <input
            id="admin-prize-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Winner IGN, Free Fire UID Snapshot, Tournament, Reference..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-500 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>

        <div>
          <select
            id="admin-prize-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Delivery Statuses</option>
            <option value="ANTI_CHEAT_UNDER_REVIEW">Under Anti-Cheat Review</option>
            <option value="ELIGIBLE_FOR_PRIZE">Eligible for Prize (Approved)</option>
            <option value="PROCESSING">Processing</option>
            <option value="SENT">Delivered / Sent</option>
            <option value="CLAIMED">Claimed by Winner</option>
            <option value="HELD_SUSPICIOUS">Held / Suspicious</option>
          </select>
        </div>
      </div>

      {/* Deliveries Table */}
      {filtered.length === 0 ? (
        <EmptyState
          id="no-deliveries-empty"
          title="No prize deliveries recorded yet."
          description="When tournament match results are published, winner prize deliveries are automatically created here for anti-cheat verification and fulfillment."
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Winner & Snapshot FF UID</th>
                <th className="py-3 px-3">Tournament / Match</th>
                <th className="py-3 px-3">Rank & Reward</th>
                <th className="py-3 px-3">Delivery Status</th>
                <th className="py-3 px-3">Fulfillment Reference</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filtered.map((del) => {
                const isDiamonds = isDiamondPrizeType(del.prizeType);
                return (
                  <tr key={del.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-sans">
                      <div className="font-bold text-white flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-amber-400" />
                        <span>{del.winnerIgn || del.winnerName || 'Winner'}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5 font-mono">
                        <span>FF UID: <strong className="text-cyan-400">{del.winnerFfUid || 'N/A'}</strong></span>
                        {del.winnerFfUid && (
                          <button
                            type="button"
                            onClick={() => handleCopyUid(del.winnerFfUid!)}
                            className="p-0.5 rounded text-slate-500 hover:text-cyan-300 cursor-pointer"
                            title="Copy UID"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        )}
                        {copiedUid === del.winnerFfUid && (
                          <span className="text-[9px] text-emerald-400 font-sans">Copied!</span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <span className="font-semibold text-slate-200 block truncate max-w-[180px]">
                        {del.tournamentTitle}
                      </span>
                      <span className="text-[10px] text-orange-400 block truncate max-w-[180px]">
                        {del.matchName}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <div className="flex items-center gap-1">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          del.prizeRank === 1 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-300'
                        }`}>
                          Rank #{del.prizeRank}
                        </span>
                        <span className={`font-black ${isDiamonds ? 'text-cyan-300' : 'text-amber-400'}`}>
                          {formatPrizeAmount(del.prizeValue, del.prizeType)}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block truncate max-w-[150px]">
                        {isDiamonds 
                          ? `💎 ${del.diamondPackage || 'Free Fire Diamonds'}` 
                          : del.prizeType}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <StatusBadge status={del.status} />
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px]">
                      {del.deliveryReference ? (
                        <div>
                          <span className="font-bold text-emerald-400 block">{del.deliveryReference}</span>
                          <span className="text-[10px] text-slate-500 font-sans">{del.deliveryDate}</span>
                        </div>
                      ) : (
                        <span className="text-slate-500 italic">Not dispatched</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right font-sans">
                      <div className="flex items-center justify-end gap-1.5">
                        {del.status === 'ANTI_CHEAT_UNDER_REVIEW' && (
                          <button
                            id={`approve-anticheat-${del.id}`}
                            disabled={actionLoading}
                            onClick={() => handleApproveAntiCheat(del)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1"
                          >
                            <ShieldCheck className="w-3 h-3" /> Approve
                          </button>
                        )}

                        {(del.status === 'ELIGIBLE_FOR_PRIZE' || del.status === 'PROCESSING') && (
                          <button
                            id={`deliver-prize-${del.id}`}
                            onClick={() => handleOpenDeliverModal(del)}
                            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-[11px] shadow transition-all cursor-pointer flex items-center gap-1"
                          >
                            <Send className="w-3 h-3" /> {isDiamonds ? 'Fulfill Diamonds' : 'Send Code'}
                          </button>
                        )}

                        {del.status === 'SENT' && (
                          <button
                            onClick={() => handleOpenDeliverModal(del)}
                            className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-[10px] font-medium transition-all cursor-pointer"
                          >
                            Edit
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Deliver Prize Modal */}
      {selectedDelivery && (
        <Modal
          id="deliver-prize-modal"
          isOpen={isDeliverModalOpen}
          onClose={() => setIsDeliverModalOpen(false)}
          title={isDiamondPrizeType(selectedDelivery.prizeType) ? 'Deliver Free Fire Diamonds' : 'Fulfill Digital Gift Card Prize'}
          subtitle={`Fulfilling Rank #${selectedDelivery.prizeRank} reward for ${selectedDelivery.winnerIgn}`}
          maxWidth="lg"
        >
          <form onSubmit={handleConfirmSend} className="space-y-4 py-1">
            {/* Winner Snapshot Summary */}
            <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Winner IGN:</span>
                <span className="font-bold text-white">{selectedDelivery.winnerIgn}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Winner Free Fire UID Snapshot:</span>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono font-extrabold text-cyan-400">{selectedDelivery.winnerFfUid}</span>
                  {selectedDelivery.winnerFfUid && (
                    <button
                      type="button"
                      onClick={() => handleCopyUid(selectedDelivery.winnerFfUid!)}
                      className="p-1 rounded bg-slate-900 text-slate-400 hover:text-cyan-300 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
              {selectedDelivery.diamondPackage && (
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Diamond Package:</span>
                  <span className="font-bold text-cyan-300">{selectedDelivery.diamondPackage}</span>
                </div>
              )}
              <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-800/80">
                <span className="text-slate-400">Award Quantity:</span>
                <span className="font-extrabold text-amber-400 text-sm">
                  {formatPrizeAmount(selectedDelivery.prizeValue, selectedDelivery.prizeType)}
                </span>
              </div>
            </div>

            {isDiamondPrizeType(selectedDelivery.prizeType) ? (
              <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-cyan-200 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                  <Gem className="w-4 h-4 text-cyan-400" />
                  <span>Free Fire Manual Diamonds Top-Up</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Perform top-up of <strong>{selectedDelivery.prizeValue} Diamonds</strong> to Free Fire UID: <strong className="text-cyan-300 font-mono">{selectedDelivery.winnerFfUid}</strong> via authorized top-up channels (GamesKharido / Garena Top-Up Center / UniPin). Enter the top-up order reference or transaction ID below.
                </p>
              </div>
            ) : null}

            {/* Delivery Reference */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isDiamondPrizeType(selectedDelivery.prizeType) 
                  ? 'Diamonds Top-Up Order ID / Transaction Reference *' 
                  : '16-Digit Voucher Code / Gift Card Claim URL *'}
              </label>
              <input
                type="text"
                required
                value={deliveryRef}
                onChange={(e) => setDeliveryRef(e.target.value)}
                placeholder={isDiamondPrizeType(selectedDelivery.prizeType) ? 'e.g. GK-29837492810 / TOPUP_89123' : 'e.g. AMZN-XXXX-YYYY-ZZZZ'}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none font-mono font-bold"
              />
            </div>

            {/* Recipient Contact */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Recipient Email or WhatsApp
                </label>
                <input
                  type="text"
                  value={recipientContact}
                  onChange={(e) => setRecipientContact(e.target.value)}
                  placeholder="e.g. player@gmail.com or 9876543210"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Delivery Date
                </label>
                <input
                  type="date"
                  required
                  value={deliveryDate}
                  onChange={(e) => setDeliveryDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none font-mono"
                />
              </div>
            </div>

            {/* Admin Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Internal Admin Notes
              </label>
              <textarea
                rows={2}
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="e.g. Screen recording verified clean. Top-up completed via Garena Center."
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none resize-none"
              />
            </div>

            {/* Verification Checkbox */}
            <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={hasVerifiedWinner}
                onChange={(e) => setHasVerifiedWinner(e.target.checked)}
                className="mt-0.5 rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer"
              />
              <span className="text-xs text-slate-300">
                I certify that I have verified the winner's Free Fire UID ({selectedDelivery.winnerFfUid}), reviewed game anti-cheat logs, and fulfilled the exact reward.
              </span>
            </label>

            <button
              type="submit"
              disabled={actionLoading || !hasVerifiedWinner}
              className="w-full py-3 bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {actionLoading ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              {actionLoading ? 'Updating Delivery Status...' : 'CONFIRM DELIVERY & MARK AS SENT'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};
