import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Filter, 
  DollarSign, 
  AlertCircle, 
  ShieldCheck, 
  Copy, 
  Check, 
  X, 
  Plus, 
  Receipt, 
  Printer, 
  Eye, 
  ExternalLink, 
  Gamepad2, 
  User, 
  Phone, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  RefreshCw, 
  Sparkles,
  TrendingUp,
  FileSpreadsheet,
  Lock,
  Unlock,
  KeyRound,
  ShieldAlert,
  Sliders,
  Settings,
  Shield
} from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Registration, Tournament } from '../types';
import { listenTournaments } from '../services/tournamentService';
import { 
  confirmPlayerPayment, 
  rejectPlayerPayment, 
  manualRegisterPaidPlayer, 
  checkDuplicateUtr,
  AdminPaymentRestrictions,
  DEFAULT_PAYMENT_RESTRICTIONS,
  getPaymentRestrictions,
  savePaymentRestrictions
} from '../services/paymentService';
import { Modal } from '../components/Modal';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const AdminPaymentsView: React.FC = () => {
  const { userProfile } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournId, setSelectedTournId] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'VERIFIED' | 'REJECTED'>('ALL');
  const [methodFilter, setMethodFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  // Modals state
  const [confirmModalReg, setConfirmModalReg] = useState<Registration | null>(null);
  const [rejectModalReg, setRejectModalReg] = useState<Registration | null>(null);
  const [receiptModalReg, setReceiptModalReg] = useState<Registration | null>(null);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [isRestrictionsModalOpen, setIsRestrictionsModalOpen] = useState(false);

  // Restriction Policies
  const [restrictions, setRestrictions] = useState<AdminPaymentRestrictions>(getPaymentRestrictions);
  const [tempRestrictions, setTempRestrictions] = useState<AdminPaymentRestrictions>(restrictions);
  const [restrictionSuccessMsg, setRestrictionSuccessMsg] = useState<string | null>(null);

  // Form states for modals
  const [adminNote, setAdminNote] = useState('');
  const [rejectReason, setRejectReason] = useState('Transaction reference not found in bank account.');
  const [customRejectReason, setCustomRejectReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);

  // Security Verification states for Confirm Modal
  const [adminPinInput, setAdminPinInput] = useState('');
  const [showAdminPin, setShowAdminPin] = useState(false);
  const [bankCertChecked, setBankCertChecked] = useState(false);
  const [duplicateOverrideChecked, setDuplicateOverrideChecked] = useState(false);
  const [duplicateOverrideNote, setDuplicateOverrideNote] = useState('');
  const [isDuplicateDetected, setIsDuplicateDetected] = useState(false);
  const [matchedDuplicateReg, setMatchedDuplicateReg] = useState<Registration | null>(null);

  // Manual Offline Registration Form state
  const [manualTournId, setManualTournId] = useState('');
  const [manualPlayerName, setManualPlayerName] = useState('');
  const [manualIgn, setManualIgn] = useState('');
  const [manualUid, setManualUid] = useState('');
  const [manualPhone, setManualPhone] = useState('');
  const [manualAmount, setManualAmount] = useState(50);
  const [manualMethod, setManualMethod] = useState<'UPI' | 'ONLINE' | 'CARD' | 'WALLET' | 'CASH'>('UPI');
  const [manualUtr, setManualUtr] = useState('');
  const [manualNotes, setManualNotes] = useState('Offline player payment confirmed by Admin Desk');
  const [manualFormat, setManualFormat] = useState<'SOLO' | 'SQUAD'>('SOLO');
  const [manualTeamName, setManualTeamName] = useState('');
  const [manualPinInput, setManualPinInput] = useState('');
  const [showManualPin, setShowManualPin] = useState(false);
  const [manualCertChecked, setManualCertChecked] = useState(false);

  // UTR Quick Checker state
  const [checkUtrInput, setCheckUtrInput] = useState('');
  const [utrCheckResult, setUtrCheckResult] = useState<{ checked: boolean; isDuplicate: boolean; matched?: Registration } | null>(null);
  const [utrCheckLoading, setUtrCheckLoading] = useState(false);

  useEffect(() => {
    const unsubRegs = onSnapshot(
      query(collection(db, 'registrations'), orderBy('createdAt', 'desc')),
      (snap) => {
        const list: Registration[] = [];
        snap.forEach((d) => list.push(d.data() as Registration));
        setRegistrations(list);
      }
    );

    const unsubTourn = listenTournaments((list) => {
      setTournaments(list);
      if (list.length > 0 && !manualTournId) {
        setManualTournId(list[0].id);
        setManualAmount(list[0].entryFee || 50);
      }
    });

    return () => {
      unsubRegs();
      unsubTourn();
    };
  }, []);

  // Update manual amount when selected tournament changes
  useEffect(() => {
    if (manualTournId) {
      const selected = tournaments.find((t) => t.id === manualTournId);
      if (selected) {
        setManualAmount(selected.entryFee || 50);
        setManualFormat(selected.format || 'SOLO');
      }
    }
  }, [manualTournId, tournaments]);

  // Check duplicate UTR on modal open and reset restriction states
  useEffect(() => {
    if (confirmModalReg) {
      setAdminNote(`Verified and approved by ${userProfile?.displayName || 'Admin'}`);
      setAdminPinInput('');
      setShowAdminPin(false);
      setBankCertChecked(false);
      setDuplicateOverrideChecked(false);
      setDuplicateOverrideNote('');
      setIsDuplicateDetected(false);
      setMatchedDuplicateReg(null);
      setActionError(null);

      const utr = confirmModalReg.utrNumber || confirmModalReg.paymentTransactionId || '';
      if (utr) {
        checkDuplicateUtr(utr, confirmModalReg.id).then((res) => {
          if (res.isDuplicate && res.matchedRegistration) {
            setIsDuplicateDetected(true);
            setMatchedDuplicateReg(res.matchedRegistration);
            setDuplicateWarning(`SECURITY RESTRICTION: This UTR (${utr}) is already registered with player ${res.matchedRegistration.playerName} (${res.matchedRegistration.freeFireUid}) in ${res.matchedRegistration.tournamentTitle}.`);
          } else {
            setIsDuplicateDetected(false);
            setMatchedDuplicateReg(null);
            setDuplicateWarning(null);
          }
        });
      }
    }
  }, [confirmModalReg, userProfile]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUid(id);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  const handleOpenRestrictionsModal = () => {
    setTempRestrictions({ ...restrictions });
    setActionError(null);
    setIsRestrictionsModalOpen(true);
  };

  const handleSaveRestrictions = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempRestrictions.requireSecurityPin && !tempRestrictions.securityPin.trim()) {
      setActionError('Security PIN cannot be blank when PIN requirement is active.');
      return;
    }
    savePaymentRestrictions(tempRestrictions);
    setRestrictions(tempRestrictions);
    setRestrictionSuccessMsg('Admin confirmation restrictions and security policy updated successfully.');
    setTimeout(() => setRestrictionSuccessMsg(null), 3500);
    setIsRestrictionsModalOpen(false);
  };

  // Filter only paid registrations or all registrations with entry fee
  const paidRegistrations = registrations.filter((r) => {
    const isPaidType = r.entryType === 'PAID_IN_GAME' || (r.entryFeePaid && r.entryFeePaid > 0) || r.paymentMethod !== 'FREE';
    return isPaidType;
  });

  const filteredPayments = paidRegistrations.filter((reg) => {
    if (selectedTournId !== 'ALL' && reg.tournamentId !== selectedTournId) return false;
    if (statusFilter !== 'ALL' && (reg.paymentStatus || 'PENDING') !== statusFilter) return false;
    if (methodFilter !== 'ALL' && reg.paymentMethod !== methodFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = reg.playerName?.toLowerCase().includes(q);
      const matchIgn = reg.ign?.toLowerCase().includes(q);
      const matchUid = reg.freeFireUid?.includes(q);
      const matchPhone = reg.phone?.includes(q);
      const matchTxn = reg.paymentTransactionId?.toLowerCase().includes(q) || reg.utrNumber?.toLowerCase().includes(q);
      const matchTourn = reg.tournamentTitle?.toLowerCase().includes(q);
      return matchName || matchIgn || matchUid || matchPhone || matchTxn || matchTourn;
    }
    return true;
  });

  // Analytics Metrics
  const totalPaidRevenue = paidRegistrations
    .filter((r) => r.paymentStatus === 'VERIFIED')
    .reduce((acc, r) => acc + (Number(r.entryFeePaid) || 50), 0);

  const pendingApprovalsCount = paidRegistrations.filter(
    (r) => (r.paymentStatus || 'PENDING') === 'PENDING'
  ).length;

  const totalVerifiedCount = paidRegistrations.filter((r) => r.paymentStatus === 'VERIFIED').length;
  const totalRejectedCount = paidRegistrations.filter((r) => r.paymentStatus === 'REJECTED').length;

  // Handlers
  const handleConfirmPayment = async () => {
    if (!confirmModalReg) return;
    try {
      setActionLoading(true);
      setActionError(null);

      // Restriction Check 1: Duplicate UTR strict block
      if (isDuplicateDetected && restrictions.strictDuplicateUtrBlock && !duplicateOverrideChecked) {
        setActionError('CONFIRMATION RESTRICTED: Duplicate UTR detected. You must explicitly authorize a security override to activate this slot.');
        setActionLoading(false);
        return;
      }

      // Restriction Check 2: Bank Statement Certification
      if (restrictions.requireBankStatementCheckbox && !bankCertChecked) {
        setActionError('CONFIRMATION RESTRICTED: You must certify that the credit was verified in the official bank statement.');
        setActionLoading(false);
        return;
      }

      // Restriction Check 3: Admin Security PIN Verification
      if (restrictions.requireSecurityPin) {
        if (!adminPinInput.trim()) {
          setActionError('CONFIRMATION RESTRICTED: Please enter the Admin Security PIN to authorize activation.');
          setActionLoading(false);
          return;
        }
        if (adminPinInput.trim() !== restrictions.securityPin.trim()) {
          setActionError('CONFIRMATION RESTRICTED: Incorrect Admin Security PIN. Access denied.');
          setActionLoading(false);
          return;
        }
      }

      // Restriction Check 4: Admin Audit Note
      if (restrictions.requireAdminNotes && !adminNote.trim()) {
        setActionError('CONFIRMATION RESTRICTED: Admin audit note is required for verification.');
        setActionLoading(false);
        return;
      }

      const adminName = userProfile?.displayName || 'Admin Desk';
      const finalNote = duplicateOverrideChecked
        ? `${adminNote.trim()} | [SECURITY OVERRIDE AUTHORIZED: ${duplicateOverrideNote.trim() || 'Admin certified manual override'}]`
        : adminNote.trim();

      await confirmPlayerPayment(confirmModalReg.id, adminName, finalNote);
      setConfirmModalReg(null);
    } catch (err: any) {
      console.error('Error confirming payment:', err);
      setActionError(err.message || 'Failed to confirm payment.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleRejectPayment = async () => {
    if (!rejectModalReg) return;
    try {
      setActionLoading(true);
      setActionError(null);
      const adminName = userProfile?.displayName || 'Admin Desk';
      const reason = rejectReason === 'CUSTOM' ? customRejectReason : rejectReason;
      if (!reason.trim()) {
        setActionError('Please provide a rejection reason.');
        return;
      }
      await rejectPlayerPayment(rejectModalReg.id, adminName, reason);
      setRejectModalReg(null);
    } catch (err: any) {
      console.error('Error rejecting payment:', err);
      setActionError(err.message || 'Failed to reject payment.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleManualOfflineSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualTournId || !manualPlayerName.trim() || !manualUid.trim() || !manualIgn.trim()) {
      setActionError('Please fill in Tournament, Player Name, IGN, and Free Fire UID.');
      return;
    }

    // Restriction Check 1: Min UTR Length
    if (manualMethod !== 'CASH' && restrictions.minUtrLength > 0 && manualUtr.trim()) {
      if (manualUtr.trim().length < restrictions.minUtrLength) {
        setActionError(`RESTRICTION: UTR / Reference ID must be at least ${restrictions.minUtrLength} alphanumeric characters.`);
        return;
      }
    }

    // Restriction Check 2: Physical Receipt Certification
    if (restrictions.requireBankStatementCheckbox && !manualCertChecked) {
      setActionError('RESTRICTION: You must check the certification box confirming funds were collected & verified.');
      return;
    }

    // Restriction Check 3: Admin Security PIN
    if (restrictions.requireSecurityPin) {
      if (!manualPinInput.trim()) {
        setActionError('RESTRICTION: Please enter the Admin Security PIN to confirm this manual entry.');
        return;
      }
      if (manualPinInput.trim() !== restrictions.securityPin.trim()) {
        setActionError('RESTRICTION: Incorrect Admin Security PIN. Manual entry locked.');
        return;
      }
    }

    try {
      setActionLoading(true);
      setActionError(null);
      const selectedTourn = tournaments.find((t) => t.id === manualTournId);
      const adminName = userProfile?.displayName || 'Admin Desk';

      await manualRegisterPaidPlayer({
        tournamentId: manualTournId,
        tournamentTitle: selectedTourn?.title || 'Tournament',
        playerName: manualPlayerName.trim(),
        ign: manualIgn.trim(),
        freeFireUid: manualUid.trim(),
        phone: manualPhone.trim(),
        amount: Number(manualAmount) || 50,
        paymentMethod: manualMethod,
        utrNumber: manualUtr.trim() || `OFFLINE_${Date.now().toString().slice(-6)}`,
        adminName,
        adminNotes: manualNotes.trim(),
        format: manualFormat,
        teamName: manualFormat === 'SQUAD' ? manualTeamName.trim() : undefined,
      });

      // Reset form
      setManualPlayerName('');
      setManualIgn('');
      setManualUid('');
      setManualPhone('');
      setManualUtr('');
      setManualTeamName('');
      setManualPinInput('');
      setManualCertChecked(false);
      setIsManualModalOpen(false);
    } catch (err: any) {
      console.error('Manual registration error:', err);
      setActionError(err.message || 'Failed to manually register paid player.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCheckUtr = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkUtrInput.trim()) return;

    try {
      setUtrCheckLoading(true);
      const res = await checkDuplicateUtr(checkUtrInput.trim());
      setUtrCheckResult({
        checked: true,
        isDuplicate: res.isDuplicate,
        matched: res.matchedRegistration,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setUtrCheckLoading(false);
    }
  };

  return (
    <div id="admin-payments-view" className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                Player Payment Confirmation Desk
                {pendingApprovalsCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-xs font-black bg-rose-600 text-white animate-pulse">
                    {pendingApprovalsCount} PENDING
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Audit UPI UTRs, verify entry payments, approve registrations, detect duplicate transaction fraud, and log offline player receipts
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="admin-restrictions-config-btn"
            type="button"
            onClick={handleOpenRestrictionsModal}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Shield className="w-4 h-4 text-cyan-400" />
            <span>Confirmation Restrictions</span>
            {restrictions.requireSecurityPin && (
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            )}
          </button>

          <button
            id="admin-manual-payment-btn"
            onClick={() => {
              setActionError(null);
              setManualPinInput('');
              setManualCertChecked(false);
              setIsManualModalOpen(true);
            }}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Record Offline / Cash Payment</span>
          </button>
        </div>
      </div>

      {/* Confirmation Restriction Safeguard Banner */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white">Active Admin Confirmation Safeguards</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                PROTECTED
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Strict rules enforced before manual activations to prevent accidental approvals and duplicate UTR fraud.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className={`px-2.5 py-1 rounded-lg border font-medium flex items-center gap-1.5 ${
            restrictions.requireSecurityPin
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}>
            <KeyRound className="w-3 h-3" />
            <span>PIN Lock: {restrictions.requireSecurityPin ? 'Mandatory' : 'Off'}</span>
          </span>

          <span className={`px-2.5 py-1 rounded-lg border font-medium flex items-center gap-1.5 ${
            restrictions.strictDuplicateUtrBlock
              ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
              : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}>
            <ShieldAlert className="w-3 h-3" />
            <span>Duplicate Block: {restrictions.strictDuplicateUtrBlock ? 'Strict' : 'Warn'}</span>
          </span>

          <span className={`px-2.5 py-1 rounded-lg border font-medium flex items-center gap-1.5 ${
            restrictions.requireBankStatementCheckbox
              ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
              : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}>
            <CheckCircle2 className="w-3 h-3" />
            <span>Bank Certification: {restrictions.requireBankStatementCheckbox ? 'Required' : 'Off'}</span>
          </span>

          <button
            type="button"
            onClick={handleOpenRestrictionsModal}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold flex items-center gap-1 transition-all cursor-pointer"
          >
            <Sliders className="w-3 h-3" />
            <span>Configure</span>
          </button>
        </div>
      </div>

      {restrictionSuccessMsg && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{restrictionSuccessMsg}</span>
        </div>
      )}

      {/* Analytics KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Collected Revenue */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Verified Paid Revenue</span>
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-emerald-400 font-mono">
              ₹{totalPaidRevenue.toLocaleString()}
            </span>
            <p className="text-[10px] text-slate-500 mt-0.5">
              From {totalVerifiedCount} verified paid entries
            </p>
          </div>
        </div>

        {/* Pending Approvals */}
        <div className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
          pendingApprovalsCount > 0 
            ? 'bg-rose-950/30 border-rose-500/40 shadow-lg shadow-rose-950/20' 
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-xs">
            <span className={pendingApprovalsCount > 0 ? 'text-rose-300 font-bold' : 'text-slate-400'}>
              Pending Confirmation
            </span>
            <span className={`p-1.5 rounded-lg ${pendingApprovalsCount > 0 ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-800 text-slate-400'}`}>
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <span className={`text-2xl font-black font-mono ${pendingApprovalsCount > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
              {pendingApprovalsCount}
            </span>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Requires immediate admin approval
            </p>
          </div>
        </div>

        {/* Verified Paid Entries */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Verified Paid Slots</span>
            <span className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-cyan-300 font-mono">
              {totalVerifiedCount}
            </span>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Slots active in tournament match desk
            </p>
          </div>
        </div>

        {/* Rejected / Disputed */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Rejected / Invalid UTRs</span>
            <span className="p-1.5 rounded-lg bg-slate-800 text-slate-400">
              <XCircle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-slate-400 font-mono">
              {totalRejectedCount}
            </span>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Flagged transactions or fee mismatch
            </p>
          </div>
        </div>
      </div>

      {/* UTR Fraud Inspector Bar */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800/80">
        <form onSubmit={handleCheckUtr} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300 shrink-0">
            <ShieldCheck className="w-4 h-4 text-orange-400" />
            <span>UTR Fraud Inspector:</span>
          </div>
          <div className="flex-1 relative">
            <input
              id="admin-utr-checker-input"
              type="text"
              value={checkUtrInput}
              onChange={(e) => setCheckUtrInput(e.target.value)}
              placeholder="Paste any 12-digit UTR or Transaction ID to test for duplicates / previous usage..."
              className="w-full px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none font-mono"
            />
          </div>
          <button
            type="submit"
            disabled={utrCheckLoading || !checkUtrInput.trim()}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-orange-400 border border-orange-500/30 text-xs font-bold transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
          >
            {utrCheckLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>Audit UTR</span>
          </button>
        </form>

        {/* UTR check result banner */}
        {utrCheckResult && (
          <div className="mt-2.5 pt-2.5 border-t border-slate-800/60">
            {utrCheckResult.isDuplicate && utrCheckResult.matched ? (
              <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-200 text-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    <strong>DUPLICATE UTR DETECTED!</strong> Already used by <strong>{utrCheckResult.matched.playerName}</strong> (IGN: {utrCheckResult.matched.ign}, FF UID: {utrCheckResult.matched.freeFireUid}) in {utrCheckResult.matched.tournamentTitle}.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setReceiptModalReg(utrCheckResult.matched!)}
                  className="px-2 py-1 bg-rose-900/80 hover:bg-rose-800 text-[11px] font-bold rounded-lg text-white shrink-0 cursor-pointer"
                >
                  View Receipt
                </button>
              </div>
            ) : (
              <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>UTR CLEAN & UNIQUE:</strong> Transaction reference is not currently linked to any active player registration.
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Filter and Search Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        {/* Search */}
        <div className="sm:col-span-1">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="admin-payments-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Player, FF UID, UTR, Txn ID..."
              className="w-full pl-8 pr-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
            />
          </div>
        </div>

        {/* Status Filter */}
        <div>
          <select
            id="admin-payments-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Payment Statuses</option>
            <option value="PENDING">Pending Admin Approval ({pendingApprovalsCount})</option>
            <option value="VERIFIED">Verified & Active ({totalVerifiedCount})</option>
            <option value="REJECTED">Rejected ({totalRejectedCount})</option>
          </select>
        </div>

        {/* Tournament Filter */}
        <div>
          <select
            id="admin-payments-tourn-filter"
            value={selectedTournId}
            onChange={(e) => setSelectedTournId(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Tournaments</option>
            {tournaments.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} ({t.format})
              </option>
            ))}
          </select>
        </div>

        {/* Method Filter */}
        <div>
          <select
            id="admin-payments-method-filter"
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
          >
            <option value="ALL">All Payment Methods</option>
            <option value="UPI">UPI (Google Pay / PhonePe / Paytm)</option>
            <option value="ONLINE">Online Gateway / Card</option>
            <option value="CASH">Cash / Offline Entry</option>
            <option value="WALLET">In-Game Wallet</option>
          </select>
        </div>
      </div>

      {/* Main Payments Table */}
      {filteredPayments.length === 0 ? (
        <EmptyState
          id="no-payments-admin-empty"
          title="No paid registrations found."
          description="Player entry payments processed via UPI, QR, or online checkout will appear here for audit, confirmation, or rejection."
          actionLabel="Record Offline Payment"
          onAction={() => setIsManualModalOpen(true)}
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Player & Free Fire UID</th>
                <th className="py-3 px-3">Tournament & Match</th>
                <th className="py-3 px-3">Amount & Mode</th>
                <th className="py-3 px-3">UTR / Transaction ID</th>
                <th className="py-3 px-3">Verification Status</th>
                <th className="py-3 px-4 text-right">Confirm / Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredPayments.map((reg) => {
                const status = reg.paymentStatus || 'PENDING';
                const isPending = status === 'PENDING';
                const isVerified = status === 'VERIFIED';
                const isRejected = status === 'REJECTED';
                const amount = reg.entryFeePaid || 50;

                return (
                  <tr key={reg.id} className="hover:bg-slate-800/30 transition-colors">
                    {/* Player Info */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-white text-xs leading-tight">
                        {reg.format === 'SOLO' ? reg.playerName : reg.teamName || reg.playerName}
                      </div>
                      <div className="text-[11px] text-amber-400 font-semibold">
                        IGN: {reg.ign}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>FF UID: <strong className="text-cyan-400 font-mono">{reg.freeFireUid}</strong></span>
                        {reg.freeFireUid && (
                          <button
                            type="button"
                            onClick={() => handleCopy(reg.freeFireUid, `uid-${reg.id}`)}
                            className="p-0.5 rounded text-slate-500 hover:text-cyan-300 cursor-pointer"
                            title="Copy UID"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        )}
                        {copiedUid === `uid-${reg.id}` && (
                          <span className="text-[9px] text-emerald-400 font-sans">Copied!</span>
                        )}
                      </div>
                      {reg.phone && (
                        <div className="text-[10px] text-slate-500">
                          Phone: {reg.phone}
                        </div>
                      )}
                    </td>

                    {/* Tournament & Match */}
                    <td className="py-3 px-3">
                      <span className="font-semibold text-slate-200 block truncate max-w-[170px]">
                        {reg.tournamentTitle}
                      </span>
                      <div className="flex items-center gap-1.5 text-[10px] text-orange-400 font-bold mt-0.5">
                        <span>{reg.matchName}</span>
                        <span className="px-1.5 py-0.2 rounded bg-orange-950/80 border border-orange-500/30 text-orange-300 font-mono">
                          Slot #{reg.seatNumber}
                        </span>
                      </div>
                    </td>

                    {/* Amount & Mode */}
                    <td className="py-3 px-3">
                      <div className="text-sm font-black font-mono text-emerald-400">
                        ₹{amount}
                      </div>
                      <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-bold mt-0.5">
                        <CreditCard className="w-2.5 h-2.5 text-slate-400" />
                        <span>{reg.paymentMethod || 'UPI'}</span>
                      </div>
                    </td>

                    {/* UTR / Transaction ID */}
                    <td className="py-3 px-3 font-mono">
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-cyan-300 font-bold truncate max-w-[140px]" title={reg.utrNumber || reg.paymentTransactionId}>
                          {reg.utrNumber || reg.paymentTransactionId || 'TXN_DIRECT'}
                        </span>
                        {(reg.utrNumber || reg.paymentTransactionId) && (
                          <button
                            type="button"
                            onClick={() => handleCopy(reg.utrNumber || reg.paymentTransactionId || '', `utr-${reg.id}`)}
                            className="p-0.5 rounded text-slate-500 hover:text-cyan-300 cursor-pointer"
                            title="Copy UTR"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                      {copiedUid === `utr-${reg.id}` && (
                        <span className="text-[9px] text-emerald-400 font-sans block">UTR Copied!</span>
                      )}
                      <span className="text-[10px] text-slate-500 font-sans block mt-0.5">
                        {new Date(reg.createdAt).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </td>

                    {/* Status & Audit */}
                    <td className="py-3 px-3">
                      {isPending && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-bold">
                          <Clock className="w-3 h-3" /> PENDING AUDIT
                        </span>
                      )}
                      {isVerified && (
                        <div>
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                            <CheckCircle2 className="w-3 h-3" /> CONFIRMED
                          </span>
                          {reg.verifiedBy && (
                            <span className="text-[9px] text-slate-400 block mt-0.5">
                              By {reg.verifiedBy}
                            </span>
                          )}
                        </div>
                      )}
                      {isRejected && (
                        <div>
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[10px] font-bold">
                            <XCircle className="w-3 h-3" /> REJECTED
                          </span>
                          {reg.paymentNotes && (
                            <span className="text-[9px] text-rose-300 block truncate max-w-[120px] mt-0.5" title={reg.paymentNotes}>
                              {reg.paymentNotes}
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Action Buttons */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {isPending && (
                          <>
                            <button
                              id={`confirm-pay-btn-${reg.id}`}
                              type="button"
                              onClick={() => {
                                setActionError(null);
                                setConfirmModalReg(reg);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                              title="Confirm and verify payment"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Confirm</span>
                            </button>
                            <button
                              id={`reject-pay-btn-${reg.id}`}
                              type="button"
                              onClick={() => {
                                setActionError(null);
                                setRejectModalReg(reg);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 border border-rose-500/30 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                              title="Reject payment"
                            >
                              <X className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          </>
                        )}

                        {isVerified && (
                          <button
                            id={`view-receipt-btn-${reg.id}`}
                            type="button"
                            onClick={() => setReceiptModalReg(reg)}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-cyan-500/30 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>Receipt</span>
                          </button>
                        )}

                        {isRejected && (
                          <button
                            id={`re-verify-btn-${reg.id}`}
                            type="button"
                            onClick={() => {
                              setActionError(null);
                              setConfirmModalReg(reg);
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>Re-Confirm</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* CONFIRM PAYMENT MODAL */}
      {confirmModalReg && (
        <Modal
          id="admin-confirm-payment-modal"
          isOpen={Boolean(confirmModalReg)}
          onClose={() => setConfirmModalReg(null)}
          title="Confirm Player Payment"
          subtitle={`Verify payment for ${confirmModalReg.playerName} (${confirmModalReg.ign})`}
          maxWidth="md"
        >
          <div className="space-y-4 py-1">
            {actionError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{actionError}</span>
              </div>
            )}

            {duplicateWarning && (
              <div className="p-3 rounded-xl bg-amber-950/80 border border-amber-500/60 text-amber-200 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{duplicateWarning}</span>
              </div>
            )}

            {/* Payment Summary Box */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/60 to-slate-950 border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Payment Amount Payable
                </span>
                <span className="text-2xl font-black font-mono text-emerald-400">
                  ₹{confirmModalReg.entryFeePaid || 50}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Player IGN & Name</span>
                  <span className="font-bold text-white block truncate">{confirmModalReg.ign} ({confirmModalReg.playerName})</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Free Fire UID</span>
                  <span className="font-mono font-bold text-cyan-400 block">{confirmModalReg.freeFireUid}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Tournament & Match</span>
                  <span className="font-bold text-slate-200 block truncate">{confirmModalReg.tournamentTitle}</span>
                  <span className="text-[10px] text-orange-400 font-bold">Slot #{confirmModalReg.seatNumber}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">UTR / Txn Reference</span>
                  <span className="font-mono font-bold text-cyan-300 block truncate" title={confirmModalReg.utrNumber || confirmModalReg.paymentTransactionId}>
                    {confirmModalReg.utrNumber || confirmModalReg.paymentTransactionId || 'TXN_DIRECT'}
                  </span>
                </div>
              </div>
            </div>

            {/* Duplicate UTR Restriction Alert & Override */}
            {isDuplicateDetected && (
              <div className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-500/80 text-rose-200 text-xs space-y-2">
                <div className="flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                  <div>
                    <span className="font-bold text-rose-300 block">
                      SECURITY RESTRICTION: DUPLICATE UTR DETECTED
                    </span>
                    <p className="text-[11px] text-rose-200/90 mt-0.5">
                      This transaction UTR ({confirmModalReg.utrNumber || confirmModalReg.paymentTransactionId}) is already linked to player <strong>{matchedDuplicateReg?.playerName}</strong> (IGN: {matchedDuplicateReg?.ign}, UID: {matchedDuplicateReg?.freeFireUid}) in {matchedDuplicateReg?.tournamentTitle}.
                    </p>
                  </div>
                </div>

                {restrictions.strictDuplicateUtrBlock ? (
                  <div className="pt-2 border-t border-rose-800/60 space-y-2">
                    <label className="flex items-start gap-2 text-[11px] text-rose-200 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={duplicateOverrideChecked}
                        onChange={(e) => setDuplicateOverrideChecked(e.target.checked)}
                        className="mt-0.5 w-4 h-4 rounded bg-rose-900/50 border-rose-500 text-rose-500 focus:ring-0 cursor-pointer"
                      />
                      <span>
                        <strong>ADMIN OVERRIDE:</strong> I have manually investigated and certified that this is a valid transaction and accept full responsibility.
                      </span>
                    </label>

                    {duplicateOverrideChecked && (
                      <input
                        type="text"
                        value={duplicateOverrideNote}
                        onChange={(e) => setDuplicateOverrideNote(e.target.value)}
                        placeholder="State reason for duplicate override (required for audit logs)..."
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-rose-500/50 text-xs text-white outline-none"
                      />
                    )}
                  </div>
                ) : (
                  <p className="text-[10px] text-amber-300 font-medium">
                    Warning mode active. Please double check before confirming.
                  </p>
                )}
              </div>
            )}

            {/* Admin Audit Note */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Admin Audit Notes / Verification Stamp: {restrictions.requireAdminNotes && <span className="text-rose-400">*</span>}
              </label>
              <input
                type="text"
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="e.g. Bank credit verified in HDFC statement"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
              />
            </div>

            {/* Mandatory Bank Certification Restriction */}
            {restrictions.requireBankStatementCheckbox && (
              <div className={`p-3 rounded-xl border transition-all ${
                bankCertChecked ? 'bg-emerald-950/40 border-emerald-500/50' : 'bg-slate-900/80 border-slate-800'
              }`}>
                <label className="flex items-start gap-2.5 text-xs cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={bankCertChecked}
                    onChange={(e) => setBankCertChecked(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-200 block">
                      Mandatory Bank / Merchant Statement Certification: *
                    </span>
                    <p className="text-[11px] text-slate-400">
                      I solemnly certify that I have checked the live bank / UPI statement and confirmed credit of <strong className="text-emerald-400">₹{confirmModalReg.entryFeePaid || 50}</strong> for UTR <strong>{confirmModalReg.utrNumber || confirmModalReg.paymentTransactionId || 'TXN'}</strong>.
                    </p>
                  </div>
                </label>
              </div>
            )}

            {/* Mandatory Admin Security PIN Restriction */}
            {restrictions.requireSecurityPin && (
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Admin Security PIN Required: *</span>
                  </label>
                  <span className="text-[10px] text-slate-500">Default: 7788</span>
                </div>
                <div className="relative">
                  <input
                    type={showAdminPin ? 'text' : 'password'}
                    maxLength={10}
                    value={adminPinInput}
                    onChange={(e) => setAdminPinInput(e.target.value)}
                    placeholder="Enter 4-digit Security PIN..."
                    className={`w-full pl-3.5 pr-20 py-2 rounded-xl bg-slate-950 border text-xs font-mono font-bold tracking-widest text-white outline-none transition-all ${
                      adminPinInput.trim() === restrictions.securityPin.trim()
                        ? 'border-emerald-500 text-emerald-300'
                        : adminPinInput.length > 0
                        ? 'border-rose-500 text-rose-300'
                        : 'border-slate-800 focus:border-cyan-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPin(!showAdminPin)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 px-2 py-1 rounded text-[10px] font-bold bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                  >
                    {showAdminPin ? 'Hide' : 'Show'}
                  </button>
                </div>
                {adminPinInput.length > 0 && adminPinInput.trim() !== restrictions.securityPin.trim() && (
                  <p className="text-[10px] text-rose-400 flex items-center gap-1">
                    <X className="w-3 h-3" />
                    <span>Incorrect Security PIN. Verification is locked.</span>
                  </p>
                )}
                {adminPinInput.trim() === restrictions.securityPin.trim() && (
                  <p className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Security PIN Authorized.</span>
                  </p>
                )}
              </div>
            )}

            {/* Checklist */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 space-y-1.5">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Slot Activation Notice</span>
              </div>
              <p className="text-[10px] text-slate-400">
                Confirming will activate player's seat in <strong>{confirmModalReg.matchName}</strong> and unlock their room credentials upon release.
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setConfirmModalReg(null)}
                disabled={actionLoading}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPayment}
                disabled={
                  actionLoading ||
                  (isDuplicateDetected && restrictions.strictDuplicateUtrBlock && !duplicateOverrideChecked) ||
                  (restrictions.requireBankStatementCheckbox && !bankCertChecked) ||
                  (restrictions.requireSecurityPin && adminPinInput.trim() !== restrictions.securityPin.trim()) ||
                  (restrictions.requireAdminNotes && !adminNote.trim())
                }
                className={`px-5 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-all ${
                  (isDuplicateDetected && restrictions.strictDuplicateUtrBlock && !duplicateOverrideChecked) ||
                  (restrictions.requireBankStatementCheckbox && !bankCertChecked) ||
                  (restrictions.requireSecurityPin && adminPinInput.trim() !== restrictions.securityPin.trim()) ||
                  (restrictions.requireAdminNotes && !adminNote.trim())
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 cursor-pointer'
                }`}
              >
                {actionLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                <span>Confirm & Activate Slot</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* REJECT PAYMENT MODAL */}
      {rejectModalReg && (
        <Modal
          id="admin-reject-payment-modal"
          isOpen={Boolean(rejectModalReg)}
          onClose={() => setRejectModalReg(null)}
          title="Reject Player Payment"
          subtitle={`Reject entry submission for ${rejectModalReg.playerName}`}
          maxWidth="md"
        >
          <div className="space-y-4 py-1">
            {actionError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{actionError}</span>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs text-rose-200 space-y-1">
              <span className="font-bold block">Player: {rejectModalReg.playerName} (IGN: {rejectModalReg.ign})</span>
              <span className="font-mono text-slate-300 block">FF UID: {rejectModalReg.freeFireUid}</span>
              <span className="font-mono text-cyan-300 block">Submitted UTR: {rejectModalReg.utrNumber || rejectModalReg.paymentTransactionId}</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Select Rejection Reason:
              </label>
              <select
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-rose-500 text-xs text-white outline-none cursor-pointer"
              >
                <option value="Transaction reference not found in bank account.">Transaction reference not found in bank account.</option>
                <option value="Invalid / Fake UTR number provided.">Invalid / Fake UTR number provided.</option>
                <option value="Duplicate UTR: This transaction reference was already used.">Duplicate UTR: This transaction reference was already used.</option>
                <option value="Payment amount mismatch (Received less than entry fee).">Payment amount mismatch (Received less than entry fee).</option>
                <option value="Payment reversed / chargeback detected.">Payment reversed / chargeback detected.</option>
                <option value="CUSTOM">Other (Custom Reason)</option>
              </select>
            </div>

            {rejectReason === 'CUSTOM' && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Specify Custom Rejection Note:
                </label>
                <textarea
                  rows={2}
                  value={customRejectReason}
                  onChange={(e) => setCustomRejectReason(e.target.value)}
                  placeholder="Explain why payment cannot be confirmed..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-rose-500 text-xs text-white outline-none resize-none"
                />
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setRejectModalReg(null)}
                disabled={actionLoading}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleRejectPayment}
                disabled={actionLoading}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                {actionLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
                <span>Reject Payment</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* RECORD OFFLINE / CASH PAYMENT MODAL */}
      {isManualModalOpen && (
        <Modal
          id="admin-record-offline-modal"
          isOpen={isManualModalOpen}
          onClose={() => setIsManualModalOpen(false)}
          title="Record Offline / Cash Entry Payment"
          subtitle="Manually confirm player payment and issue instant seat allocation"
          maxWidth="lg"
        >
          <form onSubmit={handleManualOfflineSubmit} className="space-y-4 py-1">
            {actionError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{actionError}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Tournament */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Target Tournament: *
                </label>
                <select
                  value={manualTournId}
                  onChange={(e) => setManualTournId(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none cursor-pointer"
                  required
                >
                  {tournaments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.format}) — Fee: ₹{t.entryFee || 50}
                    </option>
                  ))}
                </select>
              </div>

              {/* Player Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Player Name: *
                </label>
                <input
                  type="text"
                  value={manualPlayerName}
                  onChange={(e) => setManualPlayerName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
                  required
                />
              </div>

              {/* In-Game Name */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Free Fire In-Game Name (IGN): *
                </label>
                <input
                  type="text"
                  value={manualIgn}
                  onChange={(e) => setManualIgn(e.target.value)}
                  placeholder="e.g. ⚡VIPER_99⚡"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
                  required
                />
              </div>

              {/* Free Fire UID */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Free Fire UID (8-12 Digits): *
                </label>
                <input
                  type="text"
                  value={manualUid}
                  onChange={(e) => setManualUid(e.target.value)}
                  placeholder="e.g. 1928374650"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white font-mono outline-none"
                  required
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Player Phone / WhatsApp:
                </label>
                <input
                  type="text"
                  value={manualPhone}
                  onChange={(e) => setManualPhone(e.target.value)}
                  placeholder="e.g. +91 9876543210"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
                />
              </div>

              {/* Format */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Format:
                </label>
                <select
                  value={manualFormat}
                  onChange={(e) => setManualFormat(e.target.value as any)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none cursor-pointer"
                >
                  <option value="SOLO">Solo Entry</option>
                  <option value="SQUAD">Squad Team Entry</option>
                </select>
              </div>

              {/* Squad Team Name if Squad */}
              {manualFormat === 'SQUAD' && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Squad Team Name: *
                  </label>
                  <input
                    type="text"
                    value={manualTeamName}
                    onChange={(e) => setManualTeamName(e.target.value)}
                    placeholder="e.g. TEAM SOUL ESPORTS"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
                    required
                  />
                </div>
              )}

              {/* Amount */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Paid Amount (₹): *
                </label>
                <input
                  type="number"
                  min="0"
                  value={manualAmount}
                  onChange={(e) => setManualAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-emerald-400 font-mono font-bold outline-none"
                  required
                />
              </div>

              {/* Payment Mode */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Payment Mode Received:
                </label>
                <select
                  value={manualMethod}
                  onChange={(e) => setManualMethod(e.target.value as any)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none cursor-pointer"
                >
                  <option value="UPI">UPI (GPay / PhonePe / Paytm / QR)</option>
                  <option value="CASH">Cash / Physical Venue</option>
                  <option value="ONLINE">Bank IMPS / NEFT</option>
                  <option value="CARD">Card / POS</option>
                  <option value="WALLET">Wallet</option>
                </select>
              </div>

              {/* UTR / Custom Ref */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  UTR / Payment Reference ID:
                </label>
                <input
                  type="text"
                  value={manualUtr}
                  onChange={(e) => setManualUtr(e.target.value)}
                  placeholder="e.g. 423891029381 or CASH_CONFIRMED"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white font-mono outline-none"
                />
              </div>

              {/* Notes */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Admin Audit Note: {restrictions.requireAdminNotes && <span className="text-rose-400">*</span>}
                </label>
                <input
                  type="text"
                  value={manualNotes}
                  onChange={(e) => setManualNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-emerald-500 text-xs text-white outline-none"
                  required={restrictions.requireAdminNotes}
                />
              </div>

              {/* Physical Receipt Certification Restriction */}
              {restrictions.requireBankStatementCheckbox && (
                <div className="sm:col-span-2 p-3 rounded-xl border bg-slate-900/90 border-slate-800">
                  <label className="flex items-start gap-2 text-xs cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={manualCertChecked}
                      onChange={(e) => setManualCertChecked(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-0 cursor-pointer"
                    />
                    <div className="space-y-0.5">
                      <span className="font-bold text-slate-200 block">
                        Mandatory Cash / Offline Receipt Certification: *
                      </span>
                      <p className="text-[11px] text-slate-400">
                        I certify that the entry fee of <strong className="text-emerald-400">₹{manualAmount}</strong> has been physically received and logged under official esports records.
                      </p>
                    </div>
                  </label>
                </div>
              )}

              {/* Admin Security PIN Restriction */}
              {restrictions.requireSecurityPin && (
                <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Admin Security PIN: *</span>
                    </label>
                    <span className="text-[10px] text-slate-500">Default: 7788</span>
                  </div>
                  <div className="relative">
                    <input
                      type={showManualPin ? 'text' : 'password'}
                      maxLength={10}
                      value={manualPinInput}
                      onChange={(e) => setManualPinInput(e.target.value)}
                      placeholder="Enter 4-digit Security PIN..."
                      className={`w-full pl-3.5 pr-20 py-2 rounded-xl bg-slate-950 border text-xs font-mono font-bold tracking-widest text-white outline-none ${
                        manualPinInput.trim() === restrictions.securityPin.trim()
                          ? 'border-emerald-500 text-emerald-300'
                          : manualPinInput.length > 0
                          ? 'border-rose-500 text-rose-300'
                          : 'border-slate-800 focus:border-cyan-500'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowManualPin(!showManualPin)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 px-2 py-1 rounded text-[10px] font-bold bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                    >
                      {showManualPin ? 'Hide' : 'Show'}
                    </button>
                  </div>
                  {manualPinInput.length > 0 && manualPinInput.trim() !== restrictions.securityPin.trim() && (
                    <p className="text-[10px] text-rose-400">
                      Incorrect PIN. Submission locked.
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsManualModalOpen(false)}
                disabled={actionLoading}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={
                  actionLoading ||
                  (restrictions.requireBankStatementCheckbox && !manualCertChecked) ||
                  (restrictions.requireSecurityPin && manualPinInput.trim() !== restrictions.securityPin.trim())
                }
                className={`px-5 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-all ${
                  (restrictions.requireBankStatementCheckbox && !manualCertChecked) ||
                  (restrictions.requireSecurityPin && manualPinInput.trim() !== restrictions.securityPin.trim())
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 cursor-pointer'
                }`}
              >
                {actionLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                <span>Record & Issue Verified Entry</span>
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ADMIN PAYMENT CONFIRMATION RESTRICTIONS SETTINGS MODAL */}
      {isRestrictionsModalOpen && (
        <Modal
          id="admin-payment-restrictions-modal"
          isOpen={isRestrictionsModalOpen}
          onClose={() => setIsRestrictionsModalOpen(false)}
          title="Payment Confirmation Security & Restrictions"
          subtitle="Configure mandatory safeguards and verification policies for admin payment approvals"
          maxWidth="lg"
        >
          <form onSubmit={handleSaveRestrictions} className="space-y-4 py-1">
            {actionError && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{actionError}</span>
              </div>
            )}

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              {/* Restriction 1: 4-Digit Security PIN */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Require 4-Digit Admin Security PIN for Confirmations</span>
                    </span>
                    <p className="text-[11px] text-slate-400">
                      Admins must enter a secret authorization PIN before any slot is confirmed or offline payment logged.
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={tempRestrictions.requireSecurityPin}
                      onChange={(e) =>
                        setTempRestrictions({ ...tempRestrictions, requireSecurityPin: e.target.checked })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>

                {tempRestrictions.requireSecurityPin && (
                  <div className="pt-2 border-t border-slate-800/80 flex items-center gap-3">
                    <label className="text-xs font-bold text-slate-300 shrink-0">
                      Set Security PIN Code:
                    </label>
                    <input
                      type="text"
                      maxLength={8}
                      value={tempRestrictions.securityPin}
                      onChange={(e) =>
                        setTempRestrictions({ ...tempRestrictions, securityPin: e.target.value })
                      }
                      placeholder="e.g. 7788"
                      className="w-32 px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-500/50 text-xs font-mono font-bold tracking-widest text-cyan-300 text-center outline-none"
                      required
                    />
                    <span className="text-[10px] text-slate-500">
                      (Share this code only with authorized tournament moderators)
                    </span>
                  </div>
                )}
              </div>

              {/* Restriction 2: Strict Duplicate UTR Hard Block */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Strict Duplicate UTR Hard Block</span>
                  </span>
                  <p className="text-[11px] text-slate-400">
                    If an entered or submitted UTR already exists in any registration, block instant approval unless an explicit security override is authorized.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempRestrictions.strictDuplicateUtrBlock}
                    onChange={(e) =>
                      setTempRestrictions({ ...tempRestrictions, strictDuplicateUtrBlock: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Restriction 3: Bank Statement Verification Certification */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Mandatory Bank / Merchant Statement Certification</span>
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Requires admin to manually check an explicit certification box acknowledging they verified the transaction credit in the official bank statement.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempRestrictions.requireBankStatementCheckbox}
                    onChange={(e) =>
                      setTempRestrictions({ ...tempRestrictions, requireBankStatementCheckbox: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Restriction 4: Minimum UTR Length */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-white">
                    Minimum UTR / Reference ID Length
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Rejects dummy or short UTR codes with fewer than the specified character count.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="4"
                    max="20"
                    value={tempRestrictions.minUtrLength}
                    onChange={(e) =>
                      setTempRestrictions({ ...tempRestrictions, minUtrLength: Number(e.target.value) })
                    }
                    className="w-20 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono font-bold text-white text-center outline-none"
                  />
                  <span className="text-xs text-slate-400">chars</span>
                </div>
              </div>

              {/* Restriction 5: Require Admin Notes */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-white">
                    Mandatory Admin Audit Stamp Note
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Disallows empty admin note fields to maintain an auditable verification trail for every confirmation.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={tempRestrictions.requireAdminNotes}
                    onChange={(e) =>
                      setTempRestrictions({ ...tempRestrictions, requireAdminNotes: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsRestrictionsModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Save Restriction Policies</span>
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* PAYMENT RECEIPT VOUCHER MODAL */}
      {receiptModalReg && (
        <Modal
          id="admin-payment-receipt-modal"
          isOpen={Boolean(receiptModalReg)}
          onClose={() => setReceiptModalReg(null)}
          title="Esports Payment Receipt & Seat Voucher"
          subtitle={`Official entry token for ${receiptModalReg.playerName}`}
          maxWidth="md"
        >
          <div className="space-y-4 py-1 font-sans">
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-700 shadow-2xl relative overflow-hidden">
              {/* Header Stamp */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-red-600 to-orange-500 text-white flex items-center justify-center font-black text-xs">
                    FF
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider">
                      IGNITE ESPORTS DESK
                    </h4>
                    <span className="text-[9px] text-orange-400 font-semibold block">
                      Official Tournament Entry Voucher
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-black uppercase">
                    <CheckCircle2 className="w-3 h-3" /> VERIFIED
                  </span>
                </div>
              </div>

              {/* Receipt Body */}
              <div className="grid grid-cols-2 gap-3 py-4 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">Player In-Game Name:</span>
                  <strong className="text-amber-400 text-sm">{receiptModalReg.ign}</strong>
                  <span className="text-[10px] text-slate-400 block mt-0.5">({receiptModalReg.playerName})</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Free Fire UID:</span>
                  <strong className="font-mono text-cyan-400 text-sm">{receiptModalReg.freeFireUid}</strong>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Tournament:</span>
                  <span className="font-bold text-slate-200 block truncate">{receiptModalReg.tournamentTitle}</span>
                  <span className="text-[10px] text-orange-400 font-semibold">{receiptModalReg.format} Stage</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Match & Seat Allocation:</span>
                  <span className="font-bold text-white block">{receiptModalReg.matchName}</span>
                  <span className="inline-block px-2 py-0.5 bg-orange-600/30 text-orange-300 font-mono font-bold rounded text-[10px] border border-orange-500/40 mt-0.5">
                    Seat Slot #{receiptModalReg.seatNumber}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Fee Amount:</span>
                  <span className="font-mono font-black text-emerald-400 text-base">
                    ₹{receiptModalReg.entryFeePaid || 50}
                  </span>
                  <span className="text-[9px] text-slate-500 block">Mode: {receiptModalReg.paymentMethod}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block">Transaction Reference / UTR:</span>
                  <span className="font-mono font-bold text-cyan-300 text-xs block truncate" title={receiptModalReg.utrNumber || receiptModalReg.paymentTransactionId}>
                    {receiptModalReg.utrNumber || receiptModalReg.paymentTransactionId || 'TXN_VERIFIED'}
                  </span>
                  <span className="text-[9px] text-slate-500 block">
                    {new Date(receiptModalReg.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>

              {/* Verification Seal */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                <div>
                  <span>Verified By: <strong className="text-slate-200">{receiptModalReg.verifiedBy || 'Admin Desk'}</strong></span>
                  <span className="block text-slate-500">ID: {receiptModalReg.id}</span>
                </div>
                <div className="p-1 rounded bg-slate-800 border border-slate-700 text-emerald-400 font-mono text-[9px] font-bold">
                  SEAL VALIDATED
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>
              <button
                type="button"
                onClick={() => setReceiptModalReg(null)}
                className="px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
