import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Trophy, 
  Key, 
  Users, 
  Gift, 
  Tv,
  ShieldAlert, 
  Video, 
  Medal, 
  Settings, 
  LogOut, 
  ExternalLink,
  Gamepad2,
  ChevronRight,
  ClipboardList,
  Headphones,
  CreditCard,
  History
} from 'lucide-react';
import { collection, query, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Registration, Tournament } from '../types';
import { AdminDashboardView } from './AdminDashboardView';
import { AdminTournamentsView } from './AdminTournamentsView';
import { AdminMatchDeskView } from './AdminMatchDeskView';
import { AdminRegistrationsView } from './AdminRegistrationsView';
import { AdminPaymentsView } from './AdminPaymentsView';
import { AdminPlayersView } from './AdminPlayersView';
import { AdminAntiCheatView } from './AdminAntiCheatView';
import { AdminRecordingsView } from './AdminRecordingsView';
import { AdminResultsView } from './AdminResultsView';
import { AdminPrizeDeliveryView } from './AdminPrizeDeliveryView';
import { AdminAdAnalyticsView } from './AdminAdAnalyticsView';
import { AdminSettingsView } from './AdminSettingsView';
import { AdminSupportView } from './AdminSupportView';
import { AdminHistoryView } from './AdminHistoryView';
import { useAuth } from '../context/AuthContext';

interface AdminPanelProps {
  onExitToPlayerView: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onExitToPlayerView }) => {
  const { userProfile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [pendingPaymentsCount, setPendingPaymentsCount] = useState<number>(0);
  const [pendingRefundsCount, setPendingRefundsCount] = useState<number>(0);

  useEffect(() => {
    const unsubRegs = onSnapshot(collection(db, 'registrations'), (snap) => {
      let pending = 0;
      snap.forEach((doc) => {
        const data = doc.data() as Registration;
        const isPaid = data.entryType === 'PAID_IN_GAME' || (data.entryFeePaid && data.entryFeePaid > 0) || data.paymentMethod !== 'FREE';
        if (isPaid && (data.paymentStatus || 'PENDING') === 'PENDING') {
          pending++;
        }
      });
      setPendingPaymentsCount(pending);
    });

    const unsubTourns = onSnapshot(collection(db, 'tournaments'), (snap) => {
      let pendingRefunds = 0;
      snap.forEach((doc) => {
        const data = doc.data() as Tournament;
        if (data.status === 'CANCELLED') {
          const req = data.refundsRequiredCount || 0;
          const comp = data.refundsCompletedCount || 0;
          pendingRefunds += Math.max(0, req - comp);
        }
      });
      setPendingRefundsCount(pendingRefunds);
    });

    return () => {
      unsubRegs();
      unsubTourns();
    };
  }, []);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tournaments', label: 'Tournaments', icon: Trophy },
    { 
      id: 'history', 
      label: 'History & Refunds', 
      icon: History,
      badge: pendingRefundsCount > 0 ? pendingRefundsCount : undefined,
      badgeColor: 'bg-amber-600 text-white'
    },
    { id: 'matches', label: 'Match Desk', icon: Key },
    { 
      id: 'payments', 
      label: 'Confirm Payments', 
      icon: CreditCard,
      badge: pendingPaymentsCount > 0 ? pendingPaymentsCount : undefined,
      badgeColor: 'bg-rose-600 text-white'
    },
    { id: 'registrations', label: 'Roster & Entries', icon: ClipboardList },
    { id: 'results', label: 'Results & Standings', icon: Medal },
    { id: 'prizes', label: 'Prize Delivery', icon: Gift },
    { id: 'support', label: 'Support Team', icon: Headphones },
    { id: 'analytics', label: 'Ad Analytics', icon: Tv },
    { id: 'players', label: 'Players Roster', icon: Users },
    { id: 'anticheat', label: 'Anti-Cheat', icon: ShieldAlert },
    { id: 'recordings', label: 'POV Uploads', icon: Video },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div id="admin-panel-container" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col lg:flex-row">
      {/* Mobile Top Admin Header */}
      <div className="lg:hidden sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-3.5 py-3">
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-red-600 to-orange-500 text-white flex items-center justify-center font-black text-xs shadow-md shadow-red-600/30">
              FF
            </div>
            <div>
              <h1 className="text-xs font-black tracking-wider text-white uppercase leading-none">
                ADMIN DESK
              </h1>
              <span className="text-[9px] text-red-400 font-semibold block">
                Free Fire Esports
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onExitToPlayerView}
              className="text-[11px] font-bold text-orange-400 hover:text-white px-2.5 py-1.5 bg-slate-800 border border-orange-500/30 rounded-xl flex items-center gap-1 cursor-pointer"
            >
              <Gamepad2 className="w-3 h-3" /> Player View
            </button>
            <button
              onClick={() => signOut()}
              title="Sign Out"
              className="p-1.5 text-slate-400 hover:text-red-400 bg-slate-800 rounded-xl cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Scrollable Tab Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 -mx-1 px-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`admin-mobile-nav-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-rose-600 text-white">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Desktop Sidebar Navigation */}
      <aside className="hidden lg:flex w-64 bg-slate-900 border-r border-slate-800 flex-col justify-between shrink-0 sticky top-0 h-screen">
        <div>
          {/* Logo Bar */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-red-600 to-orange-500 text-white flex items-center justify-center font-black shadow-lg shadow-red-600/30">
                FF
              </div>
              <div>
                <h1 className="text-xs font-black tracking-wider text-white uppercase">
                  ADMIN DESK
                </h1>
                <span className="text-[10px] text-red-400 font-semibold block">
                  Free Fire MAX Esports
                </span>
              </div>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`admin-nav-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer ${
                    isActive
                      ? 'bg-orange-600 text-white shadow-md shadow-orange-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {item.badge !== undefined && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-black bg-rose-600 text-white shadow-sm">
                        {item.badge}
                      </span>
                    )}
                    {isActive && <ChevronRight className="w-3.5 h-3.5" />}
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* User Footer & Switch to Player View */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            id="admin-switch-player-view"
            onClick={onExitToPlayerView}
            className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-orange-400 border border-orange-500/30 font-bold rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Gamepad2 className="w-3.5 h-3.5" /> Player View
          </button>

          <div className="flex items-center justify-between pt-2 text-xs">
            <div className="truncate">
              <span className="font-bold text-white block truncate">{userProfile?.displayName || 'Admin'}</span>
              <span className="text-[10px] text-red-400 font-bold uppercase tracking-wider">Super Admin</span>
            </div>
            <button
              onClick={() => signOut()}
              title="Sign Out"
              className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-950/40 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-3.5 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        {activeTab === 'dashboard' && <AdminDashboardView onNavigateTab={(tab) => setActiveTab(tab)} />}
        {activeTab === 'tournaments' && <AdminTournamentsView onNavigateToHistory={() => setActiveTab('history')} />}
        {activeTab === 'history' && <AdminHistoryView />}
        {activeTab === 'matches' && <AdminMatchDeskView />}
        {activeTab === 'payments' && <AdminPaymentsView />}
        {activeTab === 'registrations' && <AdminRegistrationsView />}
        {activeTab === 'results' && <AdminResultsView />}
        {activeTab === 'prizes' && <AdminPrizeDeliveryView />}
        {activeTab === 'support' && <AdminSupportView />}
        {activeTab === 'analytics' && <AdminAdAnalyticsView />}
        {activeTab === 'players' && <AdminPlayersView />}
        {activeTab === 'anticheat' && <AdminAntiCheatView />}
        {activeTab === 'recordings' && <AdminRecordingsView />}
        {activeTab === 'settings' && <AdminSettingsView />}
      </main>
    </div>
  );
};
