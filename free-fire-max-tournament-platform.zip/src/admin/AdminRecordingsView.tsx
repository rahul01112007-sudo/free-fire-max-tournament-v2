import React, { useState, useEffect } from 'react';
import { Video, Check, X, ExternalLink, User, Gamepad2 } from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/config';
import { MatchRecording } from '../types';
import { reviewRecording } from '../services/recordingService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const AdminRecordingsView: React.FC = () => {
  const { userProfile } = useAuth();
  const [recordings, setRecordings] = useState<MatchRecording[]>([]);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      query(collection(db, 'recordings'), orderBy('submittedAt', 'desc')),
      (snap) => {
        const list: MatchRecording[] = [];
        snap.forEach((d) => list.push(d.data() as MatchRecording));
        setRecordings(list);
      }
    );
    return () => unsub();
  }, []);

  const handleReview = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const feedback = window.prompt('Admin review feedback / notes for player:', status === 'APPROVED' ? 'POV verified clean and approved.' : 'Incomplete recording submitted.');
    if (feedback === null) return;

    try {
      setProcessingId(id);
      await reviewRecording(id, status, feedback, userProfile?.displayName || 'Admin');
    } catch (e) {
      console.error(e);
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div id="admin-recordings-view" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Video className="w-6 h-6 text-orange-400" />
            Match POV Recordings Review Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit player screen recordings submitted for prize payouts and fair-play validation
          </p>
        </div>
      </div>

      {recordings.length === 0 ? (
        <EmptyState
          id="no-admin-recordings"
          title="No POV recordings submitted yet."
          description="Player screen recording links will appear here after matches conclude."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recordings.map((rec) => (
            <div
              key={rec.id}
              id={`admin-rec-card-${rec.id}`}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {rec.playerName} ({rec.ign})
                  </h4>
                  <p className="text-xs text-slate-400">
                    UID: <span className="font-mono text-slate-300">{rec.freeFireUid}</span> • {rec.matchName}
                  </p>
                </div>
                <StatusBadge status={rec.status} />
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs space-y-1 font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Scope:</span>
                  <span className="text-slate-200">{rec.povType}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Tournament:</span>
                  <span className="text-slate-200">{rec.tournamentTitle}</span>
                </div>
              </div>

              {rec.notes && (
                <p className="text-xs text-slate-300 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/50">
                  <span className="text-orange-400 font-semibold">Player Notes:</span> {rec.notes}
                </p>
              )}

              {rec.adminFeedback && (
                <div className="p-2.5 rounded-lg bg-orange-950/30 border border-orange-500/30 text-xs text-orange-200">
                  <span className="font-bold text-orange-400">Feedback:</span> {rec.adminFeedback}
                </div>
              )}

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <a
                  href={rec.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 font-semibold"
                >
                  Watch Video Proof <ExternalLink className="w-3.5 h-3.5" />
                </a>

                {rec.status === 'PENDING' && (
                  <div className="flex items-center gap-1.5">
                    <button
                      disabled={processingId === rec.id}
                      onClick={() => handleReview(rec.id, 'APPROVED')}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                    >
                      <Check className="w-3 h-3" /> Approve POV
                    </button>
                    <button
                      disabled={processingId === rec.id}
                      onClick={() => handleReview(rec.id, 'REJECTED')}
                      className="px-2.5 py-1 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-lg text-xs font-bold flex items-center gap-1"
                    >
                      <X className="w-3 h-3" /> Reject
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
