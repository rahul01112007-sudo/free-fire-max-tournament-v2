import React, { useState, useEffect } from 'react';
import { 
  History, 
  Trophy, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  RotateCcw, 
  Search, 
  Filter, 
  DollarSign, 
  Users, 
  CreditCard, 
  Copy, 
  Check, 
  ExternalLink, 
  Calendar, 
  ChevronRight, 
  AlertCircle, 
  Edit3, 
  ShieldCheck, 
  ShieldAlert,
  Sparkles,
  RefreshCw,
  Gift,
  X,
  FileSpreadsheet
} from 'lucide-react';
import { 
  Tournament, 
  Registration, 
  getTournamentPrizePositions, 
  formatPrizeAmount, 
  formatEntryFeeDisplay, 
  getPrizePoolLabel,
  isDiamondPrizeType 
} from '../types';
import { listenTournaments } from '../services/tournamentService';
import { 
  listenTournamentRegistrationsForRefund, 
  processPlayerRefund, 
  batchRefundTournamentPlayers,
  isRegistrationDenied
} from '../services/refundService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { Modal } from '../components/Modal';
import { useAuth } from '../context/AuthContext';

export const AdminHistoryView: React.FC = () => {
  const { userProfile } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'CANCELLED' | 'COMPLETED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected tournament for Refund Desk
  const [selectedTournForRefund, setSelectedTournForRefund] = useState<Tournament | null>(null);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [rosterSearch, setRosterSearch] = useState('');
  const [rosterFilter, setRosterFilter] = useState<'ALL' | 'PENDING' | 'REFUNDED' | 'DENIED'>('ALL');

  // Single Refund Modal state
  const [refundingReg, setRefundingReg] = useState<Registration | null>(null);
  const [refundUtrInput, setRefundUtrInput] = useState('');
  const [refundAmountInput, setRefundAmountInput] = useState<number>(0);
  const [refundNotesInput, setRefundNotesInput] = useState('');
  const [isSubmittingRefund, setIsSubmittingRefund] = useState(false);
  const [refundError, setRefundError] = useState<string | null>(null);

  // Batch Refund Modal state
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [batchPrefixInput, setBatchPrefixInput] = useState('');
  const [batchNotesInput, setBatchNotesInput] = useState('');
  const [isSubmittingBatch, setIsSubmittingBatch] = useState(false);

  // Copied states
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = listenTournaments((list) => {
      setTournaments(list);
    });
    return () => unsub();
  }, []);

  // Listen to registrations when a tournament is selected in Refund Desk
  useEffect(() => {
    if (!selectedTournForRefund) {
      setRegistrations([]);
      return;
    }
    const unsub = listenTournamentRegistrationsForRefund(selectedTournForRefund.id, (regs) => {
      setRegistrations(regs);
    });
    return () => unsub();
  }, [selectedTournForRefund?.id]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filter history tournaments (either COMPLETED or CANCELLED)
  const historyTournaments = tournaments.filter(
    (t) => t.status === 'COMPLETED' || t.status === 'CANCELLED'
  );

  const completedTournaments = historyTournaments.filter((t) => t.status === 'COMPLETED');
  const cancelledTournaments = historyTournaments.filter((t) => t.status === 'CANCELLED');

  const filteredTournaments = historyTournaments.filter((t) => {
    if (activeFilter === 'CANCELLED' && t.status !== 'CANCELLED') return false;
    if (activeFilter === 'COMPLETED' && t.status !== 'COMPLETED') return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        (t.cancellationReason && t.cancellationReason.toLowerCase().includes(q)) ||
        t.format.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate high-level summary metrics
  const totalCancelled = cancelledTournaments.length;
  const totalCompleted = completedTournaments.length;

  const pendingRefundsCount = cancelledTournaments.reduce((acc, t) => {
    const required = t.refundsRequiredCount || 0;
    const completed = t.refundsCompletedCount || 0;
    return acc + Math.max(0, required - completed);
  }, 0);

  const totalRefundAmountPending = cancelledTournaments.reduce((acc, t) => {
    const total = t.totalRefundAmount || 0;
    const required = t.refundsRequiredCount || 1;
    const completed = t.refundsCompletedCount || 0;
    const perPlayer = required > 0 ? total / required : 0;
    const pendingCount = Math.max(0, required - completed);
    return acc + Math.round(perPlayer * pendingCount);
  }, 0);

  const handleOpenSingleRefund = (reg: Registration) => {
    setRefundingReg(reg);
    setRefundError(null);
    setRefundUtrInput(reg.refundUtr || '');
    setRefundAmountInput(reg.refundAmount || reg.entryFeePaid || selectedTournForRefund?.entryFee || 0);
    setRefundNotesInput(
      reg.refundNotes || 
      (reg.refundUpiId ? `Transferred via UPI to player ID: ${reg.refundUpiId}` : `UPI refund to player phone: ${reg.phone || 'N/A'}`)
    );
  };

  const handleConfirmSingleRefund = async () => {
    if (!refundingReg || !selectedTournForRefund) return;
    if (!refundUtrInput.trim()) {
      setRefundError('Please enter a valid Refund UTR or Transaction Reference ID.');
      return;
    }

    setIsSubmittingRefund(true);
    setRefundError(null);

    try {
      await processPlayerRefund({
        registrationId: refundingReg.id,
        tournamentId: selectedTournForRefund.id,
        refundUtr: refundUtrInput.trim(),
        refundAmount: Number(refundAmountInput) || 0,
        refundNotes: refundNotesInput.trim(),
        adminName: userProfile?.displayName || 'Admin Desk',
        refundUpiId: refundingReg.refundUpiId || undefined,
      });
      setRefundingReg(null);
    } catch (e: any) {
      console.error('Failed to process refund:', e);
      setRefundError(e?.message || 'Failed to record refund in Firestore.');
    } finally {
      setIsSubmittingRefund(false);
    }
  };

  const handleConfirmBatchRefund = async () => {
    if (!selectedTournForRefund) return;

    setIsSubmittingBatch(true);
    try {
      await batchRefundTournamentPlayers({
        tournamentId: selectedTournForRefund.id,
        baseUtrPrefix: batchPrefixInput.trim() || undefined,
        batchNotes: batchNotesInput.trim() || undefined,
        adminName: userProfile?.displayName || 'Admin Desk',
      });
      setShowBatchModal(false);
    } catch (e: any) {
      console.error('Batch refund failed:', e);
      alert(e?.message || 'Failed to batch refund players.');
    } finally {
      setIsSubmittingBatch(false);
    }
  };

  // Filtered registrations in the Refund Desk
  // Registrations denied/rejected by the admin (e.g. fake payment) must NOT appear in normal refund queues.
  const eligibleRegistrations = registrations.filter((r) => !isRegistrationDenied(r));
  const deniedRegistrations = registrations.filter((r) => isRegistrationDenied(r));
  const deniedCount = deniedRegistrations.length;

  const filteredRoster = registrations.filter((reg) => {
    const isDenied = isRegistrationDenied(reg);

    // If viewing the specialized 'DENIED' tab, only show registrations rejected for fake payment
    if (rosterFilter === 'DENIED') {
      if (!isDenied) return false;
    } else {
      // For ALL, PENDING, REFUNDED tabs, completely exclude denied/rejected fake payments!
      if (isDenied) return false;

      const isRefunded = reg.refundStatus === 'REFUNDED' || reg.paymentStatus === 'REFUNDED';
      if (rosterFilter === 'PENDING' && isRefunded) return false;
      if (rosterFilter === 'REFUNDED' && !isRefunded) return false;
    }

    if (rosterSearch.trim()) {
      const q = rosterSearch.toLowerCase();
      return (
        reg.playerName.toLowerCase().includes(q) ||
        reg.freeFireUid.toLowerCase().includes(q) ||
        reg.ign.toLowerCase().includes(q) ||
        (reg.phone && reg.phone.includes(q)) ||
        (reg.utrNumber && reg.utrNumber.toLowerCase().includes(q)) ||
        (reg.refundUtr && reg.refundUtr.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const rosterPendingCount = eligibleRegistrations.filter(
    (r) => r.refundStatus !== 'REFUNDED' && r.paymentStatus !== 'REFUNDED'
  ).length;

  return (
    <div id="admin-history-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <History className="w-6 h-6 text-orange-400" />
            Tournament History & Refunds Desk
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit finished tournaments, view mid-tournament terminations, and manage entry fee refunds for joined players
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-center gap-1.5 font-medium">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            {historyTournaments.length} Archived Tournaments
          </span>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-white">{totalCompleted}</p>
          <p className="text-[10px] text-slate-500">Fully finished & awarded</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider">Cancelled</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-black text-rose-300">{totalCancelled}</p>
          <p className="text-[10px] text-slate-500">Terminated mid-way / prior</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">Refunds Pending</span>
            <RotateCcw className="w-4 h-4 text-amber-400 animate-pulse" />
          </div>
          <p className="text-2xl font-black text-amber-300">
            {pendingRefundsCount} <span className="text-xs font-normal text-amber-400">players</span>
          </p>
          <p className="text-[10px] text-amber-400/80 font-medium">
            ₹{totalRefundAmountPending.toLocaleString()} to refund
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">Refund System</span>
            <ShieldCheck className="w-4 h-4 text-teal-400" />
          </div>
          <p className="text-sm font-bold text-white mt-1">UPI & Ad Credits</p>
          <p className="text-[10px] text-slate-500">Zero data loss on cancel</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <button
            id="filter-history-all"
            onClick={() => setActiveFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'ALL'
                ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All History ({historyTournaments.length})
          </button>

          <button
            id="filter-history-cancelled"
            onClick={() => setActiveFilter('CANCELLED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeFilter === 'CANCELLED'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-rose-300 border border-slate-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Cancelled & Refunds ({cancelledTournaments.length})
            {pendingRefundsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-rose-950 text-rose-300 border border-rose-600 font-bold">
                {pendingRefundsCount}
              </span>
            )}
          </button>

          <button
            id="filter-history-completed"
            onClick={() => setActiveFilter('COMPLETED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeFilter === 'COMPLETED'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-emerald-300 border border-slate-800'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Finished ({completedTournaments.length})
          </button>
        </div>

        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            id="search-tournament-history"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tournament title or reason..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
          />
        </div>
      </div>

      {/* History Tournaments Grid */}
      {filteredTournaments.length === 0 ? (
        <EmptyState
          id="no-history-tournaments"
          title="No archived tournaments found."
          description="When tournaments are completed or cancelled mid-way, they automatically appear here with their final results or player refund rosters."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTournaments.map((tourn) => {
            const isCancelled = tourn.status === 'CANCELLED';
            const prizePositions = getTournamentPrizePositions(tourn);
            const totalVal = Number(tourn.totalPrizeValue) || Number(tourn.prizePool) || 5000;

            const reqRefunds = tourn.refundsRequiredCount || 0;
            const compRefunds = tourn.refundsCompletedCount || 0;
            const isFullyRefunded = reqRefunds > 0 && compRefunds >= reqRefunds;
            const hasPendingRefunds = reqRefunds > compRefunds;

            return (
              <div
                key={tourn.id}
                id={`history-tourn-card-${tourn.id}`}
                className={`p-5 rounded-2xl bg-slate-900 border transition-all shadow-xl flex flex-col justify-between ${
                  isCancelled
                    ? hasPendingRefunds
                      ? 'border-amber-500/40 hover:border-amber-500/60'
                      : 'border-rose-900/40 hover:border-rose-800'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="space-y-3">
                  {/* Status Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <StatusBadge status={tourn.format} />
                      <StatusBadge status={tourn.status} />
                      {isCancelled && (
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${
                          isFullyRefunded
                            ? 'bg-teal-950/80 text-teal-300 border-teal-500/50'
                            : hasPendingRefunds
                            ? 'bg-amber-950/80 text-amber-300 border-amber-500/60 animate-pulse'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}>
                          {isFullyRefunded ? '100% REFUNDED' : hasPendingRefunds ? 'REFUNDS PENDING' : 'FREE ENTRY REFUNDED'}
                        </span>
                      )}
                    </div>

                    <span className="text-[10px] text-slate-500 font-mono">
                      {tourn.cancelledAt ? new Date(tourn.cancelledAt).toLocaleDateString() : new Date(tourn.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-base font-bold text-white leading-snug">
                      {tourn.title}
                    </h3>
                    {tourn.description && (
                      <p className="text-xs text-slate-400 mt-1 line-clamp-1">
                        {tourn.description}
                      </p>
                    )}
                  </div>

                  {/* Cancelled Notice Box */}
                  {isCancelled && (
                    <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/30 space-y-1.5 text-xs">
                      <div className="flex items-center gap-1.5 text-rose-300 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                        <span>Cancelled Mid-Tournament by Admin</span>
                      </div>
                      <p className="text-[11px] text-rose-200/90 leading-relaxed pl-5">
                        <strong className="text-rose-100">Reason:</strong> {tourn.cancellationReason || 'Admin stopped tournament without completing. Player refunds queued.'}
                      </p>
                      {tourn.cancelledBy && (
                        <p className="text-[10px] text-slate-400 pl-5">
                          Initiated by: <span className="text-slate-300 font-medium">{tourn.cancelledBy}</span>
                        </p>
                      )}
                    </div>
                  )}

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-3 gap-2 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 text-center text-xs">
                    <div>
                      <span className="text-[9px] text-slate-500 block font-semibold uppercase">ENTRY FEE</span>
                      <span className="font-extrabold text-cyan-400">
                        {formatEntryFeeDisplay(tourn)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block font-semibold uppercase">ROSTER</span>
                      <span className="font-extrabold text-emerald-400">
                        {tourn.registeredCount} Players
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block font-semibold uppercase">
                        {isCancelled ? 'REFUND STATUS' : 'PRIZE POOL'}
                      </span>
                      <span className={`font-extrabold ${isCancelled ? (hasPendingRefunds ? 'text-amber-400' : 'text-teal-400') : 'text-amber-400'}`}>
                        {isCancelled ? `${compRefunds}/${reqRefunds} Done` : formatPrizeAmount(totalVal, tourn.prizeType || tourn.rewardType)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Bar */}
                <div className="pt-4 mt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-400">
                    {isCancelled ? (
                      <span className={hasPendingRefunds ? 'text-amber-400 font-bold' : 'text-teal-400 font-medium'}>
                        {hasPendingRefunds 
                          ? `⚠️ ${reqRefunds - compRefunds} players awaiting money`
                          : '✓ All joined players refunded'}
                      </span>
                    ) : (
                      <span className="text-emerald-400 font-medium">
                        ✓ Tournament Completed & Verified
                      </span>
                    )}
                  </div>

                  <button
                    id={`open-refund-desk-btn-${tourn.id}`}
                    onClick={() => setSelectedTournForRefund(tourn)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                      isCancelled
                        ? 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white shadow-md shadow-orange-600/20'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                  >
                    {isCancelled ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5" />
                        Manage Refunds
                      </>
                    ) : (
                      <>
                        <Users className="w-3.5 h-3.5" />
                        View Roster
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Interactive Refund Desk Modal */}
      {selectedTournForRefund && (
        <Modal
          id="refund-desk-modal"
          isOpen={true}
          onClose={() => setSelectedTournForRefund(null)}
          title={`Tournament Roster & Refund Desk: ${selectedTournForRefund.title}`}
          subtitle={`Inspect joined players, verify payments, and process UPI refund transactions with UTR numbers`}
          maxWidth="2xl"
        >
          <div className="space-y-5">
            {/* Top Summary Box */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Status</span>
                <span className="text-xs font-bold text-rose-400 uppercase">
                  {selectedTournForRefund.status}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Entry Ticket</span>
                <span className="text-xs font-bold text-cyan-400">
                  {formatEntryFeeDisplay(selectedTournForRefund)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Joined Players</span>
                <span className="text-xs font-bold text-white">
                  {eligibleRegistrations.length} Eligible
                </span>
                {deniedCount > 0 && (
                  <span className="text-[10px] text-rose-400 block font-semibold">
                    ({deniedCount} Denied Excluded)
                  </span>
                )}
              </div>
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block">Refund Progress</span>
                <span className={`text-xs font-bold ${rosterPendingCount > 0 ? 'text-amber-400' : 'text-teal-400'}`}>
                  {eligibleRegistrations.length - rosterPendingCount} / {eligibleRegistrations.length} Handled
                </span>
              </div>
            </div>

            {/* Action & Filter Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 flex-wrap">
                <button
                  onClick={() => setRosterFilter('ALL')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    rosterFilter === 'ALL'
                      ? 'bg-orange-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All Eligible ({eligibleRegistrations.length})
                </button>
                <button
                  onClick={() => setRosterFilter('PENDING')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    rosterFilter === 'PENDING'
                      ? 'bg-amber-600 text-white'
                      : 'text-slate-400 hover:text-amber-300'
                  }`}
                >
                  Pending ({rosterPendingCount})
                </button>
                <button
                  onClick={() => setRosterFilter('REFUNDED')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    rosterFilter === 'REFUNDED'
                      ? 'bg-teal-600 text-white'
                      : 'text-slate-400 hover:text-teal-300'
                  }`}
                >
                  Refunded ({eligibleRegistrations.length - rosterPendingCount})
                </button>
                {deniedCount > 0 && (
                  <button
                    onClick={() => setRosterFilter('DENIED')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      rosterFilter === 'DENIED'
                        ? 'bg-rose-700 text-white'
                        : 'text-rose-400 hover:text-rose-300'
                    }`}
                  >
                    <span>Denied / Fake ({deniedCount})</span>
                    <span className="text-[9px] uppercase px-1 py-0.2 bg-rose-950/80 rounded border border-rose-500/40">Excluded</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1 sm:w-48">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={rosterSearch}
                    onChange={(e) => setRosterSearch(e.target.value)}
                    placeholder="Search player, UID, phone..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-2.5 py-1 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                  />
                </div>

                {rosterPendingCount > 0 && selectedTournForRefund.status === 'CANCELLED' && (
                  <button
                    id="btn-batch-refund-players"
                    onClick={() => {
                      setBatchPrefixInput(`UPI-REFUND-${Date.now().toString().slice(-6)}`);
                      setBatchNotesInput(`Tournament cancelled refund issued to player`);
                      setShowBatchModal(true);
                    }}
                    className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-colors shadow-sm shrink-0"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Batch Refund ({rosterPendingCount})
                  </button>
                )}
              </div>
            </div>

            {/* Notification alert banner when fake/denied payments are present */}
            {deniedCount > 0 && rosterFilter !== 'DENIED' && (
              <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    <strong>{deniedCount} player registration{deniedCount > 1 ? 's were' : ' was'} denied/rejected</strong> for fake or unverified payment and automatically excluded from the refund desk.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setRosterFilter('DENIED')}
                  className="text-xs text-rose-300 hover:text-white underline font-semibold cursor-pointer shrink-0"
                >
                  View Excluded List ({deniedCount})
                </button>
              </div>
            )}

            {/* Players Table / List */}
            <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
              {filteredRoster.length === 0 ? (
                <div className="p-8 text-center bg-slate-950/60 rounded-2xl border border-slate-800/80 space-y-1">
                  <p className="text-xs font-bold text-slate-300">No matching players in this roster view.</p>
                  <p className="text-[11px] text-slate-500">Try changing your search query or status filter.</p>
                </div>
              ) : (
                filteredRoster.map((reg) => {
                  const isDeniedReg = isRegistrationDenied(reg);
                  const isRefunded = reg.refundStatus === 'REFUNDED' || reg.paymentStatus === 'REFUNDED';
                  const isPaid = reg.entryType === 'PAID_IN_GAME' || (reg.entryFeePaid && reg.entryFeePaid > 0) || reg.paymentMethod !== 'FREE';
                  const fee = reg.entryFeePaid || selectedTournForRefund.entryFee || 0;

                  return (
                    <div
                      key={reg.id}
                      id={`refund-row-${reg.id}`}
                      className={`p-3.5 rounded-xl bg-slate-950 border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isDeniedReg
                          ? 'border-rose-900/50 bg-rose-950/10'
                          : isRefunded
                          ? 'border-teal-900/40 bg-slate-950/80'
                          : 'border-amber-500/30 hover:border-amber-500/50'
                      }`}
                    >
                      {/* Player Info */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-white">{reg.ign || reg.playerName}</span>
                          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-1.5 py-0.2 rounded">
                            UID: {reg.freeFireUid}
                          </span>
                          {reg.seatNumber && (
                            <span className="text-[10px] font-bold text-slate-400 bg-slate-900 px-1.5 py-0.2 rounded border border-slate-800">
                              Seat #{reg.seatNumber}
                            </span>
                          )}
                          {isDeniedReg && (
                            <span className="text-[10px] font-bold text-rose-300 bg-rose-950/80 px-2 py-0.5 rounded border border-rose-500/50 flex items-center gap-1">
                              <ShieldAlert className="w-3 h-3 text-rose-400" />
                              PAYMENT REJECTED / DENIED
                            </span>
                          )}
                        </div>

                        {isDeniedReg ? (
                          <div className="text-[11px] text-rose-300 space-y-0.5 pt-0.5">
                            <p>
                              <strong>Rejection Reason:</strong> {reg.paymentNotes || 'Fake payment or invalid transaction reference detected.'}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">
                              Submitted UTR: {reg.utrNumber || reg.paymentTransactionId || 'None'} • Excluded from refund queue
                            </p>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center gap-3 text-[11px] text-slate-400 flex-wrap">
                              {reg.refundUpiId ? (
                                <span className="flex items-center gap-1.5">
                                  <span className="text-emerald-400 font-bold">Payout UPI:</span>
                                  <span className="font-mono font-bold text-emerald-200 bg-emerald-950/70 px-2 py-0.5 rounded border border-emerald-500/40 flex items-center gap-1">
                                    {reg.refundUpiId}
                                    <button
                                      type="button"
                                      onClick={() => copyToClipboard(reg.refundUpiId!, `upi-${reg.id}`)}
                                      title="Copy Player UPI ID"
                                      className="text-emerald-400 hover:text-white cursor-pointer"
                                    >
                                      {copiedId === `upi-${reg.id}` ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                  </span>
                                </span>
                              ) : !isRefunded ? (
                                <span className="text-[10px] text-amber-400 bg-amber-950/50 px-2 py-0.5 rounded border border-amber-500/30">
                                  Awaiting player UPI ID ({reg.phone || 'no phone'})
                                </span>
                              ) : reg.phone ? (
                                <span>
                                  Phone: <strong className="text-slate-300">{reg.phone}</strong>
                                </span>
                              ) : null}

                              <span>
                                Entry: <strong className={isPaid ? 'text-amber-400' : 'text-emerald-400'}>{isPaid ? `₹${fee} Paid` : 'Free (5 Ads)'}</strong>
                              </span>
                              {reg.utrNumber && (
                                <span className="flex items-center gap-1 font-mono">
                                  Txn Ref: <strong className="text-slate-300">{reg.utrNumber}</strong>
                                  <button
                                    onClick={() => copyToClipboard(reg.utrNumber, `txn-${reg.id}`)}
                                    title="Copy Transaction ID"
                                    className="text-slate-500 hover:text-white cursor-pointer"
                                  >
                                    {copiedId === `txn-${reg.id}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                  </button>
                                </span>
                              )}
                            </div>

                            {/* Refund Details If Already Processed */}
                            {isRefunded && (
                              <div className="pt-1 text-[11px] text-teal-300 flex items-center gap-2 flex-wrap">
                                <span className="font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
                                  Refunded {reg.refundAmount ? `₹${reg.refundAmount}` : 'Pass Restored'}
                                </span>
                                {reg.refundUtr && (
                                  <span className="font-mono bg-teal-950/60 px-1.5 py-0.2 rounded border border-teal-500/30 flex items-center gap-1">
                                    Refund UTR: {reg.refundUtr}
                                    <button
                                      onClick={() => copyToClipboard(reg.refundUtr!, `ref-${reg.id}`)}
                                      className="text-teal-400 hover:text-white cursor-pointer"
                                    >
                                      {copiedId === `ref-${reg.id}` ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />}
                                    </button>
                                  </span>
                                )}
                                {reg.refundedAt && (
                                  <span className="text-[10px] text-slate-500">
                                    on {new Date(reg.refundedAt).toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            )}
                          </>
                        )}
                      </div>

                      {/* Action Button */}
                      <div className="flex items-center gap-2 self-end sm:self-center">
                        {isDeniedReg ? (
                          <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-500 font-semibold italic">
                            No Refund Applicable
                          </span>
                        ) : isRefunded ? (
                          <button
                            id={`btn-edit-refund-${reg.id}`}
                            onClick={() => handleOpenSingleRefund(reg)}
                            className="px-3 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <Edit3 className="w-3 h-3" />
                            Edit UTR
                          </button>
                        ) : (
                          <button
                            id={`btn-issue-refund-${reg.id}`}
                            onClick={() => handleOpenSingleRefund(reg)}
                            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-md shadow-orange-600/30"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            Issue Refund
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
              <span className="text-slate-400">
                All refunds recorded here are instantly reflected in the player's personal tournament history view.
              </span>
              <button
                onClick={() => setSelectedTournForRefund(null)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer transition-colors"
              >
                Close Desk
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Single Player Refund Modal */}
      {refundingReg && selectedTournForRefund && (
        <Modal
          id="single-refund-modal"
          isOpen={true}
          onClose={() => {
            if (!isSubmittingRefund) setRefundingReg(null);
          }}
          title="Record Player Refund"
          subtitle={`Enter the bank/UPI transaction reference number (UTR) to confirm refund to player`}
          maxWidth="md"
        >
          <div className="space-y-4">
            {refundError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{refundError}</span>
              </div>
            )}

            {/* Target Player Summary */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Player IGN:</span>
                <span className="font-bold text-white">{refundingReg.ign || refundingReg.playerName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Free Fire UID:</span>
                <span className="font-mono text-cyan-400 font-bold">{refundingReg.freeFireUid}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Player Phone:</span>
                <span className="font-bold text-slate-200">{refundingReg.phone || 'Not provided'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Original Entry Fee:</span>
                <span className="font-bold text-amber-400">
                  {refundingReg.entryFeePaid ? `₹${refundingReg.entryFeePaid}` : 'Free'} ({refundingReg.paymentMethod || 'UPI'})
                </span>
              </div>
            </div>

            {/* Prominent Player UPI ID Card for Admin Payout */}
            {refundingReg.refundUpiId ? (
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-teal-950/60 to-emerald-950/40 border border-emerald-500/50 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-emerald-300 font-bold uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Player's Submitted Refund UPI ID:
                  </span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                    Ready for Transfer
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950 border border-emerald-500/40">
                  <span className="font-mono text-sm font-black text-white">{refundingReg.refundUpiId}</span>
                  <button
                    type="button"
                    id="btn-copy-player-upi-modal"
                    onClick={() => copyToClipboard(refundingReg.refundUpiId!, 'modal-upi')}
                    className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    {copiedId === 'modal-upi' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'modal-upi' ? 'Copied!' : 'Copy UPI'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-300 leading-tight">
                  1. Open your UPI app (PhonePe / GPay / Paytm) and transfer ₹{refundAmountInput} to <strong className="text-white font-mono">{refundingReg.refundUpiId}</strong>.<br />
                  2. Copy the 12-digit transaction UTR from your bank app and paste it below.
                </p>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Player has not submitted a specific UPI ID yet</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  The player was instructed in their My Match / History view to submit their UPI ID. If you already contacted them, you can refund directly to their registered phone: <strong className="text-white font-mono">{refundingReg.phone || 'on file'}</strong>.
                </p>
              </div>
            )}

            {/* Inputs */}
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Refund Amount (₹) <span className="text-rose-400">*</span>
                </label>
                <input
                  id="input-refund-amount"
                  type="number"
                  value={refundAmountInput}
                  onChange={(e) => setRefundAmountInput(Number(e.target.value))}
                  placeholder="20"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Refund UTR / Bank Reference Number <span className="text-rose-400">*</span>
                </label>
                <input
                  id="input-refund-utr"
                  type="text"
                  value={refundUtrInput}
                  onChange={(e) => setRefundUtrInput(e.target.value)}
                  placeholder="e.g. 425619283741 or UPI/REF/..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  The player will see this UTR in their personal Tournament History view to verify receipt in their bank statement.
                </span>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Admin Refund Note
                </label>
                <input
                  id="input-refund-notes"
                  type="text"
                  value={refundNotesInput}
                  onChange={(e) => setRefundNotesInput(e.target.value)}
                  placeholder="e.g. Refund sent to GPay linked to phone"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isSubmittingRefund}
                onClick={() => setRefundingReg(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                id="btn-confirm-record-refund"
                type="button"
                disabled={isSubmittingRefund}
                onClick={handleConfirmSingleRefund}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-teal-600/30 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmittingRefund ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Recording...
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Confirm Refund
                  </>
                )}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Batch Refund Modal */}
      {showBatchModal && selectedTournForRefund && (
        <Modal
          id="batch-refund-modal"
          isOpen={true}
          onClose={() => {
            if (!isSubmittingBatch) setShowBatchModal(false);
          }}
          title="Batch Refund All Pending Players"
          subtitle={`Automatically mark all ${rosterPendingCount} pending registered players as refunded`}
          maxWidth="md"
        >
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold text-amber-200">
                  You are about to batch refund {rosterPendingCount} pending player(s).
                </p>
                <p className="text-[11px] text-amber-300/80">
                  This will generate unique sequential refund reference IDs for all joined players and mark the tournament's refund status as 100% completed.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Base UTR / Batch Reference Prefix
                </label>
                <input
                  id="input-batch-prefix"
                  type="text"
                  value={batchPrefixInput}
                  onChange={(e) => setBatchPrefixInput(e.target.value)}
                  placeholder="e.g. UPI-BATCH-REFUND"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Batch Refund Note
                </label>
                <input
                  id="input-batch-notes"
                  type="text"
                  value={batchNotesInput}
                  onChange={(e) => setBatchNotesInput(e.target.value)}
                  placeholder="e.g. Tournament cancelled by Admin. Bulk UPI refund issued."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isSubmittingBatch}
                onClick={() => setShowBatchModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                id="btn-confirm-batch-refund"
                type="button"
                disabled={isSubmittingBatch}
                onClick={handleConfirmBatchRefund}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmittingBatch ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing Batch...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-3.5 h-3.5" />
                    Execute Batch Refund
                  </>
                )}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
