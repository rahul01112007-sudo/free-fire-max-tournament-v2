import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Users, 
  Gamepad2, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  Tv, 
  Flame, 
  Plus, 
  Key, 
  Video, 
  ArrowRight,
  Gift,
  TrendingUp,
  Ticket
} from 'lucide-react';
import { collection, query, onSnapshot, getDocs } from 'firebase/firestore';
import { db } from '../firebase/config';
import { Tournament, TournamentMatch, Registration, AntiCheatReport, MatchRecording, AdEntryProgress, PrizeDelivery, DEFAULT_SOLO_PRIZES, DEFAULT_SQUAD_PRIZES } from '../types';
import { CreateTournamentModal } from './CreateTournamentModal';
import { createTournamentWithMatches } from '../services/tournamentService';
import { useAuth } from '../context/AuthContext';

interface AdminDashboardViewProps {
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({ onNavigateTab }) => {
  const { userProfile } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [matches, setMatches] = useState<TournamentMatch[]>([]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [adProgressList, setAdProgressList] = useState<AdEntryProgress[]>([]);
  const [deliveries, setDeliveries] = useState<PrizeDelivery[]>([]);
  const [reports, setReports] = useState<AntiCheatReport[]>([]);
  const [recordings, setRecordings] = useState<MatchRecording[]>([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [presetLoading, setPresetLoading] = useState(false);

  useEffect(() => {
    const unsubTourn = onSnapshot(collection(db, 'tournaments'), (snap) => {
      const list: Tournament[] = [];
      snap.forEach((d) => list.push(d.data() as Tournament));
      setTournaments(list);
    });

    const unsubMatches = onSnapshot(collection(db, 'matches'), (snap) => {
      const list: TournamentMatch[] = [];
      snap.forEach((d) => list.push(d.data() as TournamentMatch));
      setMatches(list);
    });

    const unsubRegs = onSnapshot(collection(db, 'registrations'), (snap) => {
      const list: Registration[] = [];
      snap.forEach((d) => list.push(d.data() as Registration));
      setRegistrations(list);
    });

    const unsubAds = onSnapshot(collection(db, 'adEntryProgress'), (snap) => {
      const list: AdEntryProgress[] = [];
      snap.forEach((d) => list.push(d.data() as AdEntryProgress));
      setAdProgressList(list);
    });

    const unsubPrizes = onSnapshot(collection(db, 'prizeDeliveries'), (snap) => {
      const list: PrizeDelivery[] = [];
      snap.forEach((d) => list.push(d.data() as PrizeDelivery));
      setDeliveries(list);
    });

    const unsubReports = onSnapshot(collection(db, 'antiCheatReports'), (snap) => {
      const list: AntiCheatReport[] = [];
      snap.forEach((d) => list.push(d.data() as AntiCheatReport));
      setReports(list);
    });

    const unsubRecordings = onSnapshot(collection(db, 'recordings'), (snap) => {
      const list: MatchRecording[] = [];
      snap.forEach((d) => list.push(d.data() as MatchRecording));
      setRecordings(list);
    });

    return () => {
      unsubTourn();
      unsubMatches();
      unsubRegs();
      unsubAds();
      unsubPrizes();
      unsubReports();
      unsubRecordings();
    };
  }, []);

  const totalTournaments = tournaments.length;
  const openTournaments = tournaments.filter((t) => t.status === 'REGISTRATION_OPEN').length;
  const totalRegistrations = registrations.length;
  const totalVerifiedAds = adProgressList.reduce((acc, p) => acc + (p.adsCompleted || 0), 0);
  const ticketsGenerated = adProgressList.filter((p) => p.entryUnlocked || (p.adsCompleted || 0) >= (p.adsRequired || 5)).length;
  const activeMatches = matches.filter((m) => m.status === 'ACTIVE').length;
  const completedMatches = matches.filter((m) => m.status === 'COMPLETED').length;
  const soloPlayers = registrations.filter((r) => r.format === 'SOLO').length;
  const squadTeams = registrations.filter((r) => r.format === 'SQUAD').length;
  const pendingReports = reports.filter((r) => r.status === 'PENDING' || r.status === 'UNDER_REVIEW').length;
  const pendingPrizes = deliveries.filter((d) => d.status !== 'SENT' && d.status !== 'CLAIMED').length;
  const prizesSentValue = deliveries.filter((d) => d.status === 'SENT' || d.status === 'CLAIMED').reduce((acc, d) => acc + (Number(d.prizeValue) || 0), 0);
  const totalPrizeAllocated = deliveries.reduce((acc, d) => acc + (Number(d.prizeValue) || 0), 0);

  const handleQuickCreateSolo = async () => {
    try {
      setPresetLoading(true);
      await createTournamentWithMatches({
        title: 'FREE FIRE MAX — SOLO SURVIVOR CHAMPIONSHIP',
        format: 'SOLO',
        maxParticipants: 528,
        participantsPerMatch: 48,
        qualifiersCount: 11,
        advancingPerMatch: 3,
        entryFee: 0,
        adsRequired: 5,
        prizeType: 'AMAZON GIFT CARD',
        prizePool: 8000,
        prizePositions: [
          { position: 1, label: '1st Place (Solo Champion)', amount: 4000 },
          { position: 2, label: '2nd Place (Runner-up)', amount: 2000 },
          { position: 3, label: '3rd Place', amount: 1000 },
          { position: 4, label: '4th Place', amount: 600 },
          { position: 5, label: '5th Place', amount: 400 },
        ],
        prizeDistribution: DEFAULT_SOLO_PRIZES,
        firstPrize: DEFAULT_SOLO_PRIZES.first,
        secondPrize: DEFAULT_SOLO_PRIZES.second,
        thirdPrize: DEFAULT_SOLO_PRIZES.third,
        fourthPrize: DEFAULT_SOLO_PRIZES.fourth,
        fifthPrize: DEFAULT_SOLO_PRIZES.fifth,
        startDate: new Date().toISOString().split('T')[0],
        startTime: '18:00 IST',
        description: '528 players • 11 qualifier matches (48 seats each) • Top 3 survivors advance to Match #12 Grand Final (33 finalists). Total Prize Pool: ₹8,000 Amazon Gift Cards. 100% Free Entry (Watch 5 Rewarded Ads).',
        rules: 'Screen recording mandatory for top 5 winners. Spectator off. Fair play strictly enforced. Amazon Gift Cards dispatched directly upon match verification.',
        createdBy: userProfile?.displayName || 'Admin',
      });
    } catch (e) {
      console.error(e);
    } finally {
      setPresetLoading(false);
    }
  };

  const handleQuickCreateSquad = async () => {
    try {
      setPresetLoading(true);
      await createTournamentWithMatches({
        title: 'FREE FIRE MAX — SQUAD WARLORDS',
        format: 'SQUAD',
        maxParticipants: 108,
        participantsPerMatch: 12,
        qualifiersCount: 9,
        advancingPerMatch: 3,
        entryFee: 0,
        adsRequired: 5,
        prizeType: 'AMAZON GIFT CARD',
        prizePool: 7000,
        prizePositions: [
          { position: 1, label: '1st Place (Champion Squad)', amount: 3500 },
          { position: 2, label: '2nd Place (Runner-up Squad)', amount: 1800 },
          { position: 3, label: '3rd Place Squad', amount: 900 },
          { position: 4, label: '4th Place Squad', amount: 500 },
          { position: 5, label: '5th Place Squad', amount: 300 },
        ],
        prizeDistribution: DEFAULT_SQUAD_PRIZES,
        firstPrize: DEFAULT_SQUAD_PRIZES.first,
        secondPrize: DEFAULT_SQUAD_PRIZES.second,
        thirdPrize: DEFAULT_SQUAD_PRIZES.third,
        fourthPrize: DEFAULT_SQUAD_PRIZES.fourth,
        fifthPrize: DEFAULT_SQUAD_PRIZES.fifth,
        startDate: new Date().toISOString().split('T')[0],
        startTime: '20:00 IST',
        description: '108 squad teams • 9 qualifiers (12 teams each) • Top 3 advance to Semifinals and Grand Final showdown. Total Prize Pool: ₹7,000 Amazon Gift Cards. 100% Free Entry (Watch 5 Rewarded Ads).',
        rules: '4 players per roster. No emulator. POV required for prize payout for top 5 teams. Amazon Gift Cards dispatched directly upon match verification.',
        createdBy: userProfile?.displayName || 'Admin',
      });
    } catch (e) {
      console.error(e);
    } finally {
      setPresetLoading(false);
    }
  };

  return (
    <div id="admin-dashboard-view" className="space-y-6">
      {/* Top Banner with Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-red-950/50 via-slate-900 to-slate-900 border border-red-900/40">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-extrabold tracking-wider uppercase border border-red-500/30">
              Admin Operations Center
            </span>
            <span className="text-xs text-slate-400">• Free-to-Enter Rewarded Esports</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Tournament Management & Prize Desk
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time synchronization of 48-seat match rosters, rewarded-ad verifications, custom room keys & gift card fulfillments
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="admin-btn-create-tourn"
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Create Custom Tournament
          </button>
        </div>
      </div>

      {/* Real Statistics Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div 
          id="stat-tournaments" 
          onClick={() => onNavigateTab('tournaments')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Tournaments</span>
            <Trophy className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{totalTournaments}</div>
          <div className="text-[10px] text-emerald-400 font-semibold">{openTournaments} Open for reg</div>
        </div>

        <div 
          id="stat-registrations" 
          onClick={() => onNavigateTab('registrations')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Roster Entries</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{totalRegistrations}</div>
          <div className="text-[10px] text-slate-400">
            {soloPlayers} Solo • {squadTeams} Squads
          </div>
        </div>

        <div 
          id="stat-ads-completed" 
          onClick={() => onNavigateTab('analytics')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Verified Ads</span>
            <Tv className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-black text-orange-400 font-mono">
            {totalVerifiedAds}
          </div>
          <div className="text-[10px] text-slate-400">{ticketsGenerated} tickets generated</div>
        </div>

        <div 
          id="stat-matches" 
          onClick={() => onNavigateTab('matches')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Active Matches</span>
            <Gamepad2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{activeMatches}</div>
          <div className="text-[10px] text-slate-400">{completedMatches} Completed</div>
        </div>

        <div 
          id="stat-prizes-desk" 
          onClick={() => onNavigateTab('prizes')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Prizes Sent</span>
            <Gift className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">₹{prizesSentValue.toLocaleString()}</div>
          <div className="text-[10px] text-amber-400 font-semibold">{pendingPrizes} pending fulfillment</div>
        </div>

        <div 
          id="stat-anticheat" 
          onClick={() => onNavigateTab('anticheat')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all space-y-1"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider">Anti-Cheat Flags</span>
            <ShieldAlert className="w-4 h-4 text-red-400" />
          </div>
          <div className={`text-2xl font-black font-mono ${pendingReports > 0 ? 'text-red-400' : 'text-white'}`}>
            {pendingReports}
          </div>
          <div className="text-[10px] text-slate-400">{recordings.length} POV uploads</div>
        </div>
      </div>

      {/* 1-Click Tournament Presets Builder */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-500" />
              1-Click Tournament Presets Generator (100% Free Entry)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Instantly provision Free Fire MAX tournament architectures with all qualifiers (48 seats per match) & locked Grand Final in Firestore
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Solo Championship Preset */}
          <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase">
                  FREE ENTRY (5 ADS) • 528 PLAYERS
                </span>
                <span className="text-xs font-bold text-amber-400">₹8,000 AMAZON GIFT CARDS</span>
              </div>
              <h4 className="text-sm font-bold text-white mt-1.5">
                FREE FIRE MAX — SOLO SURVIVOR CHAMPIONSHIP
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Generates Match #1 to #11 (48 seats each) + Match #12 Grand Final (33 finalists locked). 100% Free Entry.
              </p>
            </div>

            <button
              id="quick-create-solo-btn"
              disabled={presetLoading}
              onClick={handleQuickCreateSolo}
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              {presetLoading ? 'Deploying to Firestore...' : 'Generate Solo Championship (Free Entry)'}
            </button>
          </div>

          {/* Squad Warlords Preset */}
          <div className="p-4 rounded-xl bg-slate-950 border border-purple-500/30 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase">
                  FREE ENTRY (5 ADS) • 108 TEAMS
                </span>
                <span className="text-xs font-bold text-purple-400">₹7,000 AMAZON GIFT CARDS</span>
              </div>
              <h4 className="text-sm font-bold text-white mt-1.5">
                FREE FIRE MAX — SQUAD WARLORDS
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Generates Match #1 to #9 (12 squad slots each) + Semifinals & Grand Final. 100% Free Entry.
              </p>
            </div>

            <button
              id="quick-create-squad-btn"
              disabled={presetLoading}
              onClick={handleQuickCreateSquad}
              className="w-full py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              {presetLoading ? 'Deploying to Firestore...' : 'Generate Squad Warlords (Free Entry)'}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div 
          onClick={() => onNavigateTab('matches')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-orange-500/50 cursor-pointer transition-all group"
        >
          <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Key className="w-4 h-4" />
          </div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
            Match Desk & Custom Rooms
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-orange-400 transition-colors" />
          </h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Allocate seats, enter custom room credentials, and broadcast realtime unlock to players.
          </p>
        </div>

        <div 
          onClick={() => onNavigateTab('prizes')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition-all group"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Gift className="w-4 h-4" />
          </div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
            Prize Fulfillment Desk
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
          </h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Audit anti-cheat clearance and manually dispatch official digital gift cards with delivery reference tracking.
          </p>
        </div>

        <div 
          onClick={() => onNavigateTab('analytics')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 cursor-pointer transition-all group"
        >
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Tv className="w-4 h-4" />
          </div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
            Rewarded Ad Analytics
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
          </h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Monitor verified completions, 5-ad entry unlock conversion, and configurable ad network yield modeling.
          </p>
        </div>

        <div 
          onClick={() => onNavigateTab('anticheat')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-red-500/50 cursor-pointer transition-all group"
        >
          <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
            Anti-Cheat & Fair Play
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-red-400 transition-colors" />
          </h4>
          <p className="text-[11px] text-slate-400 mt-1">
            Investigate suspicious headshot ratios, aimbot video proofs, and ban fair play violators.
          </p>
        </div>
      </div>

      <CreateTournamentModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSuccess={() => setIsCreateModalOpen(false)}
      />
    </div>
  );
};

