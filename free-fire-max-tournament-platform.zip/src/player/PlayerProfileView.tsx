import React, { useState, useEffect } from 'react';
import { User, Shield, Gamepad2, Phone, Mail, Save, CheckCircle2, AlertCircle, Headphones, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { updateUserProfile } from '../services/authService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';

interface PlayerProfileViewProps {
  onOpenPlayerAuth: () => void;
  onOpenSupport?: () => void;
}

export const PlayerProfileView: React.FC<PlayerProfileViewProps> = ({ onOpenPlayerAuth, onOpenSupport }) => {
  const { currentUser, userProfile, refreshProfile } = useAuth();
  const [displayName, setDisplayName] = useState('');
  const [freeFireUid, setFreeFireUid] = useState('');
  const [ign, setIgn] = useState('');
  const [phone, setPhone] = useState('');
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setFreeFireUid(userProfile.freeFireUid || '');
      setIgn(userProfile.ign || '');
      setPhone(userProfile.phone || '');
    }
  }, [userProfile]);

  if (!currentUser || !userProfile) {
    return (
      <EmptyState
        id="profile-signin-empty"
        title="Sign In to Access Player Profile"
        description="Configure your Free Fire UID, In-Game Name (IGN), and WhatsApp number to auto-fill tournament registrations."
        actionText="Sign In / Register"
        onAction={onOpenPlayerAuth}
      />
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(false);

    try {
      setSaving(true);
      await updateUserProfile(currentUser.uid, {
        displayName: displayName.trim(),
        freeFireUid: freeFireUid.trim(),
        ign: ign.trim(),
        phone: phone.trim(),
      });
      await refreshProfile();
      setSuccessMsg(true);
      setTimeout(() => setSuccessMsg(false), 3000);
    } catch (err: any) {
      console.warn('Profile update notice:', err?.message || err);
      setError(err.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div id="player-profile-view" className="max-w-2xl mx-auto space-y-6">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
          <User className="w-6 h-6 text-orange-400" />
          Player Profile & Esports Identity
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Your Free Fire MAX player credentials used for match assignments and room verification
        </p>
      </div>

      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
        {/* Status Header */}
        <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-orange-600/20 border border-orange-500/30 text-orange-400 font-bold flex items-center justify-center text-lg">
              {userProfile.displayName?.charAt(0) || 'P'}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white leading-tight">
                {userProfile.displayName}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {userProfile.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <StatusBadge status={userProfile.role.toUpperCase()} />
            <StatusBadge status={userProfile.status.toUpperCase()} />
          </div>
        </div>

        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Profile details updated successfully in Firestore!</span>
          </div>
        )}

        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="profile-name-input"
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                WhatsApp Phone
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="profile-phone-input"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 9876543210"
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                In-Game Name (IGN) <span className="text-orange-500">*</span>
              </label>
              <div className="relative">
                <Gamepad2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="profile-ign-input"
                  type="text"
                  required
                  value={ign}
                  onChange={(e) => setIgn(e.target.value)}
                  placeholder="e.g. VIP_SNIPER"
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Free Fire UID <span className="text-orange-500">*</span>
              </label>
              <input
                id="profile-ffuid-input"
                type="text"
                required
                value={freeFireUid}
                onChange={(e) => setFreeFireUid(e.target.value)}
                placeholder="e.g. 1092837465"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Account Email (Firebase Auth)
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" />
              <input
                type="email"
                disabled
                value={userProfile.email}
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl bg-slate-950/40 border border-slate-800 text-xs text-slate-500 cursor-not-allowed outline-none font-mono"
              />
            </div>
          </div>

          <div className="pt-3">
            <button
              id="profile-save-button"
              type="submit"
              disabled={saving}
              className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {saving ? <span className="inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Updating Profile...' : 'Save Profile Changes'}
            </button>
          </div>
        </form>

        {/* 24/7 Support Desk Shortcut */}
        {onOpenSupport && (
          <div 
            onClick={onOpenSupport}
            className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-orange-500/40 transition-all cursor-pointer flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-600/20 text-orange-400">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white group-hover:text-orange-400 transition-colors">
                  Need Help or Have a Match Dispute?
                </h4>
                <p className="text-[11px] text-slate-400">
                  Open a ticket with the 24/7 Tournament Moderation Team
                </p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-orange-400 transition-colors" />
          </div>
        )}
      </div>
    </div>
  );
};
