import React, { useState, useEffect } from 'react';
import { 
  LifeBuoy, 
  Send, 
  MessageSquare, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  ChevronRight, 
  User, 
  ShieldCheck, 
  HelpCircle,
  Gamepad2,
  Calendar,
  Sparkles,
  ArrowLeft,
  Headphones,
  FileText
} from 'lucide-react';
import { 
  SupportTicket, 
  SupportCategory, 
  SupportTicketStatus, 
  Tournament 
} from '../types';
import { 
  createSupportTicket, 
  listenPlayerTickets, 
  addTicketMessage 
} from '../services/supportService';
import { listenTournaments } from '../services/tournamentService';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';

const SUPPORT_CATEGORIES: { category: SupportCategory; desc: string; icon: string }[] = [
  { category: 'Tournament Issue', desc: 'Queries regarding tournament slots, format, or dates', icon: '🏆' },
  { category: 'Match/Room Issue', desc: 'Problems entering custom room ID, password or seat', icon: '🎮' },
  { category: 'Entry/Payment Issue', desc: 'Issues with paid entry UPI verification or 5-ad ticket', icon: '💳' },
  { category: 'Prize/Reward Issue', desc: 'Diamonds fulfillment or gift card delivery status', icon: '💎' },
  { category: 'Cheating Report', desc: 'Report unfair gameplay, aimbot, or emulator in mobile lobby', icon: '🚨' },
  { category: 'Account Issue', desc: 'Profile updates, Free Fire UID changes or ban appeals', icon: '👤' },
  { category: 'Technical Problem', desc: 'Bugs, video playback errors, or UI display glitches', icon: '⚙️' },
  { category: 'Other', desc: 'General queries or sponsorship inquiries', icon: '💬' },
];

export const PlayerSupportView: React.FC = () => {
  const { currentUser, userProfile } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [replyMessage, setReplyMessage] = useState<string>('');
  const [submittingReply, setSubmittingReply] = useState<boolean>(false);

  // New Ticket Form State
  const [category, setCategory] = useState<SupportCategory>('Tournament Issue');
  const [subject, setSubject] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [selectedTournId, setSelectedTournId] = useState<string>('');
  const [matchInfo, setMatchInfo] = useState<string>('');
  const [submittingNew, setSubmittingNew] = useState<boolean>(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (!currentUser) return;
    const unsub = listenPlayerTickets(currentUser.uid, (list) => {
      setTickets(list);
      // Keep active ticket updated in real-time
      if (selectedTicket) {
        const fresh = list.find((t) => t.id === selectedTicket.id);
        if (fresh) setSelectedTicket(fresh);
      }
    });
    return () => unsub();
  }, [currentUser, selectedTicket?.id]);

  useEffect(() => {
    const unsub = listenTournaments((list) => {
      setTournaments(list);
    });
    return () => unsub();
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!subject.trim()) {
      setFormError('Please enter a ticket subject.');
      return;
    }
    if (!message.trim()) {
      setFormError('Please enter detailed message description.');
      return;
    }

    try {
      setSubmittingNew(true);
      setFormError(null);
      const chosenTourn = tournaments.find((t) => t.id === selectedTournId);

      const created = await createSupportTicket({
        userId: currentUser.uid,
        playerName: userProfile?.displayName || 'Player',
        playerEmail: userProfile?.email || currentUser.email || '',
        freeFireUid: userProfile?.freeFireUid || '',
        category,
        subject: subject.trim(),
        message: message.trim(),
        tournamentId: chosenTourn?.id || '',
        tournamentTitle: chosenTourn?.title || '',
        matchName: matchInfo.trim(),
      });

      setSubject('');
      setMessage('');
      setSelectedTournId('');
      setMatchInfo('');
      setIsCreatingNew(false);
      setSelectedTicket(created);
    } catch (err: any) {
      setFormError(err?.message || 'Failed to submit support request.');
    } finally {
      setSubmittingNew(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyMessage.trim() || !currentUser) return;

    try {
      setSubmittingReply(true);
      await addTicketMessage(
        selectedTicket.id,
        currentUser.uid,
        userProfile?.displayName || 'Player',
        'player',
        replyMessage.trim(),
        selectedTicket.status === 'RESOLVED' || selectedTicket.status === 'CLOSED' ? 'OPEN' : undefined
      );
      setReplyMessage('');
    } catch (err) {
      console.error('Error sending ticket reply:', err);
    } finally {
      setSubmittingReply(false);
    }
  };

  const getStatusBadge = (status: SupportTicketStatus) => {
    switch (status) {
      case 'OPEN':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] font-bold">
            OPEN
          </span>
        );
      case 'IN REVIEW':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] font-bold">
            IN REVIEW
          </span>
        );
      case 'RESOLVED':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
            RESOLVED
          </span>
        );
      case 'CLOSED':
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold">
            CLOSED
          </span>
        );
    }
  };

  return (
    <div id="player-support-view" className="space-y-6">
      {/* Header Banner */}
      <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-orange-950/40 border border-slate-800 p-4 sm:p-7 shadow-xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[11px] font-bold uppercase tracking-wider">
              <Headphones className="w-3.5 h-3.5" />
              24/7 Official Player Support Desk
            </div>
            <h1 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white">
              Support Team & Ticket Center
            </h1>
            <p className="text-xs text-slate-400 leading-relaxed">
              Submit match disputes, payment verifications, diamond reward inquiries, anti-cheat reports, or account appeals directly to the tournament moderation staff.
            </p>
          </div>

          <button
            id="create-support-ticket-btn"
            onClick={() => {
              setSelectedTicket(null);
              setIsCreatingNew(true);
            }}
            className="px-5 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center gap-2 cursor-pointer min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            Create Support Request
          </button>
        </div>
      </div>

      {/* Main Layout */}
      {isCreatingNew ? (
        /* Create Ticket Form */
        <div className="rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-7 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsCreatingNew(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-lg font-bold text-white">Submit New Support Ticket</h2>
                <p className="text-xs text-slate-400">Our administrative staff usually responds within 15–30 minutes.</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleCreateTicket} className="space-y-5">
            {/* Category Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">
                1. Select Issue Category <span className="text-orange-400">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {SUPPORT_CATEGORIES.map((cat) => (
                  <button
                    key={cat.category}
                    type="button"
                    onClick={() => setCategory(cat.category)}
                    className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                      category === cat.category
                        ? 'bg-orange-600/20 border-orange-500 text-white shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 text-xs font-bold text-white mb-0.5">
                      <span>{cat.icon}</span>
                      <span>{cat.category}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 line-clamp-2 leading-tight">
                      {cat.desc}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Optional Tournament Link */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Related Tournament (Optional)
                </label>
                <select
                  value={selectedTournId}
                  onChange={(e) => setSelectedTournId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none cursor-pointer"
                >
                  <option value="">-- No specific tournament --</option>
                  {tournaments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.format})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                  Match / Room / Seat Info (Optional)
                </label>
                <input
                  type="text"
                  value={matchInfo}
                  onChange={(e) => setMatchInfo(e.target.value)}
                  placeholder="e.g. Qualifier Match #3, Room ID #10294"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
                />
              </div>
            </div>

            {/* Subject */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                2. Subject Summary <span className="text-orange-400">*</span>
              </label>
              <input
                type="text"
                id="support-ticket-subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Brief summary of your request or issue..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                3. Detailed Message & Explanation <span className="text-orange-400">*</span>
              </label>
              <textarea
                id="support-ticket-message"
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Provide all relevant information, player IGNs, transaction UTRs, or POV links so our team can assist you immediately..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none resize-none"
              />
            </div>

            {/* Error Message */}
            {formError && (
              <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {formError}
              </div>
            )}

            {/* Submit Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="submit-support-ticket-btn"
                disabled={submittingNew}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center gap-2 cursor-pointer"
              >
                {submittingNew ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    Submit Ticket
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      ) : selectedTicket ? (
        /* Ticket Conversation View */
        <div className="rounded-2xl sm:rounded-3xl bg-slate-900 border border-slate-800 p-4 sm:p-7 shadow-xl space-y-6">
          {/* Top Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedTicket(null)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-orange-400 font-bold">
                    {selectedTicket.ticketId}
                  </span>
                  {getStatusBadge(selectedTicket.status)}
                </div>
                <h2 className="text-lg font-bold text-white mt-0.5">
                  {selectedTicket.subject}
                </h2>
              </div>
            </div>

            <div className="text-right text-xs text-slate-400 font-sans">
              <span>Category: <strong className="text-slate-200">{selectedTicket.category}</strong></span>
              {selectedTicket.tournamentTitle && (
                <span className="block text-[11px] text-orange-400 mt-0.5 truncate max-w-xs">
                  {selectedTicket.tournamentTitle}
                </span>
              )}
            </div>
          </div>

          {/* Messages Thread */}
          <div className="space-y-4 max-h-[500px] overflow-y-auto p-1 pr-2">
            {selectedTicket.messages?.map((msg, idx) => {
              const isAdmin = msg.senderRole === 'admin';

              return (
                <div
                  key={msg.id || idx}
                  className={`p-4 rounded-2xl border transition-all ${
                    isAdmin
                      ? 'bg-orange-950/30 border-orange-500/40 ml-4 sm:ml-8'
                      : 'bg-slate-950/80 border-slate-800 mr-4 sm:mr-8'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2 text-xs">
                    <div className="flex items-center gap-2">
                      <div className={`p-1 rounded-lg ${isAdmin ? 'bg-orange-600 text-white' : 'bg-slate-800 text-slate-300'}`}>
                        {isAdmin ? <ShieldCheck className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
                      </div>
                      <span className="font-bold text-white">
                        {msg.senderName} {isAdmin && <span className="text-[10px] text-orange-400 font-normal">(Official Staff)</span>}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(msg.createdAt).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                    {msg.message}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Reply Form */}
          <form onSubmit={handleSendReply} className="pt-3 border-t border-slate-800 space-y-3">
            <div className="relative">
              <textarea
                rows={3}
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder="Type a reply to the tournament support team..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-500 outline-none resize-none pr-24"
              />
              <button
                type="submit"
                disabled={submittingReply || !replyMessage.trim()}
                className="absolute bottom-3 right-3 px-4 py-2 bg-orange-600 hover:bg-orange-500 disabled:opacity-40 text-white text-xs font-bold rounded-lg uppercase tracking-wider shadow transition-all flex items-center gap-1.5 cursor-pointer"
              >
                {submittingReply ? 'Sending...' : (
                  <>
                    <Send className="w-3 h-3" /> Send Reply
                  </>
                )}
              </button>
            </div>
            {selectedTicket.status === 'RESOLVED' && (
              <p className="text-[11px] text-emerald-400">
                ✓ This ticket has been marked as resolved by staff. Sending a new reply will automatically reopen the request.
              </p>
            )}
          </form>
        </div>
      ) : (
        /* Tickets List View */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-orange-400" />
              My Support Requests ({tickets.length})
            </h2>
          </div>

          {tickets.length === 0 ? (
            <EmptyState
              id="no-player-tickets"
              title="No support tickets opened."
              description="If you experience any issues with tournament qualifiers, UID verification, room credentials or prize delivery, create a request here."
              actionText="Open New Support Ticket"
              onAction={() => setIsCreatingNew(true)}
            />
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {tickets.map((ticket) => (
                <div
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-orange-500/40 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg group"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-orange-400">
                        {ticket.ticketId}
                      </span>
                      {getStatusBadge(ticket.status)}
                      <span className="text-[10px] text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {ticket.category}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white group-hover:text-orange-400 transition-colors">
                      {ticket.subject}
                    </h3>

                    <p className="text-xs text-slate-400 line-clamp-1">
                      {ticket.messages?.[ticket.messages.length - 1]?.message || ticket.message}
                    </p>

                    {ticket.tournamentTitle && (
                      <div className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                        <span>🏆</span> {ticket.tournamentTitle}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(ticket.updatedAt || ticket.createdAt).toLocaleString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-orange-400 transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
