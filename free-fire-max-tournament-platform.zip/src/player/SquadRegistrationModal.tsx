import React, { useState, useEffect } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Gamepad2, 
  Phone, 
  AlertCircle, 
  CheckCircle2, 
  Play, 
  Sparkles, 
  Gift, 
  Lock, 
  Unlock,
  Gem,
  DollarSign
} from 'lucide-react';
import { Modal } from '../components/Modal';
import { 
  Tournament, 
  Registration, 
  SquadMember, 
  AdEntryProgress, 
  getTournamentPrizePositions, 
  formatPrizeAmount,
  formatEntryFeeDisplay,
  isDiamondPrizeType,
  normalizeEntryType,
  getPrizePoolLabel
} from '../types';
import { registerSquadTeam } from '../services/registrationService';
import { listenAdEntryProgress } from '../services/adRewardService';
import { RewardedAdModal } from '../components/RewardedAdModal';
import { TournamentPaymentModal } from '../components/TournamentPaymentModal';
import { PaymentVerificationResult } from '../services/paymentService';
import { useAuth } from '../context/AuthContext';

interface SquadRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament | null;
  onSuccess: (reg: Registration) => void;
}

export const SquadRegistrationModal: React.FC<SquadRegistrationModalProps> = ({
  isOpen,
  onClose,
  tournament,
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [teamName, setTeamName] = useState('');
  const [phone, setPhone] = useState('');
  
  const [captain, setCaptain] = useState<SquadMember>({
    name: '',
    freeFireUid: '',
    ign: '',
  });

  const [member2, setMember2] = useState<SquadMember>({ name: '', freeFireUid: '', ign: '' });
  const [member3, setMember3] = useState<SquadMember>({ name: '', freeFireUid: '', ign: '' });
  const [member4, setMember4] = useState<SquadMember>({ name: '', freeFireUid: '', ign: '' });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedReg, setConfirmedReg] = useState<Registration | null>(null);

  // Ad Progress State
  const [adProgress, setAdProgress] = useState<AdEntryProgress | null>(null);
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);

  // Payment Checkout State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  useEffect(() => {
    if (userProfile) {
      setCaptain({
        name: userProfile.displayName || 'Captain',
        freeFireUid: userProfile.freeFireUid || '',
        ign: userProfile.ign || userProfile.displayName || '',
      });
      setPhone(userProfile.phone || '');
    }
  }, [userProfile, isOpen]);

  useEffect(() => {
    if (isOpen) {
      setConfirmedReg(null);
      setError(null);
      setIsPaymentModalOpen(false);
    }
  }, [isOpen]);

  // Realtime listener for 5-ad entry progress
  useEffect(() => {
    if (!isOpen || !currentUser || !tournament) {
      setAdProgress(null);
      return;
    }

    const unsub = listenAdEntryProgress(currentUser.uid, tournament.id, (prog) => {
      setAdProgress(prog);
    });

    return () => unsub();
  }, [isOpen, currentUser, tournament]);

  if (!tournament) return null;

  const entryType = normalizeEntryType(tournament.entryType, tournament.entryFee);
  const isPaidEntry = entryType === 'PAID_IN_GAME';
  const isFreeDiamonds = entryType === 'FREE_IN_GAME';
  const isAdBased = entryType === 'FREE_ADS';

  const adsCompleted = adProgress?.adsCompleted || 0;
  const adsRequired = adProgress?.adsRequired || tournament.adsRequired || 5;
  const isUnlocked = Boolean(adProgress?.entryUnlocked || adsCompleted >= adsRequired);
  const prizePositions = getTournamentPrizePositions(tournament);
  const isDiamonds = isDiamondPrizeType(tournament.prizeType || tournament.rewardType);

  const handleStartWatchAd = () => {
    if (!currentUser) {
      setError('Please sign in to watch rewarded ads.');
      return;
    }
    setError(null);
    setIsAdModalOpen(true);
  };

  const handleRewardEarned = (updated: AdEntryProgress) => {
    setAdProgress(updated);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('Please sign in to register.');
      return;
    }

    if (!teamName.trim()) {
      setError('Please enter your Squad Team Name.');
      return;
    }

    if (!captain.freeFireUid.trim() || !captain.ign.trim()) {
      setError('Please enter Captain Free Fire UID and IGN.');
      return;
    }

    if (!member2.freeFireUid.trim() || !member2.ign.trim() ||
        !member3.freeFireUid.trim() || !member3.ign.trim() ||
        !member4.freeFireUid.trim() || !member4.ign.trim()) {
      setError('All 4 squad team members must have IGN and Free Fire UID filled.');
      return;
    }

    if (isPaidEntry) {
      setIsPaymentModalOpen(true);
      return;
    }

    if (isAdBased && !isUnlocked) {
      setError(`Please complete all 5 rewarded ads to unlock free entry for your squad (${adsCompleted}/${adsRequired} completed).`);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const reg = await registerSquadTeam({
        tournamentId: tournament.id,
        teamName: teamName.trim(),
        teamLeaderUid: currentUser.uid,
        captain,
        members: [member2, member3, member4],
        phone: phone.trim(),
        paymentMethod: 'FREE',
      });

      setConfirmedReg(reg);
      onSuccess(reg);
    } catch (err: any) {
      console.warn('Squad registration notice:', err?.message || err);
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async (paymentResult: PaymentVerificationResult) => {
    if (!currentUser) return;
    try {
      setLoading(true);
      setError(null);

      const reg = await registerSquadTeam({
        tournamentId: tournament.id,
        teamName: teamName.trim(),
        teamLeaderUid: currentUser.uid,
        captain,
        members: [member2, member3, member4],
        phone: phone.trim(),
        paymentTransactionId: paymentResult.transactionId,
        utrNumber: paymentResult.transactionId.replace(/^TXN_/, ''),
        paymentMethod: paymentResult.paymentMethod,
        entryFeePaid: paymentResult.amount,
        isManualPending: paymentResult.isManualPending,
      });

      setConfirmedReg(reg);
      onSuccess(reg);
    } catch (err: any) {
      console.error('Paid squad registration error:', err);
      setError(err.message || 'Payment verified but squad seat allocation failed. Please contact support.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Modal
        id="squad-registration-modal"
        isOpen={isOpen}
        onClose={onClose}
        title={confirmedReg ? 'Squad Registration Confirmed!' : isPaidEntry ? 'Squad Tournament Entry — PAID' : 'Squad Tournament Entry — FREE'}
        subtitle={confirmedReg ? 'Team Slot allocated in Firestore' : tournament.title}
        maxWidth="2xl"
      >
        {confirmedReg ? (
          <div id="confirmed-squad-panel" className="space-y-4 py-2">
            <div className={`p-4 rounded-2xl text-center border ${
              isPaidEntry ? 'bg-cyan-950/40 border-cyan-500/40' : 'bg-emerald-950/40 border-emerald-500/40'
            }`}>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2.5 ${
                isPaidEntry ? 'bg-cyan-500/20 text-cyan-400' : 'bg-emerald-500/20 text-emerald-400'
              }`}>
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-white uppercase tracking-wider">
                SQUAD REGISTRATION CONFIRMED ({isPaidEntry ? `PAID ₹${confirmedReg.entryFeePaid || tournament.entryFee}` : 'FREE ENTRY'})
              </h4>
              <p className={`text-xs mt-1 ${isPaidEntry ? 'text-cyan-300' : 'text-emerald-300'}`}>
                {isPaidEntry 
                  ? 'Squad entry fee verified. Winner receives In-Game Free Fire Diamond Reward.' 
                  : 'Your squad team is confirmed for qualifier matches.'}
              </p>
            </div>

            <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-4 space-y-3">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Team Name</span>
                <span className="font-bold text-white text-sm">
                  {confirmedReg.teamName}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Assigned Qualifier</span>
                <span className="font-bold text-purple-400">
                  {confirmedReg.matchName}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Team Slot Number</span>
                <span className="font-extrabold text-white text-sm bg-purple-600/20 px-2.5 py-0.5 rounded border border-purple-500/40">
                  Slot #{confirmedReg.seatNumber} / {tournament.participantsPerMatch || 12}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Entry Verification</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[11px] border flex items-center gap-1 ${
                  isPaidEntry 
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40' 
                    : 'bg-emerald-950 text-emerald-400 border-emerald-600/40'
                }`}>
                  <CheckCircle2 className="w-3 h-3" />
                  {isPaidEntry ? `PAID ENTRY (₹${confirmedReg.entryFeePaid || tournament.entryFee} Verified)` : 'FREE ENTRY VERIFIED'}
                </span>
              </div>
            </div>

            {/* Squad Lineup Snapshot */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Verified Team Lineup & UID Snapshots:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {confirmedReg.members?.map((m, idx) => (
                  <div key={idx} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                    <span className="text-slate-300">{idx === 0 ? '👑 ' : ''}{m.ign}</span>
                    <span className="font-mono text-cyan-400">{m.freeFireUid}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              id="view-squad-my-match-btn"
              onClick={onClose}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
            >
              VIEW MY MATCH DESK
            </button>
          </div>
        ) : (
          <form id="squad-reg-form" onSubmit={handleFormSubmit} className="space-y-4">
            {error && (
              <div id="squad-reg-error" className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tournament & Prize Banner */}
            <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isDiamonds ? <Gem className="w-4 h-4 text-cyan-400" /> : <Gift className="w-4 h-4 text-amber-400" />}
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {isDiamonds ? 'FREE FIRE DIAMONDS REWARD' : `${(tournament.prizeType || tournament.rewardType || 'GIFT CARD').replace(/_/g, ' ')} POOL`}
                  </span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                  isPaidEntry 
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40' 
                    : 'bg-purple-950 text-purple-300 border-purple-500/40'
                }`}>
                  ENTRY: {formatEntryFeeDisplay(tournament)}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">{getPrizePoolLabel(tournament.prizeType || tournament.rewardType)}</span>
                  <span className="font-extrabold text-amber-400">
                    {formatPrizeAmount(tournament.totalPrizeValue || tournament.prizePool, tournament.prizeType || tournament.rewardType)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">ENTRY TYPE</span>
                  <span className={`font-extrabold ${isPaidEntry ? 'text-cyan-400' : 'text-purple-400'}`}>
                    {formatEntryFeeDisplay(tournament)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">SQUAD TEAMS</span>
                  <span className="font-extrabold text-slate-300">{tournament.registeredCount} / {tournament.maxParticipants}</span>
                </div>
              </div>

              {isPaidEntry && (
                <div className="text-[10px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-cyan-400 font-bold">Non-cash in-game reward:</span> Winner receives official Free Fire In-Game Diamonds top-up delivered to the registered UID snapshot. There is no cash prize or withdrawal.
                </div>
              )}
            </div>

            {/* AD UNLOCK STATUS (Only for FREE_ADS tournaments) */}
            {isAdBased && (
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Squad Entry Ticket Status
                  </span>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    isUnlocked 
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40' 
                      : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                  }`}>
                    {isUnlocked ? 'TICKET UNLOCKED' : `${adsCompleted}/${adsRequired} Ads Watched`}
                  </span>
                </div>

                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-emerald-500 h-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (adsCompleted / adsRequired) * 100)}%` }}
                  />
                </div>

                {!isUnlocked && (
                  <button
                    type="button"
                    onClick={handleStartWatchAd}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="w-4 h-4" />
                    Watch Video Ad #{adsCompleted + 1} to Unlock Squad Entry
                  </button>
                )}
              </div>
            )}

            {/* Team Details */}
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Squad Team Name <span className="text-purple-400">*</span>
                  </label>
                  <input
                    id="squad-reg-team-name"
                    type="text"
                    required
                    value={teamName}
                    onChange={(e) => setTeamName(e.target.value)}
                    placeholder="e.g. GOD LIKE ESPORTS"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-white outline-none font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Captain Phone / WhatsApp <span className="text-purple-400">*</span>
                  </label>
                  <input
                    id="squad-reg-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 9876543210"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-white outline-none font-mono"
                  />
                </div>
              </div>

              {/* 4 Lineup Members */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block">
                  4 Roster Members (IGN & Free Fire UID Snapshot):
                </span>

                {/* Member 1 (Captain) */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-purple-500/40 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-purple-400 font-bold mb-0.5">Player 1: Captain IGN</label>
                    <input
                      type="text"
                      required
                      value={captain.ign}
                      onChange={(e) => setCaptain({ ...captain, ign: e.target.value })}
                      placeholder="Captain IGN"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-purple-400 font-bold mb-0.5">Captain FF UID</label>
                    <input
                      type="text"
                      required
                      value={captain.freeFireUid}
                      onChange={(e) => setCaptain({ ...captain, freeFireUid: e.target.value })}
                      placeholder="Captain FF UID"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono outline-none"
                    />
                  </div>
                </div>

                {/* Member 2 */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 2: IGN</label>
                    <input
                      type="text"
                      required
                      value={member2.ign}
                      onChange={(e) => setMember2({ ...member2, ign: e.target.value })}
                      placeholder="Player 2 IGN"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 2 FF UID</label>
                    <input
                      type="text"
                      required
                      value={member2.freeFireUid}
                      onChange={(e) => setMember2({ ...member2, freeFireUid: e.target.value })}
                      placeholder="Player 2 FF UID"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono outline-none"
                    />
                  </div>
                </div>

                {/* Member 3 */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 3: IGN</label>
                    <input
                      type="text"
                      required
                      value={member3.ign}
                      onChange={(e) => setMember3({ ...member3, ign: e.target.value })}
                      placeholder="Player 3 IGN"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 3 FF UID</label>
                    <input
                      type="text"
                      required
                      value={member3.freeFireUid}
                      onChange={(e) => setMember3({ ...member3, freeFireUid: e.target.value })}
                      placeholder="Player 3 FF UID"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono outline-none"
                    />
                  </div>
                </div>

                {/* Member 4 */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 4: IGN</label>
                    <input
                      type="text"
                      required
                      value={member4.ign}
                      onChange={(e) => setMember4({ ...member4, ign: e.target.value })}
                      placeholder="Player 4 IGN"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold mb-0.5">Player 4 FF UID</label>
                    <input
                      type="text"
                      required
                      value={member4.freeFireUid}
                      onChange={(e) => setMember4({ ...member4, freeFireUid: e.target.value })}
                      placeholder="Player 4 FF UID"
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                id="squad-reg-submit-btn"
                type="submit"
                disabled={loading || (isAdBased && !isUnlocked)}
                className={`w-full py-3 font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  isPaidEntry
                    ? 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-slate-950 font-black shadow-cyan-600/30'
                    : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-600/30'
                }`}
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : isPaidEntry ? (
                  <DollarSign className="w-4 h-4" />
                ) : isUnlocked ? (
                  <Sparkles className="w-4 h-4" />
                ) : (
                  <Lock className="w-4 h-4" />
                )}
                {loading
                  ? 'Assigning Squad Slot in Firestore...'
                  : isPaidEntry
                  ? `CONTINUE TO PAYMENT (₹${tournament.entryFee})`
                  : isAdBased && !isUnlocked
                  ? `WATCH ADS TO UNLOCK (${adsCompleted}/${adsRequired})`
                  : 'CONFIRM SQUAD REGISTRATION'}
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* Rewarded Ad Watch Modal */}
      <RewardedAdModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        tournamentId={tournament.id}
        onRewardEarned={handleRewardEarned}
      />

      {/* Tournament Payment Modal */}
      {currentUser && (
        <TournamentPaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          tournament={tournament}
          userId={currentUser.uid}
          payerName={teamName || captain.ign || 'Squad Captain'}
          freeFireUid={captain.freeFireUid}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </>
  );
};
