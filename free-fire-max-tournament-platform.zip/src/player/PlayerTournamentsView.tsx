import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Users, 
  User, 
  Calendar, 
  Clock, 
  Shield, 
  ArrowRight, 
  CheckCircle, 
  Sparkles, 
  Filter, 
  Award, 
  Gift, 
  Play, 
  CheckCircle2,
  Gem,
  DollarSign
} from 'lucide-react';
import { 
  Tournament, 
  TournamentFormat, 
  Registration, 
  getTournamentPrizePositions, 
  formatPrizeAmount,
  normalizeEntryType,
  normalizeRewardType,
  isDiamondPrizeType,
  getPrizePoolLabel,
  formatEntryFeeDisplay
} from '../types';
import { listenTournaments } from '../services/tournamentService';
import { listenUserRegistrations } from '../services/registrationService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { SoloRegistrationModal } from './SoloRegistrationModal';
import { SquadRegistrationModal } from './SquadRegistrationModal';
import { TournamentEntryCardModal } from '../components/TournamentEntryCardModal';
import { useAuth } from '../context/AuthContext';

interface PlayerTournamentsViewProps {
  onNavigateToMyMatch: () => void;
  onOpenPlayerAuth: () => void;
  onOpenAdminAuth: () => void;
}

export const PlayerTournamentsView: React.FC<PlayerTournamentsViewProps> = ({
  onNavigateToMyMatch,
  onOpenPlayerAuth,
  onOpenAdminAuth,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [userRegistrations, setUserRegistrations] = useState<Registration[]>([]);
  const [formatFilter, setFormatFilter] = useState<'ALL' | TournamentFormat | 'PAID' | 'FREE_ADS'>('ALL');
  const [selectedSoloTourn, setSelectedSoloTourn] = useState<Tournament | null>(null);
  const [selectedSquadTourn, setSelectedSquadTourn] = useState<Tournament | null>(null);
  const [entryCardReg, setEntryCardReg] = useState<Registration | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubTourn = listenTournaments((list) => {
      setTournaments(list);
      setLoading(false);
    });

    return () => unsubTourn();
  }, []);

  useEffect(() => {
    if (!currentUser) {
      setUserRegistrations([]);
      return;
    }
    const unsubReg = listenUserRegistrations(currentUser.uid, (regs) => {
      setUserRegistrations(regs);
    });
    return () => unsubReg();
  }, [currentUser]);

  const isUserRegisteredFor = (tournId: string): boolean => {
    return userRegistrations.some((r) => r.tournamentId === tournId);
  };

  const filteredTournaments = tournaments.filter((t) => {
    const entryType = t.entryType || (t.entryFee && t.entryFee > 0 ? 'PAID_IN_GAME' : 'FREE_ADS');
    if (formatFilter === 'SOLO') return t.format === 'SOLO';
    if (formatFilter === 'SQUAD') return t.format === 'SQUAD';
    if (formatFilter === 'PAID') return entryType === 'PAID_IN_GAME';
    if (formatFilter === 'FREE_ADS') return entryType === 'FREE_ADS';
    return true;
  });

  return (
    <div id="player-tournaments-view" className="space-y-6">
      {/* Header Banner */}
      <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-orange-950/30 border border-slate-800 p-4 sm:p-8 shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-2.5 sm:space-y-3">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[11px] sm:text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3 sm:w-3.5 h-3 sm:h-3.5" />
            Free Ads & Paid Entry • Free Fire In-Game Rewards
          </div>
          <h1 className="text-xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            Compete, Qualify & Win <span className="bg-gradient-to-r from-orange-400 via-amber-400 to-cyan-400 bg-clip-text text-transparent">Official In-Game Diamonds</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-xl">
            Live automated Free Fire MAX tournament brackets with instant qualifier seat allocations, custom room credentials, and verified In-Game Diamond & Gift Card rewards.
          </p>

          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 pt-1 sm:pt-2">
            {!currentUser ? (
              <button
                id="hero-register-btn"
                onClick={onOpenPlayerAuth}
                className="w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all cursor-pointer min-h-[44px] flex items-center justify-center"
              >
                Sign In to Enter Tournaments
              </button>
            ) : (
              <button
                id="hero-view-matches-btn"
                onClick={onNavigateToMyMatch}
                className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-orange-400 border border-orange-500/30 font-bold rounded-xl text-xs uppercase tracking-wider shadow transition-all flex items-center justify-center gap-1.5 cursor-pointer min-h-[44px]"
              >
                View My Active Matches ({userRegistrations.length}) <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 sm:pb-4">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto -mx-1 px-1 py-0.5">
          <button
            id="filter-all"
            onClick={() => setFormatFilter('ALL')}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer min-h-[38px] ${
              formatFilter === 'ALL'
                ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            ALL TOURNAMENTS ({tournaments.length})
          </button>

          <button
            id="filter-paid"
            onClick={() => setFormatFilter('PAID')}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 cursor-pointer min-h-[38px] ${
              formatFilter === 'PAID'
                ? 'bg-cyan-600 text-slate-950 font-black shadow-md shadow-cyan-600/30'
                : 'bg-slate-900 text-cyan-400 hover:text-white border border-cyan-500/30'
            }`}
          >
            <Gem className="w-3.5 h-3.5" />
            PAID ENTRY ({tournaments.filter((t) => (t.entryType === 'PAID_IN_GAME' || (t.entryFee && t.entryFee > 0))).length})
          </button>

          <button
            id="filter-free-ads"
            onClick={() => setFormatFilter('FREE_ADS')}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 cursor-pointer min-h-[38px] ${
              formatFilter === 'FREE_ADS'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-900 text-emerald-400 hover:text-white border border-emerald-500/30'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            FREE (5 ADS) ({tournaments.filter((t) => (!t.entryType || t.entryType === 'FREE_ADS') && (!t.entryFee || t.entryFee === 0)).length})
          </button>

          <button
            id="filter-solo"
            onClick={() => setFormatFilter('SOLO')}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 cursor-pointer min-h-[38px] ${
              formatFilter === 'SOLO'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            SOLO ({tournaments.filter((t) => t.format === 'SOLO').length})
          </button>

          <button
            id="filter-squad"
            onClick={() => setFormatFilter('SQUAD')}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 cursor-pointer min-h-[38px] ${
              formatFilter === 'SQUAD'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            SQUAD ({tournaments.filter((t) => t.format === 'SQUAD').length})
          </button>
        </div>

        <div className="text-xs text-slate-400">
          Showing <span className="font-bold text-white">{filteredTournaments.length}</span> live tournaments
        </div>
      </div>

      {/* Tournaments Grid */}
      {filteredTournaments.length === 0 ? (
        <EmptyState
          id="no-tournaments-empty"
          title="No tournaments found."
          description={
            isAdmin
              ? 'As an administrator, head over to the Admin Panel to create official Solo or Squad tournaments.'
              : 'Upcoming tournaments will appear here as soon as published by the tournament administration.'
          }
          actionText={isAdmin ? 'Go to Admin Tournament Desk' : undefined}
          onAction={isAdmin ? onOpenAdminAuth : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredTournaments.map((tourn) => {
            const alreadyRegistered = isUserRegisteredFor(tourn.id);
            const isFull = tourn.registeredCount >= tourn.maxParticipants;
            const progressPercent = Math.min(100, Math.round((tourn.registeredCount / tourn.maxParticipants) * 100));
            const prizePositions = getTournamentPrizePositions(tourn);
            const totalVal = Number(tourn.totalPrizeValue) || Number(tourn.prizePool) || prizePositions.reduce((a, b) => a + b.amount, 0);
            
            const entryType = normalizeEntryType(tourn.entryType, tourn.entryFee);
            const isPaidEntry = entryType === 'PAID_IN_GAME';
            const isDiamonds = isDiamondPrizeType(tourn.prizeType || tourn.rewardType);

            return (
              <div
                key={tourn.id}
                id={`tournament-card-${tourn.id}`}
                className="group relative rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 p-4 sm:p-5 space-y-3.5 sm:space-y-4 shadow-lg transition-all hover:shadow-orange-950/20 flex flex-col justify-between"
              >
                {/* Header */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2.5 sm:mb-3">
                    <StatusBadge status={tourn.format} />
                    {isPaidEntry ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                        <Gem className="w-3 h-3 text-cyan-400" />
                        ENTRY: ₹{tourn.entryFee}
                      </span>
                    ) : entryType === 'FREE_IN_GAME' ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-purple-950/80 text-purple-300 border border-purple-500/40 text-[10px] font-black uppercase tracking-wider">
                        ENTRY: FREE
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 text-[10px] font-black uppercase tracking-wider">
                        ENTRY: FREE ({tourn.adsRequired || 5} ADS)
                      </span>
                    )}
                  </div>

                  <h3 id={`tourn-title-${tourn.id}`} className="text-base font-bold text-white group-hover:text-orange-400 transition-colors leading-snug">
                    {tourn.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                    {tourn.description || 'Free Fire MAX competitive championship. Top survivors qualify for official rewards.'}
                  </p>
                </div>

                {/* Key Metrics */}
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2 p-2.5 sm:p-3 bg-slate-950/70 rounded-xl border border-slate-800/80 text-center">
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">{getPrizePoolLabel(tourn.prizeType || tourn.rewardType)}</span>
                    <span className="text-xs sm:text-sm font-extrabold text-amber-400">
                      {formatPrizeAmount(totalVal, tourn.prizeType || tourn.rewardType)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">ENTRY</span>
                    <span className={`text-xs sm:text-sm font-black ${isPaidEntry ? 'text-cyan-400' : entryType === 'FREE_IN_GAME' ? 'text-purple-400' : 'text-emerald-400'}`}>
                      {formatEntryFeeDisplay(tourn)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">1ST PLACE</span>
                    <span className="text-xs sm:text-sm font-extrabold text-white">
                      {formatPrizeAmount(prizePositions[0]?.amount || 0, tourn.prizeType || tourn.rewardType)}
                    </span>
                  </div>
                </div>

                {/* Prize / Diamonds Breakdown */}
                <div className="p-2.5 sm:p-3 bg-slate-950/80 rounded-xl border border-amber-500/20 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1 truncate max-w-[170px] sm:max-w-none">
                      {isDiamonds ? (
                        <>
                          <Gem className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          <span className="text-cyan-300">Free Fire Diamonds</span>
                        </>
                      ) : (
                        <>
                          <Gift className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span>{(tourn.prizeType || tourn.rewardType || 'GIFT CARD').replace(/_/g, ' ')}</span>
                        </>
                      )}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">
                      {prizePositions.length} Ranks
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-1.5 text-center font-mono">
                    {prizePositions.map((p, idx) => (
                      <div 
                        key={idx} 
                        className={`flex-1 min-w-[62px] rounded-lg p-1 sm:p-1.5 border ${
                          p.position === 1 ? 'bg-amber-950/50 border-amber-500/40' :
                          p.position === 2 ? 'bg-slate-900 border-slate-700' :
                          p.position === 3 ? 'bg-orange-950/40 border-orange-500/30' :
                          'bg-slate-900/90 border-slate-800'
                        }`}
                      >
                        <span className="text-[9px] text-slate-400 font-sans block font-bold truncate">
                          {p.label.split(' ')[0] || `#${p.position}`}
                        </span>
                        <span className="text-[11px] sm:text-xs font-black text-white">
                          {formatPrizeAmount(p.amount, p.prizeType || tourn.prizeType || tourn.rewardType)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {isPaidEntry && (
                    <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
                      <span className="text-cyan-400 font-semibold">Non-cash in-game reward.</span> Delivered to verified UID.
                    </div>
                  )}
                </div>

                {/* Slots Progress */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-400">
                      {tourn.format === 'SOLO' ? 'Player Capacity' : 'Squad Teams Capacity'}
                    </span>
                    <span className="text-white font-mono">
                      {tourn.registeredCount} / {tourn.maxParticipants}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all ${
                        isPaidEntry
                          ? 'bg-gradient-to-r from-cyan-500 to-teal-500'
                          : tourn.format === 'SOLO'
                          ? 'bg-gradient-to-r from-orange-500 to-amber-500'
                          : 'bg-gradient-to-r from-purple-500 to-indigo-500'
                      }`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Time & Format Details */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-1 border-t border-slate-800/60">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{tourn.startDate}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>{tourn.startTime}</span>
                  </div>
                </div>

                {/* Action CTA */}
                <div className="pt-2">
                  {alreadyRegistered ? (() => {
                    const userReg = userRegistrations.find((r) => r.tournamentId === tourn.id);
                    const isVerified = userReg?.paymentStatus === 'VERIFIED' || userReg?.paymentStatus === 'APPROVED';
                    const isPending = userReg?.paymentStatus === 'PENDING' || userReg?.paymentStatus === 'PENDING_APPROVAL';

                    return (
                      <div className="space-y-2">
                        {isVerified ? (
                          <div className="p-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/50 flex items-center justify-between gap-2 text-xs">
                            <div className="flex items-center gap-1.5 text-emerald-300 font-bold truncate">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                              <span className="truncate">CONFIRMED (SEAT #{userReg?.seatNumber})</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => userReg && setEntryCardReg(userReg)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-[11px] font-black uppercase tracking-wider shrink-0 transition-all cursor-pointer shadow-sm"
                            >
                              VIEW CARD
                            </button>
                          </div>
                        ) : isPending ? (
                          <div className="p-2.5 rounded-xl bg-amber-950/70 border border-amber-500/50 flex items-center justify-between gap-2 text-xs">
                            <div className="flex items-center gap-1.5 text-amber-300 font-bold truncate">
                              <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
                              <span className="truncate">PAYMENT UNDER REVIEW (SEAT #{userReg?.seatNumber})</span>
                            </div>
                            <span className="text-[10px] text-amber-400/90 font-mono bg-amber-950 px-2 py-0.5 rounded border border-amber-500/30">
                              PENDING ADMIN
                            </span>
                          </div>
                        ) : (
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 text-xs text-center font-bold">
                            STATUS: {userReg?.paymentStatus}
                          </div>
                        )}

                        <button
                          id={`btn-already-registered-${tourn.id}`}
                          onClick={onNavigateToMyMatch}
                          className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                        >
                          <span>Go to My Match Desk</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })() : isFull ? (
                    <button
                      disabled
                      className="w-full py-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-500 font-bold text-xs uppercase tracking-wider cursor-not-allowed text-center min-h-[44px]"
                    >
                      TOURNAMENT FULL ({tourn.registeredCount}/{tourn.maxParticipants})
                    </button>
                  ) : tourn.status !== 'REGISTRATION_OPEN' ? (
                    <button
                      disabled
                      className="w-full py-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-500 font-bold text-xs uppercase tracking-wider cursor-not-allowed text-center min-h-[44px]"
                    >
                      REGISTRATION CLOSED
                    </button>
                  ) : (
                    <button
                      id={`btn-register-${tourn.id}`}
                      onClick={() => {
                        if (!currentUser) {
                          onOpenPlayerAuth();
                        } else if (tourn.format === 'SOLO') {
                          setSelectedSoloTourn(tourn);
                        } else {
                          setSelectedSquadTourn(tourn);
                        }
                      }}
                      className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer min-h-[44px] ${
                        isPaidEntry
                          ? 'bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 shadow-cyan-600/30 font-black'
                          : tourn.format === 'SOLO'
                          ? 'bg-gradient-to-r from-orange-600 via-amber-600 to-emerald-600 hover:from-orange-500 hover:to-emerald-500 text-white shadow-orange-600/30'
                          : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 text-white shadow-purple-600/30'
                      }`}
                    >
                      {isPaidEntry ? (
                        <>
                          <DollarSign className="w-3.5 h-3.5" />
                          ENTER PAID (₹{tourn.entryFee}) • {isDiamonds ? 'WIN DIAMONDS' : 'JOIN MATCH'}
                        </>
                      ) : entryType === 'FREE_IN_GAME' ? (
                        <>
                          <Gem className="w-3.5 h-3.5" />
                          ENTER FREE • WIN DIAMONDS
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-white" />
                          ENTER FREE • WATCH {tourn.adsRequired || 5} ADS
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Solo Registration Modal */}
      <SoloRegistrationModal
        isOpen={Boolean(selectedSoloTourn)}
        tournament={selectedSoloTourn}
        onClose={() => setSelectedSoloTourn(null)}
        onSuccess={() => {
          setSelectedSoloTourn(null);
          onNavigateToMyMatch();
        }}
      />

      {/* Squad Registration Modal */}
      <SquadRegistrationModal
        isOpen={Boolean(selectedSquadTourn)}
        tournament={selectedSquadTourn}
        onClose={() => setSelectedSquadTourn(null)}
        onSuccess={() => {
          setSelectedSquadTourn(null);
          onNavigateToMyMatch();
        }}
      />

      {/* Official Tournament Entry Card Modal */}
      {entryCardReg && (
        <TournamentEntryCardModal
          isOpen={Boolean(entryCardReg)}
          onClose={() => setEntryCardReg(null)}
          registration={entryCardReg}
        />
      )}
    </div>
  );
};
