import React, { useState } from 'react';
import { Video, Link as LinkIcon, Send, AlertCircle } from 'lucide-react';
import { Modal } from '../components/Modal';
import { POVType } from '../types';
import { submitMatchRecording } from '../services/recordingService';
import { useAuth } from '../context/AuthContext';

interface SubmitRecordingModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName?: string;
  onSuccess: () => void;
}

export const SubmitRecordingModal: React.FC<SubmitRecordingModalProps> = ({
  isOpen,
  onClose,
  tournamentId,
  tournamentTitle = '',
  matchId,
  matchName = '',
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [videoUrl, setVideoUrl] = useState('');
  const [povType, setPovType] = useState<POVType>('FULL_GAMEPLAY');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('Please sign in to submit a recording.');
      return;
    }

    if (!videoUrl.trim()) {
      setError('Please enter your video recording URL.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await submitMatchRecording({
        playerId: currentUser.uid,
        playerName: userProfile?.displayName || 'Player',
        freeFireUid: userProfile?.freeFireUid || '',
        ign: userProfile?.ign || userProfile?.displayName || 'Player',
        tournamentId,
        tournamentTitle,
        matchId,
        matchName,
        videoUrl: videoUrl.trim(),
        povType,
        notes: notes.trim(),
      });

      onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Recording submission failed:', err);
      setError(err.message || 'Failed to submit POV recording.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="submit-recording-modal"
      isOpen={isOpen}
      onClose={onClose}
      title="Submit Match POV Recording"
      subtitle={`${matchName || 'Match'} • ${tournamentTitle || 'Tournament'}`}
      maxWidth="md"
    >
      <form id="submit-recording-form" onSubmit={handleSubmit} className="space-y-3.5">
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            POV Video Link (Google Drive / YouTube Unlisted / Loom) <span className="text-orange-500">*</span>
          </label>
          <div className="relative">
            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              id="recording-url-input"
              type="url"
              required
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://drive.google.com/... or YouTube link"
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
            />
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">
            Ensure Google Drive link permissions are set to "Anyone with link can view".
          </span>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Recording Format / POV Scope
          </label>
          <select
            id="recording-type-select"
            value={povType}
            onChange={(e) => setPovType(e.target.value as POVType)}
            className="w-full px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
          >
            <option value="FULL_GAMEPLAY">Full Match Screen Recording (Plane to Booyah/Death)</option>
            <option value="LAST_ZONES">Final Zones & End Game POV</option>
            <option value="KILL_MOMENTS">Key Clutch & Highlight Moments</option>
            <option value="SPEC_PROOF">Spectator / Handcam Verification</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Notes / Timestamps (Optional)
          </label>
          <textarea
            id="recording-notes-input"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. 5 kills, died at zone 4, phone model: ROG 6..."
            className="w-full p-3 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none resize-none"
          />
        </div>

        <div className="pt-2">
          <button
            id="submit-recording-btn"
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Video className="w-4 h-4" />
            )}
            {loading ? 'Submitting POV...' : 'SUBMIT MATCH RECORDING'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
