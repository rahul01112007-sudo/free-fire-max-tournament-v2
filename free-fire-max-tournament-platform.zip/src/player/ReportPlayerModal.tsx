import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, Link as LinkIcon, Send } from 'lucide-react';
import { Modal } from '../components/Modal';
import { AntiCheatReason } from '../types';
import { submitAntiCheatReport } from '../services/antiCheatService';
import { useAuth } from '../context/AuthContext';

interface ReportPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournamentId?: string;
  tournamentTitle?: string;
  matchId?: string;
  matchName?: string;
  suspectIgn?: string;
  suspectFfUid?: string;
  onSuccess: () => void;
}

export const ReportPlayerModal: React.FC<ReportPlayerModalProps> = ({
  isOpen,
  onClose,
  tournamentId = '',
  tournamentTitle = '',
  matchId = '',
  matchName = '',
  suspectIgn: initialSuspectIgn = '',
  suspectFfUid: initialSuspectFfUid = '',
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [suspectIgn, setSuspectIgn] = useState(initialSuspectIgn);
  const [suspectFfUid, setSuspectFfUid] = useState(initialSuspectFfUid);
  const [reason, setReason] = useState<AntiCheatReason>('AIMBOT');
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('You must be signed in to submit an anti-cheat report.');
      return;
    }

    if (!suspectIgn.trim() || !suspectFfUid.trim()) {
      setError('Please provide suspect IGN and Free Fire UID.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await submitAntiCheatReport({
        reporterUid: currentUser.uid,
        reporterName: userProfile?.displayName || 'Player',
        reporterEmail: currentUser.email || '',
        suspectIgn: suspectIgn.trim(),
        suspectFfUid: suspectFfUid.trim(),
        tournamentId,
        tournamentTitle,
        matchId,
        matchName,
        reason,
        description: description.trim(),
        evidenceUrl: evidenceUrl.trim(),
      });

      onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Report submission failed:', err);
      setError(err.message || 'Failed to submit report.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="report-player-modal"
      isOpen={isOpen}
      onClose={onClose}
      title="Anti-Cheat Violation Report"
      subtitle="Report suspicious behavior, hacks, or fair-play violations to the admin desk"
      maxWidth="md"
    >
      <form id="anti-cheat-report-form" onSubmit={handleSubmit} className="space-y-3.5">
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Suspect IGN <span className="text-red-500">*</span>
            </label>
            <input
              id="report-suspect-ign"
              type="text"
              required
              value={suspectIgn}
              onChange={(e) => setSuspectIgn(e.target.value)}
              placeholder="Suspect IGN"
              className="w-full px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 text-xs text-white outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Suspect FF UID <span className="text-red-500">*</span>
            </label>
            <input
              id="report-suspect-ffuid"
              type="text"
              required
              value={suspectFfUid}
              onChange={(e) => setSuspectFfUid(e.target.value)}
              placeholder="Suspect FF UID"
              className="w-full px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 text-xs text-white outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Violation Category <span className="text-red-500">*</span>
          </label>
          <select
            id="report-reason-select"
            value={reason}
            onChange={(e) => setReason(e.target.value as AntiCheatReason)}
            className="w-full px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 text-xs text-white outline-none"
          >
            <option value="AIMBOT">Aimbot / Auto-Headshot</option>
            <option value="WALLHACK">Wallhack / ESP / Antenna</option>
            <option value="SPEEDHACK">Speedhack / Teleport</option>
            <option value="NO_RECOIL">No Recoil / Magic Bullet</option>
            <option value="TEAMING">Illegal Teaming in Solo Match</option>
            <option value="EMULATOR_IN_MOBILE_MATCH">Unauthorized Emulator Usage</option>
            <option value="MACRO_OR_SCRIPTS">Fast Gloo Wall Scripts / Macros</option>
            <option value="OTHER">Other Fair Play Violation</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Evidence Video Link (YouTube / Google Drive / Streamable) <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              id="report-evidence-link"
              type="url"
              required
              value={evidenceUrl}
              onChange={(e) => setEvidenceUrl(e.target.value)}
              placeholder="https://youtu.be/... or Google Drive video URL"
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 text-xs text-white outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Detailed Incident Description
          </label>
          <textarea
            id="report-desc-input"
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what happened, timestamp in video, suspect actions..."
            className="w-full p-3 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 text-xs text-white placeholder:text-slate-600 outline-none resize-none"
          />
        </div>

        <div className="pt-2">
          <button
            id="submit-report-btn"
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <ShieldAlert className="w-4 h-4" />
            )}
            {loading ? 'Submitting Report...' : 'SUBMIT ANTI-CHEAT REPORT'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
