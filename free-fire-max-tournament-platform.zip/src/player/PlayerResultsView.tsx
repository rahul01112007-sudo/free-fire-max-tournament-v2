import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Flame, Award, Users, Search, CheckCircle2, Gem } from 'lucide-react';
import { MatchResult, Tournament, formatPrizeAmount } from '../types';
import { listenAllResults } from '../services/resultService';
import { listenTournaments } from '../services/tournamentService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';

export const PlayerResultsView: React.FC = () => {
  const [results, setResults] = useState<MatchResult[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournamentId, setSelectedTournamentId] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubRes = listenAllResults((list) => {
      setResults(list);
      setLoading(false);
    });

    const unsubTourn = listenTournaments((list) => {
      setTournaments(list);
    });

    return () => {
      unsubRes();
      unsubTourn();
    };
  }, []);

  const filteredResults = results.filter((res) => {
    if (selectedTournamentId !== 'ALL' && res.tournamentId !== selectedTournamentId) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNameMatch = res.matchName.toLowerCase().includes(q);
      const winnerMatch = res.winners.some((w) => 
        w.ign.toLowerCase().includes(q) || 
        w.name.toLowerCase().includes(q) || 
        w.ffUid.includes(q)
      );
      return matchNameMatch || winnerMatch;
    }
    return true;
  });

  return (
    <div id="player-results-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            Official Match Results & Leaderboards
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Verified match standings, points, surviving qualified players & prize distribution
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <input
            id="results-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Player IGN, Free Fire UID, or Match Name..."
            className="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-500 text-xs text-white placeholder:text-slate-500 outline-none"
          />
        </div>
        <select
          id="results-tournament-select"
          value={selectedTournamentId}
          onChange={(e) => setSelectedTournamentId(e.target.value)}
          className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-amber-500 text-xs text-white outline-none"
        >
          <option value="ALL">All Tournaments</option>
          {tournaments.map((t) => (
            <option key={t.id} value={t.id}>
              {t.title} ({t.format})
            </option>
          ))}
        </select>
      </div>

      {/* Results List */}
      {filteredResults.length === 0 ? (
        <EmptyState
          id="no-results-empty"
          title="No published match results yet."
          description="Tournament match results and qualified finalists will appear here once verified and published by the admin desk."
        />
      ) : (
        <div className="space-y-6">
          {filteredResults.map((result) => (
            <div
              key={result.id}
              id={`result-card-${result.id}`}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl"
            >
              {/* Result Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={result.format} />
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider bg-amber-950/80 text-amber-400 border border-amber-600/50">
                      {result.stage}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white leading-snug">
                    {result.matchName}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {result.tournamentTitle || 'Championship Series'} • Published on {new Date(result.publishedAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {/* Mobile Card-Based Standings (< md) */}
              <div className="block md:hidden space-y-2.5">
                {result.winners.map((winner, idx) => {
                  return (
                    <div
                      key={idx}
                      className={`p-3.5 rounded-xl border space-y-2 text-xs ${
                        winner.rank === 1
                          ? 'bg-amber-950/30 border-amber-500/40'
                          : winner.rank === 2
                          ? 'bg-slate-900 border-slate-700'
                          : winner.rank === 3
                          ? 'bg-orange-950/25 border-orange-500/30'
                          : 'bg-slate-950 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                        <div className="flex items-center gap-2">
                          {winner.rank === 1 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-500 text-slate-950 font-black text-xs shrink-0">
                              🥇1
                            </span>
                          ) : winner.rank === 2 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-300 text-slate-950 font-black text-xs shrink-0">
                              🥈2
                            </span>
                          ) : winner.rank === 3 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-orange-600 text-white font-black text-xs shrink-0">
                              🥉3
                            </span>
                          ) : (
                            <span className="font-mono font-bold text-slate-400 px-2 py-0.5 bg-slate-900 rounded border border-slate-800">
                              #{winner.rank}
                            </span>
                          )}
                          <span className="font-bold text-white font-sans text-sm truncate">
                            {winner.ign}
                          </span>
                        </div>

                        {winner.prizeAmount ? (
                          <span className="font-extrabold text-amber-400 font-mono text-sm">
                            {formatPrizeAmount(winner.prizeAmount, winner.prizeType)}
                          </span>
                        ) : null}
                      </div>

                      <div className="grid grid-cols-3 gap-2 py-1 text-center font-mono">
                        <div className="p-1.5 bg-slate-900/80 rounded-lg border border-slate-800">
                          <span className="text-[9px] text-slate-500 uppercase block font-sans">Kills</span>
                          <span className="font-bold text-red-400">{winner.kills}</span>
                        </div>
                        <div className="p-1.5 bg-slate-900/80 rounded-lg border border-slate-800">
                          <span className="text-[9px] text-slate-500 uppercase block font-sans">Points</span>
                          <span className="font-bold text-amber-300">{winner.totalPoints}</span>
                        </div>
                        <div className="p-1.5 bg-slate-900/80 rounded-lg border border-slate-800 truncate">
                          <span className="text-[9px] text-slate-500 uppercase block font-sans">UID</span>
                          <span className="text-slate-300 text-[10px] truncate block">{winner.ffUid || '-'}</span>
                        </div>
                      </div>

                      <div className="pt-1 flex items-center justify-between">
                        {winner.qualified ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-600/60 text-[10px] font-bold">
                            <CheckCircle2 className="w-3 h-3" /> ADVANCED TO FINALS
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[10px] font-mono">ELIMINATED</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Desktop Leaderboard Table (md and above) */}
              <div className="hidden md:block overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-900/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-12 text-center">Rank</th>
                      <th className="py-2.5 px-3">Player / Squad IGN</th>
                      <th className="py-2.5 px-3">Free Fire UID</th>
                      <th className="py-2.5 px-3 text-center">Kills</th>
                      <th className="py-2.5 px-3 text-center">Pts</th>
                      <th className="py-2.5 px-3 text-center">Status / Advancement</th>
                      <th className="py-2.5 px-3 text-right">Prize</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {result.winners.map((winner, idx) => {
                      return (
                        <tr
                          key={idx}
                          className={`hover:bg-slate-900/50 transition-colors ${
                            winner.rank === 1
                              ? 'bg-amber-950/20'
                              : winner.rank === 2
                              ? 'bg-slate-800/30'
                              : winner.rank === 3
                              ? 'bg-orange-950/20'
                              : ''
                          }`}
                        >
                          <td className="py-2.5 px-3 text-center font-bold">
                            {winner.rank === 1 ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-500 text-slate-950 font-black text-xs">
                                🥇1
                              </span>
                            ) : winner.rank === 2 ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-300 text-slate-950 font-black text-xs">
                                🥈2
                              </span>
                            ) : winner.rank === 3 ? (
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-orange-600 text-white font-black text-xs">
                                🥉3
                              </span>
                            ) : (
                              `#${winner.rank}`
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-bold text-white font-sans">
                            {winner.ign}
                          </td>
                          <td className="py-2.5 px-3 text-slate-400">
                            {winner.ffUid}
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-red-400">
                            {winner.kills}
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-amber-300">
                            {winner.totalPoints}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            {winner.qualified ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-600/60 text-[10px] font-bold">
                                <CheckCircle2 className="w-3 h-3" /> ADVANCED TO FINALS
                              </span>
                            ) : (
                              <span className="text-slate-500 text-[10px]">ELIMINATED</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-extrabold text-amber-400 font-mono">
                            {winner.prizeAmount ? formatPrizeAmount(winner.prizeAmount, winner.prizeType) : '-'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {result.notes && (
                <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-400">
                  <span className="font-semibold text-slate-200">Match Admin Notes:</span> {result.notes}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
