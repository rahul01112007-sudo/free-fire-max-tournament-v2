import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  ShieldCheck, 
  Gamepad2, 
  Phone, 
  AlertCircle, 
  CheckCircle2, 
  Play, 
  Sparkles, 
  Flame, 
  Gift, 
  Lock,
  Unlock,
  Gem,
  DollarSign
} from 'lucide-react';
import { Modal } from '../components/Modal';
import { 
  Tournament, 
  Registration, 
  AdEntryProgress, 
  getTournamentPrizePositions, 
  formatPrizeAmount,
  formatEntryFeeDisplay,
  isDiamondPrizeType,
  normalizeEntryType,
  getPrizePoolLabel
} from '../types';
import { registerSoloPlayer } from '../services/registrationService';
import { listenAdEntryProgress } from '../services/adRewardService';
import { RewardedAdModal } from '../components/RewardedAdModal';
import { TournamentPaymentModal } from '../components/TournamentPaymentModal';
import { PaymentVerificationResult } from '../services/paymentService';
import { useAuth } from '../context/AuthContext';

interface SoloRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament | null;
  onSuccess: (reg: Registration) => void;
}

export const SoloRegistrationModal: React.FC<SoloRegistrationModalProps> = ({
  isOpen,
  onClose,
  tournament,
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [playerName, setPlayerName] = useState('');
  const [freeFireUid, setFreeFireUid] = useState('');
  const [ign, setIgn] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedReg, setConfirmedReg] = useState<Registration | null>(null);

  // Ad Progress State (for FREE_ADS entry type)
  const [adProgress, setAdProgress] = useState<AdEntryProgress | null>(null);
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);

  // Payment Checkout State (for PAID_IN_GAME entry type)
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  useEffect(() => {
    if (userProfile) {
      setPlayerName(userProfile.displayName || '');
      setFreeFireUid(userProfile.freeFireUid || '');
      setIgn(userProfile.ign || userProfile.displayName || '');
      setPhone(userProfile.phone || '');
    }
  }, [userProfile, isOpen]);

  useEffect(() => {
    if (isOpen) {
      setConfirmedReg(null);
      setError(null);
      setIsPaymentModalOpen(false);
    }
  }, [isOpen]);

  // Realtime listener for 5-ad entry progress
  useEffect(() => {
    if (!isOpen || !currentUser || !tournament) {
      setAdProgress(null);
      return;
    }

    const unsub = listenAdEntryProgress(currentUser.uid, tournament.id, (prog) => {
      setAdProgress(prog);
    });

    return () => unsub();
  }, [isOpen, currentUser, tournament]);

  if (!tournament) return null;

  const entryType = normalizeEntryType(tournament.entryType, tournament.entryFee);
  const isPaidEntry = entryType === 'PAID_IN_GAME';
  const isFreeDiamonds = entryType === 'FREE_IN_GAME';
  const isAdBased = entryType === 'FREE_ADS';

  const adsCompleted = adProgress?.adsCompleted || 0;
  const adsRequired = adProgress?.adsRequired || tournament.adsRequired || 5;
  const isUnlocked = Boolean(adProgress?.entryUnlocked || adsCompleted >= adsRequired);
  const prizePositions = getTournamentPrizePositions(tournament);
  const isDiamonds = isDiamondPrizeType(tournament.prizeType || tournament.rewardType);

  const handleStartWatchAd = () => {
    if (!currentUser) {
      setError('Please sign in to watch rewarded ads and enter tournaments.');
      return;
    }
    setError(null);
    setIsAdModalOpen(true);
  };

  const handleRewardEarned = (updated: AdEntryProgress) => {
    setAdProgress(updated);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('Please sign in to register.');
      return;
    }

    if (!freeFireUid.trim() || !ign.trim() || !phone.trim()) {
      setError('Please fill in all Free Fire player details.');
      return;
    }

    if (isPaidEntry) {
      // Open Payment Checkout Modal
      setIsPaymentModalOpen(true);
      return;
    }

    if (isAdBased && !isUnlocked) {
      setError(`Please complete all 5 rewarded ads to unlock your free entry (${adsCompleted}/${adsRequired} completed).`);
      return;
    }

    // Direct Free Registration (FREE_ADS or FREE_IN_GAME)
    try {
      setLoading(true);
      setError(null);
      const reg = await registerSoloPlayer({
        tournamentId: tournament.id,
        playerId: currentUser.uid,
        playerName: playerName.trim() || userProfile?.displayName || 'Player',
        freeFireUid: freeFireUid.trim(),
        ign: ign.trim(),
        phone: phone.trim(),
        paymentMethod: 'FREE',
      });

      setConfirmedReg(reg);
      onSuccess(reg);
    } catch (err: any) {
      console.warn('Solo registration notice:', err?.message || err);
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async (paymentResult: PaymentVerificationResult) => {
    if (!currentUser) return;
    try {
      setLoading(true);
      setError(null);

      const reg = await registerSoloPlayer({
        tournamentId: tournament.id,
        playerId: currentUser.uid,
        playerName: playerName.trim() || userProfile?.displayName || 'Player',
        freeFireUid: freeFireUid.trim(),
        ign: ign.trim(),
        phone: phone.trim(),
        paymentTransactionId: paymentResult.transactionId,
        utrNumber: paymentResult.transactionId.replace(/^TXN_/, ''),
        paymentMethod: paymentResult.paymentMethod,
        entryFeePaid: paymentResult.amount,
        isManualPending: paymentResult.isManualPending,
      });

      setConfirmedReg(reg);
      onSuccess(reg);
    } catch (err: any) {
      console.error('Paid registration processing error:', err);
      setError(err.message || 'Payment verified but slot assignment failed. Please contact support.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Modal
        id="solo-registration-modal"
        isOpen={isOpen}
        onClose={onClose}
        title={confirmedReg ? 'Registration Confirmed!' : isPaidEntry ? 'Solo Tournament Entry — PAID' : 'Solo Tournament Entry — FREE'}
        subtitle={confirmedReg ? 'Match and seat allocated in Firestore' : tournament.title}
        maxWidth="lg"
      >
        {confirmedReg ? (
          <div id="confirmed-registration-panel" className="space-y-4 py-2">
            <div className={`p-4 rounded-2xl text-center border ${
              isPaidEntry 
                ? 'bg-cyan-950/40 border-cyan-500/40' 
                : 'bg-emerald-950/40 border-emerald-500/40'
            }`}>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2.5 ${
                isPaidEntry ? 'bg-cyan-500/20 text-cyan-400' : 'bg-emerald-500/20 text-emerald-400'
              }`}>
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-white uppercase tracking-wider">
                {isPaidEntry ? 'REGISTRATION CONFIRMED (PAID ENTRY)' : 'REGISTRATION CONFIRMED (FREE ENTRY)'}
              </h4>
              <p className={`text-xs mt-1 ${isPaidEntry ? 'text-cyan-300' : 'text-emerald-300'}`}>
                {isPaidEntry 
                  ? `Entry fee of ₹${confirmedReg.entryFeePaid || tournament.entryFee} verified. Non-cash In-Game Diamond reward.`
                  : 'Your Free Fire MAX tournament registration is locked.'}
              </p>
            </div>

            <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-4 space-y-3">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Tournament</span>
                <span className="font-semibold text-white text-right max-w-[200px] truncate">
                  {confirmedReg.tournamentTitle}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Assigned Match</span>
                <span className="font-bold text-orange-400">
                  {confirmedReg.matchName}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Assigned Seat Number</span>
                <span className="font-extrabold text-white text-sm bg-orange-600/20 px-2.5 py-0.5 rounded border border-orange-500/40">
                  #{confirmedReg.seatNumber} / {tournament.participantsPerMatch || 48}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/80">
                <span className="text-slate-400">Player IGN & FF UID</span>
                <span className="font-medium text-slate-200">
                  {confirmedReg.ign} ({confirmedReg.freeFireUid})
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Entry Verification</span>
                <span className={`font-bold px-2 py-0.5 rounded text-[11px] border flex items-center gap-1 ${
                  isPaidEntry 
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40' 
                    : 'bg-emerald-950 text-emerald-400 border-emerald-600/40'
                }`}>
                  <CheckCircle2 className="w-3 h-3" />
                  {isPaidEntry ? `PAID ENTRY (₹${confirmedReg.entryFeePaid || tournament.entryFee} Verified)` : 'FREE ENTRY VERIFIED'}
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
              <span className="font-semibold text-orange-400">Room Credentials Notice:</span> Custom Room ID and Password will be automatically broadcast to your <span className="font-bold text-white">"My Match"</span> tab when released prior to match start.
            </div>

            <button
              id="view-my-match-after-reg-btn"
              onClick={onClose}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all cursor-pointer"
            >
              VIEW MY MATCH DESK
            </button>
          </div>
        ) : (
          <form id="solo-reg-form" onSubmit={handleFormSubmit} className="space-y-4">
            {error && (
              <div id="solo-reg-error" className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Tournament & Prize Banner */}
            <div className="p-3.5 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isDiamonds ? <Gem className="w-4 h-4 text-cyan-400" /> : <Gift className="w-4 h-4 text-amber-400" />}
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {isDiamonds ? 'FREE FIRE DIAMONDS REWARD' : `${(tournament.prizeType || tournament.rewardType || 'GIFT CARD').replace(/_/g, ' ')} POOL`}
                  </span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                  isPaidEntry 
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40' 
                    : 'bg-emerald-950 text-emerald-400 border-emerald-500/40'
                }`}>
                  ENTRY: {formatEntryFeeDisplay(tournament)}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">{getPrizePoolLabel(tournament.prizeType || tournament.rewardType)}</span>
                  <span className="font-extrabold text-amber-400">
                    {formatPrizeAmount(tournament.totalPrizeValue || tournament.prizePool, tournament.prizeType || tournament.rewardType)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">ENTRY TYPE</span>
                  <span className={`font-extrabold ${isPaidEntry ? 'text-cyan-400' : 'text-emerald-400'}`}>
                    {formatEntryFeeDisplay(tournament)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">SLOTS</span>
                  <span className="font-extrabold text-slate-300">{tournament.registeredCount} / {tournament.maxParticipants}</span>
                </div>
              </div>

              {isPaidEntry && (
                <div className="text-[10px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-800">
                  <span className="text-cyan-400 font-bold">Non-cash in-game reward:</span> Winner receives official Free Fire In-Game Diamonds top-up delivered to the registered UID snapshot. There is no cash prize or withdrawal.
                </div>
              )}

              {/* Dynamic Prize Breakdown */}
              <div className="pt-1.5">
                <div className="grid grid-cols-5 gap-1.5 text-center font-mono text-[10px]">
                  {prizePositions.slice(0, 5).map((p, idx) => (
                    <div 
                      key={idx} 
                      className={`p-1.5 rounded-lg border ${
                        idx === 0 
                          ? 'bg-amber-950/40 border-amber-500/50 text-amber-300' 
                          : 'bg-slate-900/60 border-slate-800 text-slate-400'
                      }`}
                    >
                      <span className="block font-sans text-[9px] font-bold">
                        {idx === 0 ? '1st (Champion)' : `#${idx + 1}`}
                      </span>
                      <span className="font-extrabold text-white">
                        {isDiamonds ? `${p.amount}💎` : `₹${p.amount}`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* AD UNLOCK STATUS (Only for FREE_ADS tournaments) */}
            {isAdBased && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Free Entry Ticket Requirement
                    </span>
                  </div>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    isUnlocked 
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40' 
                      : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                  }`}>
                    {isUnlocked ? 'TICKET UNLOCKED' : `${adsCompleted}/${adsRequired} Ads Watched`}
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1">
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className="bg-gradient-to-r from-orange-500 to-emerald-500 h-full transition-all duration-500"
                      style={{ width: `${Math.min(100, (adsCompleted / adsRequired) * 100)}%` }}
                    />
                  </div>
                </div>

                {!isUnlocked && (
                  <button
                    type="button"
                    id="watch-ad-for-entry-btn"
                    onClick={handleStartWatchAd}
                    className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="w-4 h-4" />
                    Watch Video Ad #{adsCompleted + 1} to Unlock Free Ticket
                  </button>
                )}
              </div>
            )}

            {/* FREE FIRE PLAYER PROFILE FORM */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Player Free Fire Profile
                </label>
                <span className="text-[10px] text-cyan-400">UID snapshot captured upon registration</span>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Player Name / Real Name <span className="text-orange-500">*</span>
                </label>
                <input
                  id="solo-reg-name"
                  type="text"
                  required
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                    <span>Free Fire UID <span className="text-orange-500">*</span></span>
                    <span className="text-[10px] text-cyan-400 font-mono">UID Snapshot</span>
                  </label>
                  <input
                    id="solo-reg-uid"
                    type="text"
                    required
                    value={freeFireUid}
                    onChange={(e) => setFreeFireUid(e.target.value)}
                    placeholder="e.g. 192837465"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Free Fire In-Game Name (IGN) <span className="text-orange-500">*</span>
                  </label>
                  <input
                    id="solo-reg-ign"
                    type="text"
                    required
                    value={ign}
                    onChange={(e) => setIgn(e.target.value)}
                    placeholder="e.g. IGNITE_CHAMP"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  WhatsApp / Phone Number <span className="text-orange-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="solo-reg-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 9876543210"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-orange-500 text-xs text-white outline-none font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                id="solo-reg-submit-btn"
                type="submit"
                disabled={loading || (isAdBased && !isUnlocked)}
                className={`w-full py-3 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  isPaidEntry
                    ? 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-slate-950 font-black shadow-cyan-600/30'
                    : 'bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 shadow-orange-600/30'
                }`}
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : isPaidEntry ? (
                  <DollarSign className="w-4 h-4" />
                ) : isUnlocked ? (
                  <Sparkles className="w-4 h-4" />
                ) : (
                  <Lock className="w-4 h-4" />
                )}
                {loading
                  ? 'Assigning Seat in Firestore...'
                  : isPaidEntry
                  ? `CONTINUE TO PAYMENT (₹${tournament.entryFee})`
                  : isAdBased && !isUnlocked
                  ? `WATCH ADS TO UNLOCK (${adsCompleted}/${adsRequired})`
                  : 'CONFIRM FREE REGISTRATION'}
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* Rewarded Ad Watch Modal */}
      <RewardedAdModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        tournamentId={tournament.id}
        onRewardEarned={handleRewardEarned}
      />

      {/* Tournament Payment Modal for Paid Entry */}
      {currentUser && (
        <TournamentPaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          tournament={tournament}
          userId={currentUser.uid}
          payerName={ign || playerName || 'Player'}
          freeFireUid={freeFireUid}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </>
  );
};
