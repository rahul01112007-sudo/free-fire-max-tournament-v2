import React, { useState, useEffect } from 'react';
import { 
  History, 
  Trophy, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  RotateCcw, 
  Search, 
  Filter, 
  DollarSign, 
  Users, 
  CreditCard, 
  Copy, 
  Check, 
  ExternalLink, 
  Calendar, 
  ChevronRight, 
  AlertCircle, 
  Sparkles,
  Gift,
  X,
  FileText,
  Headphones,
  ShieldCheck,
  ShieldAlert,
  Gamepad2,
  Lock,
  ArrowUpRight,
  Send,
  Edit3
} from 'lucide-react';
import { 
  Registration, 
  Tournament, 
  formatEntryFeeDisplay, 
  formatPrizeAmount, 
  getPrizePoolLabel,
  isDiamondPrizeType 
} from '../types';
import { listenUserRegistrations } from '../services/registrationService';
import { listenTournaments } from '../services/tournamentService';
import { submitPlayerRefundUpi, isRegistrationDenied } from '../services/refundService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { Modal } from '../components/Modal';
import { useAuth } from '../context/AuthContext';

interface PlayerHistoryViewProps {
  onNavigateToTournaments: () => void;
  onNavigateToSupport?: () => void;
  onOpenPlayerAuth: () => void;
}

export const PlayerHistoryView: React.FC<PlayerHistoryViewProps> = ({
  onNavigateToTournaments,
  onNavigateToSupport,
  onOpenPlayerAuth,
}) => {
  const { currentUser, userProfile } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournamentsMap, setTournamentsMap] = useState<Record<string, Tournament>>({});
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'COMPLETED' | 'CANCELLED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected registration for Receipt Modal
  const [selectedReceiptReg, setSelectedReceiptReg] = useState<Registration | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Player UPI submission state
  const [upiInputs, setUpiInputs] = useState<Record<string, string>>({});
  const [submittingUpiFor, setSubmittingUpiFor] = useState<string | null>(null);
  const [upiSubmitSuccess, setUpiSubmitSuccess] = useState<Record<string, string>>({});
  const [upiSubmitError, setUpiSubmitError] = useState<Record<string, string>>({});
  const [editingUpiFor, setEditingUpiFor] = useState<Record<string, boolean>>({});

  const handleSubmitUpi = async (regId: string) => {
    const upi = upiInputs[regId]?.trim();
    if (!upi) {
      setUpiSubmitError((prev) => ({ ...prev, [regId]: 'Please enter a valid UPI ID (e.g. 9876543210@paytm or name@oksbi)' }));
      return;
    }
    setSubmittingUpiFor(regId);
    setUpiSubmitError((prev) => ({ ...prev, [regId]: '' }));
    try {
      await submitPlayerRefundUpi(regId, upi);
      setUpiSubmitSuccess((prev) => ({ 
        ...prev, 
        [regId]: `UPI ID "${upi}" submitted successfully! The admin will transfer your refund payout to this UPI ID.` 
      }));
      setEditingUpiFor((prev) => ({ ...prev, [regId]: false }));
    } catch (err: any) {
      setUpiSubmitError((prev) => ({ ...prev, [regId]: err.message || 'Failed to submit UPI ID' }));
    } finally {
      setSubmittingUpiFor(null);
    }
  };

  // Listen to tournaments map
  useEffect(() => {
    const unsub = listenTournaments((list) => {
      const map: Record<string, Tournament> = {};
      list.forEach((t) => {
        map[t.id] = t;
      });
      setTournamentsMap(map);
    });
    return () => unsub();
  }, []);

  // Listen to current player's registrations
  useEffect(() => {
    if (!currentUser) {
      setRegistrations([]);
      return;
    }
    const unsub = listenUserRegistrations(currentUser.uid, (list) => {
      setRegistrations(list);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4">
        <EmptyState
          id="auth-required-history"
          title="Sign in to view your Tournament History"
          description="Log in with your Free Fire player account to track past matches, finished rankings, and entry fee refund receipts."
          actionText="Player Sign In"
          onAction={onOpenPlayerAuth}
        />
      </div>
    );
  }

  // Combine registration with tournament details
  const decoratedList = registrations.map((reg) => {
    const tourn = tournamentsMap[reg.tournamentId];
    const isCancelled = tourn?.status === 'CANCELLED' || reg.refundStatus === 'PENDING' || reg.refundStatus === 'REFUNDED' || reg.paymentStatus === 'REFUNDED';
    const isCompleted = tourn?.status === 'COMPLETED';
    return {
      reg,
      tourn,
      isCancelled,
      isCompleted,
    };
  });

  const completedCount = decoratedList.filter((d) => d.isCompleted).length;
  const cancelledCount = decoratedList.filter((d) => d.isCancelled).length;
  const refundedCount = decoratedList.filter(
    (d) => d.reg.refundStatus === 'REFUNDED' || d.reg.paymentStatus === 'REFUNDED'
  ).length;

  const filteredList = decoratedList.filter((item) => {
    if (activeFilter === 'COMPLETED' && !item.isCompleted) return false;
    if (activeFilter === 'CANCELLED' && !item.isCancelled) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const title = (item.tourn?.title || item.reg.tournamentTitle || '').toLowerCase();
      const match = (item.reg.matchName || '').toLowerCase();
      const utr = (item.reg.utrNumber || '').toLowerCase();
      const refUtr = (item.reg.refundUtr || '').toLowerCase();
      return title.includes(q) || match.includes(q) || utr.includes(q) || refUtr.includes(q);
    }
    return true;
  });

  return (
    <div id="player-history-view" className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <History className="w-6 h-6 text-orange-400" />
            My Tournament History & Refunds
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit your past tournaments, match receipts, and track refunds for tournaments cancelled mid-way
          </p>
        </div>

        <button
          id="btn-explore-upcoming"
          onClick={onNavigateToTournaments}
          className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer self-start sm:self-auto"
        >
          <Trophy className="w-4 h-4" /> Browse Tournaments
        </button>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Played</span>
            <Gamepad2 className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-2xl font-black text-white">{registrations.length}</p>
          <p className="text-[10px] text-slate-500">Tournament participations</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-300">{completedCount}</p>
          <p className="text-[10px] text-slate-500">Matches concluded</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-rose-950/60 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider">Cancelled</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-black text-rose-300">{cancelledCount}</p>
          <p className="text-[10px] text-slate-500">Cancelled by admin</p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-teal-500/30 space-y-1 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">Refunds Done</span>
            <RotateCcw className="w-4 h-4 text-teal-400" />
          </div>
          <p className="text-2xl font-black text-teal-300">{refundedCount}</p>
          <p className="text-[10px] text-teal-400/80 font-medium">UPI & Ad pass returns</p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <button
            id="player-filter-all"
            onClick={() => setActiveFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'ALL'
                ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All Matches ({registrations.length})
          </button>

          <button
            id="player-filter-cancelled"
            onClick={() => setActiveFilter('CANCELLED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeFilter === 'CANCELLED'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-rose-300 border border-slate-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Cancelled & Refunds ({cancelledCount})
          </button>

          <button
            id="player-filter-completed"
            onClick={() => setActiveFilter('COMPLETED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeFilter === 'COMPLETED'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-emerald-300 border border-slate-800'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Completed ({completedCount})
          </button>
        </div>

        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            id="search-player-history"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tournament, match, or UTR..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
          />
        </div>
      </div>

      {/* History Cards List */}
      {filteredList.length === 0 ? (
        <EmptyState
          id="no-player-history"
          title="No tournaments found in this history view."
          description="Join upcoming Free Fire MAX tournaments to battle for prizes, earn leaderboard points, and view receipts."
          actionText="Find a Tournament"
          onAction={onNavigateToTournaments}
        />
      ) : (
        <div className="space-y-4">
          {filteredList.map(({ reg, tourn, isCancelled, isCompleted }) => {
            const isDenied = isRegistrationDenied(reg);
            const isPaid = reg.entryType === 'PAID_IN_GAME' || (reg.entryFeePaid && reg.entryFeePaid > 0) || reg.paymentMethod !== 'FREE';
            const fee = reg.entryFeePaid || (tourn?.entryFee || 0);
            const isRefunded = reg.refundStatus === 'REFUNDED' || reg.paymentStatus === 'REFUNDED';
            const isRefundPending = isCancelled && isPaid && !isRefunded && !isDenied;

            return (
              <div
                key={reg.id}
                id={`player-history-card-${reg.id}`}
                className={`p-4 sm:p-5 rounded-2xl bg-slate-900 border transition-all shadow-xl space-y-4 ${
                  isCancelled
                    ? isDenied
                      ? 'border-rose-900/60 bg-slate-900/90'
                      : isRefunded
                      ? 'border-teal-900/60 hover:border-teal-700'
                      : 'border-amber-500/50 hover:border-amber-500/80 bg-slate-900/90'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <StatusBadge status={reg.format} />
                    <StatusBadge status={tourn?.status || (isCancelled ? 'CANCELLED' : 'COMPLETED')} />
                    
                    {isCancelled && (
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase border ${
                        isDenied
                          ? 'bg-rose-950/80 text-rose-300 border-rose-500/60'
                          : isRefunded
                          ? 'bg-teal-950/80 text-teal-300 border-teal-500/60 shadow-sm shadow-teal-500/20'
                          : 'bg-amber-950/80 text-amber-300 border-amber-500/60 animate-pulse'
                      }`}>
                        {isDenied ? '🚫 REGISTRATION DENIED • NO REFUND' : isRefunded ? '✓ REFUND PROCESSED' : '⚠️ REFUND IN PROGRESS'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{new Date(reg.createdAt).toLocaleDateString()}</span>
                    <span>•</span>
                    <span className="text-slate-300 font-bold">Seat #{reg.seatNumber}</span>
                  </div>
                </div>

                {/* Tournament Title & Match */}
                <div className="space-y-1">
                  <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                    {tourn?.title || reg.tournamentTitle}
                  </h3>
                  <p className="text-xs text-orange-400 font-semibold flex items-center gap-1.5">
                    <Gamepad2 className="w-3.5 h-3.5" />
                    {reg.matchName || `Qualifier Match #${reg.matchNumber}`}
                    {reg.teamName && (
                      <span className="text-slate-400 font-normal">
                        • Team: <strong className="text-slate-200">{reg.teamName}</strong>
                      </span>
                    )}
                  </p>
                </div>

                {/* CANCELLED TOURNAMENT REFUND NOTIFICATION CARD (The core feature requested by user) */}
                {isCancelled && (
                  isDenied ? (
                    <div className="p-4 rounded-xl border space-y-3 bg-rose-950/30 border-rose-500/50 text-rose-200">
                      <div className="flex items-start justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2 font-bold text-sm text-rose-300">
                          <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
                          <span>Tournament Cancelled — Registration Denied (Ineligible for Refund)</span>
                        </div>
                        <span className="text-xs font-mono font-bold bg-rose-950/80 px-2 py-0.5 rounded border border-rose-500/40 text-rose-300">
                          PAYMENT REJECTED
                        </span>
                      </div>
                      <p className="text-xs leading-relaxed text-slate-300 pl-7">
                        This match was terminated by the administrator. However, your registration was rejected/denied by the administrator due to invalid or fake payment submission.
                      </p>
                      <div className="ml-7 p-3 bg-slate-950/90 rounded-xl border border-rose-900/60 space-y-1 text-xs">
                        <span className="text-[10px] text-rose-400 uppercase font-bold block">Rejection Note:</span>
                        <p className="text-rose-200 italic">{reg.paymentNotes || 'Fake payment or invalid transaction reference detected.'}</p>
                        <p className="text-[11px] text-slate-400 font-mono pt-1">
                          Submitted Reference: {reg.utrNumber || reg.paymentTransactionId || 'None'} • Excluded from refund queue. No money owed.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className={`p-4 rounded-xl border space-y-3 ${
                      isRefunded
                        ? 'bg-teal-950/30 border-teal-500/40 text-teal-200'
                        : 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                    }`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 font-bold text-sm">
                          {isRefunded ? (
                            <>
                              <CheckCircle2 className="w-5 h-5 text-teal-400 shrink-0" />
                              <span className="text-teal-300">
                                Tournament Cancelled — Refund Successfully Credited!
                              </span>
                            </>
                          ) : (
                            <>
                              <RotateCcw className="w-5 h-5 text-amber-400 shrink-0 animate-spin" />
                              <span className="text-amber-300">
                                Tournament Cancelled Mid-Way — Refund in Progress
                              </span>
                            </>
                          )}
                        </div>

                        <span className="text-xs font-mono font-bold bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                          {isPaid ? `Entry Fee: ₹${fee}` : 'Free Ad Entry'}
                        </span>
                      </div>

                      {/* Cancellation reason */}
                      <p className="text-xs leading-relaxed opacity-90 pl-7">
                        <strong>Admin Announcement:</strong> {tourn?.cancellationReason || 'The tournament was terminated mid-way without completing. All joined players receive full refunds.'}
                      </p>

                      {/* Refund Receipt Details OR Interactive UPI Submission Desk */}
                      {isRefunded ? (
                        <div className="mt-2 p-3.5 bg-slate-950/90 rounded-xl border border-teal-500/40 space-y-2 text-xs">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-teal-900/40 pb-2">
                            <div>
                              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Refunded Amount</span>
                              <span className="text-lg font-black text-emerald-400">
                                {reg.refundAmount ? `₹${reg.refundAmount}` : (isPaid ? `₹${fee}` : 'Free Ad Pass Restored')}
                              </span>
                            </div>

                            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-mono text-[11px] font-bold border border-emerald-500/40 flex items-center gap-1 self-start sm:self-auto">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>REFUND COMPLETED</span>
                            </span>
                          </div>

                          {/* UPI and UTR Details */}
                          <div className="space-y-1.5 text-[11px]">
                            {(reg.refundUpiId || reg.phone) && (
                              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                                <span className="text-slate-400">Transferred to UPI ID:</span>
                                <span className="font-mono font-bold text-teal-300">
                                  {reg.refundUpiId || reg.phone}
                                </span>
                              </div>
                            )}

                            {reg.refundUtr && (
                              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                                <span className="text-slate-400">Bank / UPI Refund UTR:</span>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                                    {reg.refundUtr}
                                  </span>
                                  <button
                                    id={`btn-copy-refund-utr-${reg.id}`}
                                    type="button"
                                    onClick={() => copyToClipboard(reg.refundUtr!, `refund-utr-${reg.id}`)}
                                    className="text-slate-400 hover:text-white cursor-pointer"
                                    title="Copy Refund UTR"
                                  >
                                    {copiedId === `refund-utr-${reg.id}` ? (
                                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3.5 h-3.5" />
                                    )}
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>

                          {reg.refundNotes && (
                            <p className="text-[11px] text-slate-300 border-t border-slate-800/80 pt-1.5">
                              <strong className="text-slate-400">Admin Note:</strong> {reg.refundNotes}
                            </p>
                          )}

                          <div className="text-[10px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-900">
                            <span>
                              Processed by: <strong className="text-slate-300">{reg.refundedBy || 'Head Admin'}</strong>
                            </span>
                            {reg.refundedAt && (
                              <span>{new Date(reg.refundedAt).toLocaleString()}</span>
                            )}
                          </div>
                        </div>
                      ) : (
                        /* Player UPI Submission Desk */
                        <div className="mt-2 p-3.5 bg-slate-950/95 rounded-xl border-2 border-amber-500/50 space-y-3">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <div>
                              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                                <RotateCcw className="w-4 h-4 text-amber-400" />
                                Submit Your UPI ID to Receive Refund (₹{fee})
                              </h4>
                              <p className="text-[11px] text-slate-300 mt-1">
                                Enter your Google Pay, PhonePe, Paytm, BHIM or Bank UPI ID. The administrator will manually transfer your entry fee refund directly to this UPI address and post the bank transaction UTR.
                              </p>
                            </div>
                            <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full text-[10px] font-mono font-bold shrink-0">
                              AWAITING PAYOUT
                            </span>
                          </div>

                          {/* If player already submitted UPI and is not editing */}
                          {reg.refundUpiId && !editingUpiFor[reg.id] ? (
                            <div className="p-3 rounded-xl bg-teal-950/40 border border-teal-500/40 space-y-2">
                              <div className="flex items-center justify-between flex-wrap gap-2">
                                <div className="flex items-center gap-1.5 text-xs text-teal-300 font-bold">
                                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                                  <span>Your Payout UPI ID is Submitted:</span>
                                </div>
                                <button
                                  type="button"
                                  id={`btn-edit-upi-${reg.id}`}
                                  onClick={() => {
                                    setEditingUpiFor((prev) => ({ ...prev, [reg.id]: true }));
                                    setUpiInputs((prev) => ({ ...prev, [reg.id]: reg.refundUpiId || '' }));
                                  }}
                                  className="text-[11px] text-amber-400 hover:text-amber-300 underline font-semibold cursor-pointer inline-flex items-center gap-1"
                                >
                                  <Edit3 className="w-3 h-3" />
                                  <span>Edit / Change UPI ID</span>
                                </button>
                              </div>

                              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900 border border-teal-500/30">
                                <span className="font-mono text-sm font-black text-white">{reg.refundUpiId}</span>
                                <button
                                  type="button"
                                  onClick={() => copyToClipboard(reg.refundUpiId!, `upi-reg-${reg.id}`)}
                                  className="p-1 text-slate-400 hover:text-white cursor-pointer"
                                  title="Copy UPI ID"
                                >
                                  {copiedId === `upi-reg-${reg.id}` ? (
                                    <Check className="w-3.5 h-3.5 text-teal-400" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>

                              <p className="text-[10px] text-slate-400">
                                {reg.refundUpiSubmittedAt ? `Submitted on ${new Date(reg.refundUpiSubmittedAt).toLocaleString()}. ` : ''}
                                The admin has been notified and will transfer your ₹{fee} refund manually to this address.
                              </p>
                            </div>
                          ) : (
                            /* Input form to enter / submit UPI ID */
                            <div className="space-y-2 pt-1">
                              <label className="block text-[11px] font-bold text-slate-300">
                                {reg.refundUpiId ? 'Update your payout UPI ID:' : 'Enter your Google Pay / PhonePe / Paytm UPI ID:'}
                              </label>
                              <div className="flex flex-col sm:flex-row gap-2">
                                <input
                                  type="text"
                                  id={`input-upi-${reg.id}`}
                                  placeholder="e.g. 9876543210@paytm or player@okhdfcbank"
                                  value={upiInputs[reg.id] !== undefined ? upiInputs[reg.id] : (reg.refundUpiId || '')}
                                  onChange={(e) => {
                                    setUpiInputs((prev) => ({ ...prev, [reg.id]: e.target.value }));
                                    if (upiSubmitError[reg.id]) {
                                      setUpiSubmitError((prev) => ({ ...prev, [reg.id]: '' }));
                                    }
                                  }}
                                  className="flex-1 bg-slate-900 border border-slate-700 focus:border-orange-500 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 outline-none font-mono"
                                />
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    id={`btn-submit-upi-${reg.id}`}
                                    disabled={submittingUpiFor === reg.id}
                                    onClick={() => handleSubmitUpi(reg.id)}
                                    className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-600/30 cursor-pointer min-h-[36px]"
                                  >
                                    <Send className="w-3.5 h-3.5" />
                                    <span>{submittingUpiFor === reg.id ? 'Submitting...' : 'Submit UPI ID'}</span>
                                  </button>
                                  {editingUpiFor[reg.id] && (
                                    <button
                                      type="button"
                                      onClick={() => setEditingUpiFor((prev) => ({ ...prev, [reg.id]: false }))}
                                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                                    >
                                      Cancel
                                    </button>
                                  )}
                                </div>
                              </div>

                              {upiSubmitError[reg.id] && (
                                <p className="text-[11px] text-rose-400 font-semibold flex items-center gap-1 mt-1">
                                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                                  <span>{upiSubmitError[reg.id]}</span>
                                </p>
                              )}

                              {upiSubmitSuccess[reg.id] && (
                                <p className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                                  <span>{upiSubmitSuccess[reg.id]}</span>
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                )}

                {/* Key Metrics Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-semibold">Free Fire UID</span>
                    <span className="font-mono font-bold text-cyan-400">{reg.freeFireUid}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-semibold">In-Game IGN</span>
                    <span className="font-bold text-white truncate max-w-[120px] mx-auto block">{reg.ign || reg.playerName}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-semibold">Entry Ticket</span>
                    <span className="font-bold text-emerald-400">
                      {isPaid ? `Paid ₹${fee}` : 'Free (5 Ads)'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-semibold">Payment Txn</span>
                    <span className="font-mono text-slate-300 truncate max-w-[100px] mx-auto block text-[11px]">
                      {reg.utrNumber || 'FREE_ENTRY'}
                    </span>
                  </div>
                </div>

                {/* Actions Bar */}
                <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800">
                  <div className="text-xs text-slate-400">
                    Registration ID: <span className="font-mono text-slate-300">{reg.id.slice(0, 10)}...</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {onNavigateToSupport && isCancelled && !isRefunded && (
                      <button
                        onClick={onNavigateToSupport}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Headphones className="w-3.5 h-3.5 text-orange-400" />
                        Help
                      </button>
                    )}

                    <button
                      id={`btn-view-receipt-${reg.id}`}
                      onClick={() => setSelectedReceiptReg(reg)}
                      className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors border border-slate-700"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      View Receipt & Proof
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Official Match & Refund Receipt Modal */}
      {selectedReceiptReg && (
        <Modal
          id="match-receipt-modal"
          isOpen={true}
          onClose={() => setSelectedReceiptReg(null)}
          title="Esports Tournament Receipt & Proof"
          subtitle="Official tournament participation and payment/refund verification record"
          maxWidth="md"
        >
          <div className="space-y-4">
            {/* Header Ticket Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-orange-950/60 via-slate-950 to-slate-900 border border-orange-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black text-orange-400 uppercase tracking-wider">
                  FREE FIRE MAX ESPORTS • OFFICIAL ENTRY
                </span>
                <StatusBadge status={tournamentsMap[selectedReceiptReg.tournamentId]?.status || 'ARCHIVED'} />
              </div>
              <h4 className="text-base font-black text-white">
                {tournamentsMap[selectedReceiptReg.tournamentId]?.title || selectedReceiptReg.tournamentTitle}
              </h4>
              <p className="text-xs text-slate-400">
                Match: {selectedReceiptReg.matchName} • Seat #{selectedReceiptReg.seatNumber}
              </p>
            </div>

            {/* Details Table */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Registration ID:</span>
                <span className="font-mono text-white font-bold">{selectedReceiptReg.id}</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Player IGN:</span>
                <span className="font-bold text-white">{selectedReceiptReg.ign || selectedReceiptReg.playerName}</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Free Fire UID:</span>
                <span className="font-mono text-cyan-400 font-bold">{selectedReceiptReg.freeFireUid}</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Phone / Registered UPI:</span>
                <span className="font-bold text-slate-300">{selectedReceiptReg.phone || 'N/A'}</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Entry Payment Method:</span>
                <span className="font-bold text-emerald-400">{selectedReceiptReg.paymentMethod || 'UPI'}</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Original Transaction UTR:</span>
                <span className="font-mono text-slate-200">{selectedReceiptReg.utrNumber || 'N/A'}</span>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-400">Registered On:</span>
                <span className="text-slate-300">{new Date(selectedReceiptReg.createdAt).toLocaleString()}</span>
              </div>
            </div>

            {/* Refund Info Section if Cancelled/Refunded */}
            {(selectedReceiptReg.refundStatus === 'REFUNDED' || selectedReceiptReg.paymentStatus === 'REFUNDED') && (
              <div className="p-3.5 rounded-xl bg-teal-950/40 border border-teal-500/40 space-y-2 text-xs text-teal-200">
                <div className="flex items-center gap-1.5 font-bold text-teal-300">
                  <ShieldCheck className="w-4 h-4 text-teal-400" />
                  <span>Refund Certificate</span>
                </div>
                {selectedReceiptReg.refundUpiId && (
                  <div className="flex items-center justify-between">
                    <span className="text-teal-400/80">Credited to UPI ID:</span>
                    <span className="font-mono font-bold text-teal-200">
                      {selectedReceiptReg.refundUpiId}
                    </span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-teal-400/80">Refund UTR:</span>
                  <span className="font-mono font-bold text-white bg-teal-950 px-2 py-0.5 rounded border border-teal-500/40">
                    {selectedReceiptReg.refundUtr || 'Processed by Admin'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-teal-400/80">Amount Returned:</span>
                  <span className="font-bold text-emerald-300">
                    ₹{selectedReceiptReg.refundAmount || selectedReceiptReg.entryFeePaid || 0}
                  </span>
                </div>
                {selectedReceiptReg.refundNotes && (
                  <p className="text-[11px] text-teal-300/90 pt-1 border-t border-teal-500/30">
                    <strong>Admin Note:</strong> {selectedReceiptReg.refundNotes}
                  </p>
                )}
              </div>
            )}

            <div className="flex items-center justify-end pt-2">
              <button
                onClick={() => setSelectedReceiptReg(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition-colors"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
