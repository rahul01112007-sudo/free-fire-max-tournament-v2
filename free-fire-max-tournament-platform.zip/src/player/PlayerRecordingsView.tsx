import React, { useState, useEffect } from 'react';
import { Video, CheckCircle2, Clock, XCircle, ExternalLink, AlertCircle } from 'lucide-react';
import { MatchRecording } from '../types';
import { listenUserRecordings } from '../services/recordingService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { useAuth } from '../context/AuthContext';

export const PlayerRecordingsView: React.FC = () => {
  const { currentUser } = useAuth();
  const [recordings, setRecordings] = useState<MatchRecording[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) {
      setRecordings([]);
      setLoading(false);
      return;
    }

    const unsub = listenUserRecordings(currentUser.uid, (list) => {
      setRecordings(list);
      setLoading(false);
    });

    return () => unsub();
  }, [currentUser]);

  if (!currentUser) {
    return (
      <EmptyState
        id="recordings-signin-empty"
        title="Sign In to View POV Submissions"
        description="Submit and track your Free Fire MAX match screen recordings for prize validation and fair-play anti-cheat checks."
      />
    );
  }

  return (
    <div id="player-recordings-view" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Video className="w-6 h-6 text-orange-400" />
            My Submitted POV Recordings
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Track verification status of your match recordings submitted for anti-cheat verification
          </p>
        </div>
      </div>

      {recordings.length === 0 ? (
        <EmptyState
          id="no-recordings-empty"
          title="No match recordings submitted yet."
          description="After playing in your tournament match, submit your screen recording link from the 'My Match' tab to confirm your rank and prizes."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recordings.map((rec) => (
            <div
              key={rec.id}
              id={`recording-card-${rec.id}`}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-white leading-tight">
                    {rec.matchName || 'Tournament Match'}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {rec.tournamentTitle || 'Free Fire MAX Tournament'}
                  </p>
                </div>
                <StatusBadge status={rec.status} />
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs space-y-1.5 font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>POV Type:</span>
                  <span className="text-slate-200">{rec.povType.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Player IGN:</span>
                  <span className="text-slate-200">{rec.ign}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Submitted At:</span>
                  <span className="text-slate-400 text-[11px]">{new Date(rec.submittedAt).toLocaleDateString()}</span>
                </div>
              </div>

              {rec.notes && (
                <p className="text-xs text-slate-300 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/50">
                  <span className="text-orange-400 font-semibold">Notes:</span> {rec.notes}
                </p>
              )}

              {rec.adminFeedback && (
                <div className="p-3 rounded-xl bg-orange-950/30 border border-orange-500/30 text-xs text-orange-200">
                  <span className="font-bold block text-orange-400">Admin Review Feedback:</span>
                  {rec.adminFeedback}
                </div>
              )}

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <a
                  href={rec.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 font-semibold"
                >
                  Open Recording Link <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
