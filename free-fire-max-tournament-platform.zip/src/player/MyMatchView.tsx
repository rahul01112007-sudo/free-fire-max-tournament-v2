import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  Lock, 
  Unlock, 
  Copy, 
  Check, 
  Video, 
  ShieldAlert, 
  Users, 
  Clock, 
  AlertCircle, 
  ArrowUpRight,
  ShieldCheck,
  FileText,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { Registration, RoomCredentials, Tournament } from '../types';
import { listenUserRegistrations } from '../services/registrationService';
import { listenRoomCredentials } from '../services/roomService';
import { listenTournaments } from '../services/tournamentService';
import { StatusBadge } from '../components/StatusBadge';
import { EmptyState } from '../components/EmptyState';
import { SubmitRecordingModal } from './SubmitRecordingModal';
import { ReportPlayerModal } from './ReportPlayerModal';
import { TournamentEntryCardModal } from '../components/TournamentEntryCardModal';
import { useAuth } from '../context/AuthContext';

interface MyMatchViewProps {
  onNavigateToTournaments: () => void;
  onOpenPlayerAuth: () => void;
  onNavigateToHistory?: () => void;
}

interface MatchCardProps {
  registration: Registration;
  tournament?: Tournament;
  onOpenSubmitRecording: (reg: Registration) => void;
  onOpenReportPlayer: (reg: Registration) => void;
  onOpenEntryCard: (reg: Registration) => void;
  onNavigateToHistory?: () => void;
}

const MatchCard: React.FC<MatchCardProps> = ({
  registration,
  tournament,
  onOpenSubmitRecording,
  onOpenReportPlayer,
  onOpenEntryCard,
  onNavigateToHistory,
}) => {
  const [room, setRoom] = useState<RoomCredentials | null>(null);
  const [copiedRoomId, setCopiedRoomId] = useState(false);
  const [copiedPassword, setCopiedPassword] = useState(false);

  useEffect(() => {
    // Realtime listener for match room credentials
    const unsub = listenRoomCredentials(registration.matchId, (roomData) => {
      setRoom(roomData);
    });
    return () => unsub();
  }, [registration.matchId]);

  const handleCopy = (text: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedRoomId(true);
      setTimeout(() => setCopiedRoomId(false), 2000);
    } else {
      setCopiedPassword(true);
      setTimeout(() => setCopiedPassword(false), 2000);
    }
  };

  const isDenied = registration.paymentStatus === 'REJECTED' || (registration.paymentStatus as string) === 'DENIED';
  const isCancelled = tournament?.status === 'CANCELLED' || registration.refundStatus === 'PENDING' || registration.refundStatus === 'REFUNDED' || registration.paymentStatus === 'REFUNDED';
  const isVerified = (registration.paymentStatus === 'VERIFIED' || registration.paymentStatus === 'APPROVED') && !isCancelled;
  const isPending = (registration.paymentStatus === 'PENDING' || registration.paymentStatus === 'PENDING_APPROVAL') && !isCancelled;
  const isRoomReleased = isVerified && room?.status === 'RELEASED';

  return (
    <div
      id={`my-match-card-${registration.id}`}
      className={`rounded-2xl border p-5 space-y-4 shadow-xl transition-all ${
        isCancelled
          ? 'bg-slate-900/95 border-rose-500/60 ring-1 ring-rose-500/30'
          : !isVerified
          ? 'bg-slate-900/90 border-amber-500/40'
          : isRoomReleased
          ? 'bg-slate-900 border-emerald-500/60 ring-1 ring-emerald-500/30'
          : 'bg-slate-900/90 border-slate-800 hover:border-emerald-500/40'
      }`}
    >
      {/* Cancellation Notice Banner or Payment Status Banner */}
      {isCancelled ? (
        <div 
          id={`cancelled-banner-${registration.id}`}
          className="p-4 bg-gradient-to-r from-rose-950/80 via-slate-950 to-slate-950 rounded-xl border-2 border-rose-500/70 shadow-lg shadow-rose-950/40 space-y-3"
        >
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2 text-rose-300 font-extrabold text-sm sm:text-base">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
              <span>THE MATCH IS NOW CANCELLED BY ADMIN</span>
            </div>
            <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider border ${
              isDenied
                ? 'bg-rose-950/90 text-rose-400 border-rose-500/60'
                : registration.refundStatus === 'REFUNDED'
                ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500/50'
                : 'bg-rose-600/30 text-rose-300 border-rose-500/40 animate-pulse'
            }`}>
              {isDenied 
                ? '🚫 REGISTRATION DENIED • NO REFUND' 
                : registration.refundStatus === 'REFUNDED' 
                ? '✓ REFUND COMPLETED' 
                : '⚠️ REFUND DESK ACTIVE'}
            </span>
          </div>

          <div className="text-xs text-slate-300 space-y-2">
            {isDenied ? (
              <div className="space-y-1.5 leading-relaxed">
                <p className="text-rose-200">
                  This tournament was terminated by the administrator. However, your registration was <strong>denied by the admin due to invalid or fake payment submission</strong>.
                </p>
                <div className="text-[11px] text-rose-300/90 bg-rose-950/40 p-2.5 rounded-lg border border-rose-500/30">
                  <span className="text-rose-400 font-bold uppercase text-[10px] block">Admin Rejection Notice:</span>
                  <span>{registration.paymentNotes || 'Fake payment or unverified transaction reference detected.'}</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Because valid entry funds were never verified for this registration, this entry is excluded from refunds.
                </p>
              </div>
            ) : (
              <>
                <p className="leading-relaxed">
                  This tournament has been cancelled mid-way by the administrator. <strong className="text-white">For more information and to submit your UPI ID for your refund, please go to the History for Refund section.</strong>
                </p>
                {tournament?.cancellationReason && (
                  <div className="text-[11px] text-slate-300 bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-rose-400 font-bold uppercase text-[10px] block">Cancellation Reason:</span>
                    <span className="italic">{tournament.cancellationReason}</span>
                  </div>
                )}
                {registration.refundUpiId && (
                  <div className="text-[11px] text-teal-300 font-mono bg-teal-950/40 border border-teal-500/30 p-2 rounded-lg flex items-center justify-between">
                    <span>Submitted Refund UPI ID: <strong>{registration.refundUpiId}</strong></span>
                    <span className="text-[10px] text-teal-400 uppercase font-bold">
                      {registration.refundStatus === 'REFUNDED' ? 'Paid via UPI' : 'Awaiting Admin Transfer'}
                    </span>
                  </div>
                )}
                {registration.refundStatus === 'REFUNDED' && registration.refundUtr && (
                  <div className="text-[11px] text-emerald-300 font-mono bg-emerald-950/40 border border-emerald-500/30 p-2 rounded-lg">
                    <span>Bank Refund UTR: <strong>{registration.refundUtr}</strong></span>
                    {registration.refundAmount && <span className="ml-2">(Refunded: ₹{registration.refundAmount})</span>}
                  </div>
                )}
              </>
            )}
          </div>

          {!isDenied && (
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-t border-rose-950">
              <span className="text-[11px] text-slate-400">
                Submit or review your UPI payout details in your personal refund desk:
              </span>
              <button
                type="button"
                id={`btn-goto-refund-desk-${registration.id}`}
                onClick={onNavigateToHistory}
                className="px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-orange-600/30 transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Go to History for Refund Section &rarr;</span>
              </button>
            </div>
          )}
        </div>
      ) : isVerified ? (
        <div className="p-3 bg-gradient-to-r from-emerald-950/60 via-slate-950 to-slate-950 rounded-xl border border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-black text-emerald-300 uppercase tracking-wider block">
                PAYMENT CONFIRMED • PASS & ROOM ACCESS ACTIVE
              </span>
              <span className="text-[11px] text-slate-300">
                Verified by: <strong className="text-white">{registration.verifiedBy || 'Admin Desk'}</strong>
                {registration.verifiedAt && ` • ${new Date(registration.verifiedAt).toLocaleDateString()}`}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenEntryCard(registration)}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer self-start sm:self-auto shadow-md"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>View Tournament Card</span>
          </button>
        </div>
      ) : isPending ? (
        <div className="p-3.5 bg-gradient-to-r from-amber-950/60 via-slate-950 to-slate-950 rounded-xl border border-amber-500/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              <Clock className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider block">
                PAYMENT CONFIRMATION PENDING (ADMIN REVIEW)
              </span>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Your slot is reserved. Tournament Card & Room Credentials will unlock as soon as the Admin approves your submitted UTR: <strong className="text-cyan-300 font-mono">{registration.utrNumber || registration.paymentTransactionId}</strong>.
              </p>
            </div>
          </div>

          <div className="px-3 py-1 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold shrink-0 self-start sm:self-center">
            AWAITING APPROVAL
          </div>
        </div>
      ) : (
        <div className="p-3 bg-slate-950 rounded-xl border border-rose-500/40 flex items-center justify-between text-xs text-rose-300">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>Registration status: {registration.paymentStatus}</span>
          </div>
        </div>
      )}

      {/* Header with Format and Match Status */}
      <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <StatusBadge status={registration.format} />
            <StatusBadge status={registration.paymentStatus} />
          </div>
          <h3 id={`reg-tourn-title-${registration.id}`} className="text-base font-bold text-white leading-snug">
            {registration.tournamentTitle}
          </h3>
        </div>

        <div className="text-right">
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">ASSIGNED MATCH</span>
          <span className="text-sm font-extrabold text-orange-400">
            {registration.matchName}
          </span>
        </div>
      </div>

      {/* Seat & Player Information Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 p-3 sm:p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs">
        <div>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
            {registration.format === 'SOLO' ? 'ALLOCATED SEAT' : 'TEAM SLOT'}
          </span>
          <span className="text-xs sm:text-sm font-extrabold text-white bg-orange-600/20 px-2 py-0.5 rounded border border-orange-500/40 inline-block mt-0.5 font-mono">
            #{registration.seatNumber} {registration.format === 'SOLO' ? '/ 48' : '/ 12'}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
            {registration.format === 'SOLO' ? 'PLAYER IGN' : 'SQUAD NAME'}
          </span>
          <span className="font-bold text-slate-200 block truncate mt-0.5">
            {registration.format === 'SOLO' ? registration.ign : registration.teamName}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
            FREE FIRE UID
          </span>
          <span className="font-mono text-cyan-300 font-bold block truncate mt-0.5">
            {registration.freeFireUid}
          </span>
        </div>

        <div>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-semibold">
            PAYMENT STATE
          </span>
          {isVerified ? (
            <span className="font-mono text-emerald-400 font-bold block truncate mt-0.5 text-[11px]">
              VERIFIED ✓
            </span>
          ) : isPending ? (
            <span className="font-mono text-amber-400 font-bold block truncate mt-0.5 text-[11px]">
              PENDING ADMIN REVIEW
            </span>
          ) : (
            <span className="font-mono text-slate-400 font-bold block truncate mt-0.5 text-[11px]">
              {registration.paymentStatus}
            </span>
          )}
        </div>
      </div>

      {/* Squad Member List if SQUAD */}
      {registration.format === 'SQUAD' && registration.members && (
        <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/60 space-y-1.5">
          <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1">
            <Users className="w-3 h-3" /> Registered Squad Roster (4 Players)
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-300">
            {registration.members.map((m, idx) => (
              <div key={idx} className="bg-slate-900 px-2 py-1.5 rounded-lg border border-slate-800">
                <span className="font-semibold text-white truncate block">{idx === 0 ? '👑 ' : ''}{m.ign}</span>
                <span className="text-[10px] text-slate-500 font-mono block truncate">{m.freeFireUid}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Realtime Custom Room Credentials Desk OR Cancellation Message */}
      {isCancelled ? (
        <div className="p-4 rounded-xl border bg-slate-950/90 border-rose-900/40 text-center space-y-2">
          <p className="text-xs text-slate-300 font-medium">
            Room credentials and qualifier entry are closed because this match was cancelled.
          </p>
          {!isDenied && (
            <button
              type="button"
              id={`btn-action-goto-refund-${registration.id}`}
              onClick={onNavigateToHistory}
              className="text-xs text-orange-400 hover:text-orange-300 font-bold underline cursor-pointer inline-flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Open History for Refund Section to enter UPI ID and claim refund &rarr;</span>
            </button>
          )}
        </div>
      ) : !isVerified ? (
        /* LOCKED UNTIL ADMIN CONFIRMS PAYMENT */
        <div className="p-4 rounded-xl border bg-gradient-to-br from-amber-950/30 via-slate-950 to-slate-950 border-amber-500/40 space-y-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                ROOM ID & PASSWORD LOCKED
              </h4>
              <p className="text-[11px] text-slate-400">
                Payment confirmation required by Admin before Room ID & Password are revealed.
              </p>
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] text-slate-300 space-y-1">
            <p>
              • Your submitted UTR: <strong className="text-cyan-300 font-mono">{registration.utrNumber || registration.paymentTransactionId}</strong>
            </p>
            <p className="text-slate-400">
              • Once the Tournament Admin reviews and confirms your transaction in the Admin Desk, your custom room ID, password, and official pass will activate automatically.
            </p>
          </div>
        </div>
      ) : isRoomReleased && room ? (
        /* UNLOCKED & RELEASED ROOM CREDENTIALS */
        <div className="p-3.5 sm:p-4 rounded-xl border bg-gradient-to-r from-emerald-950/40 via-slate-950 to-slate-950 border-emerald-500/60 shadow-lg shadow-emerald-500/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Unlock className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 flex-wrap">
                  CUSTOM ROOM CREDENTIALS
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-extrabold animate-pulse">
                    RELEASED LIVE
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  Join custom room in Free Fire MAX now
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
            {/* Room ID Box */}
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                  ROOM ID
                </span>
                <span id={`room-id-val-${registration.id}`} className="text-base font-extrabold text-white font-mono tracking-wider">
                  {room.roomId || 'PENDING'}
                </span>
              </div>
              <button
                id={`copy-room-id-${registration.id}`}
                onClick={() => handleCopy(room.roomId, 'id')}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer min-h-[38px]"
              >
                {copiedRoomId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedRoomId ? 'Copied' : 'Copy'}
              </button>
            </div>

            {/* Room Password Box */}
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-700/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                  PASSWORD
                </span>
                <span id={`room-pass-val-${registration.id}`} className="text-base font-extrabold text-amber-400 font-mono tracking-wider">
                  {room.roomPassword || 'PENDING'}
                </span>
              </div>
              <button
                id={`copy-room-pass-${registration.id}`}
                onClick={() => handleCopy(room.roomPassword, 'pass')}
                className="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer min-h-[38px]"
              >
                {copiedPassword ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedPassword ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {room.customRules && (
            <div className="text-[11px] text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
              <span className="text-amber-400 font-bold">Room Rules:</span> {room.customRules}
            </div>
          )}
        </div>
      ) : (
        /* VERIFIED BUT ROOM NOT RELEASED YET */
        <div className="p-3.5 bg-slate-950/90 rounded-xl border border-slate-800 text-center space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-slate-300 font-bold text-xs">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>ROOM CREDENTIALS AWAITING BROADCAST</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Payment verified. The tournament administrator will release Room ID & Password 10-15 minutes prior to match launch.
          </p>
        </div>
      )}

      {/* Action Buttons */}
      {!isCancelled && (
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-slate-800/80">
          {isVerified ? (
            <button
              type="button"
              onClick={() => onOpenEntryCard(registration)}
              className="px-4 py-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-emerald-500/40 transition-all cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Official Entry Pass</span>
            </button>
          ) : (
            <div className="text-[11px] text-amber-400/80 font-semibold flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Pass unlocks upon payment confirmation</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            {isVerified && (
              <button
                id={`btn-submit-pov-${registration.id}`}
                onClick={() => onOpenSubmitRecording(registration)}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
              >
                <Video className="w-3.5 h-3.5 text-orange-400" />
                <span>POV Recording</span>
              </button>
            )}

            <button
              id={`btn-report-cheat-${registration.id}`}
              onClick={() => onOpenReportPlayer(registration)}
              className="px-3.5 py-2.5 bg-red-950/60 hover:bg-red-900/60 text-red-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-red-800/50 transition-all cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
              <span>Report</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export const MyMatchView: React.FC<MyMatchViewProps> = ({
  onNavigateToTournaments,
  onOpenPlayerAuth,
  onNavigateToHistory,
}) => {
  const { currentUser } = useAuth();
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [tournaments, setTournaments] = useState<Record<string, Tournament>>({});
  const [loading, setLoading] = useState(true);

  const [recordingModalReg, setRecordingModalReg] = useState<Registration | null>(null);
  const [reportModalReg, setReportModalReg] = useState<Registration | null>(null);
  const [entryCardReg, setEntryCardReg] = useState<Registration | null>(null);

  useEffect(() => {
    const unsubTourn = listenTournaments((tList) => {
      const map: Record<string, Tournament> = {};
      tList.forEach((t) => {
        map[t.id] = t;
      });
      setTournaments(map);
    });
    return () => unsubTourn();
  }, []);

  useEffect(() => {
    if (!currentUser) {
      setRegistrations([]);
      setLoading(false);
      return;
    }

    const unsub = listenUserRegistrations(currentUser.uid, (list) => {
      setRegistrations(list);
      setLoading(false);
    });

    return () => unsub();
  }, [currentUser]);

  if (!currentUser) {
    return (
      <EmptyState
        id="signin-required-my-match"
        title="Sign In to Access My Match Desk"
        description="View your active tournament registrations, match assignments, seat numbers, and live custom room credentials."
        actionText="Sign In / Register"
        onAction={onOpenPlayerAuth}
      />
    );
  }

  return (
    <div id="my-match-view" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Gamepad2 className="w-6 h-6 text-orange-400" />
            My Active Tournament Matches
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Your real-time assigned tournament qualifiers, seats & custom room credentials
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
            Active Registrations: <span className="font-bold text-orange-400">{registrations.length}</span>
          </span>
          <button
            id="register-another-tourn-btn"
            onClick={onNavigateToTournaments}
            className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all"
          >
            Explore More <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Registrations List */}
      {registrations.length === 0 ? (
        <EmptyState
          id="no-registrations-empty"
          title="No active tournament registrations."
          description="You have not registered for any upcoming Free Fire MAX tournaments yet. Join an open tournament to receive your qualifier match and seat assignment."
          actionText="Browse Open Tournaments"
          onAction={onNavigateToTournaments}
        />
      ) : (
        <div className="space-y-6">
          {registrations.map((reg) => (
            <MatchCard
              key={reg.id}
              registration={reg}
              tournament={tournaments[reg.tournamentId]}
              onNavigateToHistory={onNavigateToHistory}
              onOpenSubmitRecording={(r) => setRecordingModalReg(r)}
              onOpenReportPlayer={(r) => setReportModalReg(r)}
              onOpenEntryCard={(r) => setEntryCardReg(r)}
            />
          ))}
        </div>
      )}

      {/* Official Tournament Entry Card Modal (Only rendered when verified) */}
      {entryCardReg && (entryCardReg.paymentStatus === 'VERIFIED' || entryCardReg.paymentStatus === 'APPROVED') && (
        <TournamentEntryCardModal
          isOpen={Boolean(entryCardReg)}
          onClose={() => setEntryCardReg(null)}
          registration={entryCardReg}
        />
      )}

      {/* Submit Recording Modal */}
      {recordingModalReg && (
        <SubmitRecordingModal
          isOpen={Boolean(recordingModalReg)}
          onClose={() => setRecordingModalReg(null)}
          tournamentId={recordingModalReg.tournamentId}
          tournamentTitle={recordingModalReg.tournamentTitle}
          matchId={recordingModalReg.matchId}
          matchName={recordingModalReg.matchName}
          onSuccess={() => setRecordingModalReg(null)}
        />
      )}

      {/* Report Cheater Modal */}
      {reportModalReg && (
        <ReportPlayerModal
          isOpen={Boolean(reportModalReg)}
          onClose={() => setReportModalReg(null)}
          tournamentId={reportModalReg.tournamentId}
          tournamentTitle={reportModalReg.tournamentTitle}
          matchId={reportModalReg.matchId}
          matchName={reportModalReg.matchName}
          onSuccess={() => setReportModalReg(null)}
        />
      )}
    </div>
  );
};
