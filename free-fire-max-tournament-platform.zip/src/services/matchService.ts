import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { MatchStatus, TournamentMatch } from '../types';

export function listenTournamentMatches(
  tournamentId: string, 
  callback: (matches: TournamentMatch[]) => void
): () => void {
  const q = query(
    collection(db, 'matches'), 
    where('tournamentId', '==', tournamentId),
    orderBy('matchNumber', 'asc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: TournamentMatch[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as TournamentMatch);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to matches:', err);
  });
}

export async function getTournamentMatches(tournamentId: string): Promise<TournamentMatch[]> {
  const q = query(
    collection(db, 'matches'), 
    where('tournamentId', '==', tournamentId),
    orderBy('matchNumber', 'asc')
  );
  const snap = await getDocs(q);
  const list: TournamentMatch[] = [];
  snap.forEach((doc) => list.push(doc.data() as TournamentMatch));
  return list;
}

export async function getMatchById(matchId: string): Promise<TournamentMatch | null> {
  const docRef = doc(db, 'matches', matchId);
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return snap.data() as TournamentMatch;
  }
  return null;
}

export async function updateMatchStatus(matchId: string, status: MatchStatus): Promise<void> {
  const docRef = doc(db, 'matches', matchId);
  await updateDoc(docRef, { status });
}

export async function updateMatchDetails(
  matchId: string, 
  data: { scheduledTime?: string; mapName?: string; status?: MatchStatus }
): Promise<void> {
  const docRef = doc(db, 'matches', matchId);
  const cleanData: Record<string, any> = {};
  if (data.scheduledTime !== undefined) cleanData.scheduledTime = data.scheduledTime;
  if (data.mapName !== undefined) cleanData.mapName = data.mapName;
  if (data.status !== undefined) cleanData.status = data.status;
  if (Object.keys(cleanData).length > 0) {
    await updateDoc(docRef, cleanData);
  }
}
