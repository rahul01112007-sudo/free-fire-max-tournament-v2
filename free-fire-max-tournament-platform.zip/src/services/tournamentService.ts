import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { 
  Tournament, 
  TournamentFormat, 
  TournamentMatch, 
  TournamentStatus, 
  TournamentEntryType,
  PrizeDistribution,
  PrizePosition,
  PrizeType,
  PrizeSnapshot,
  RewardCurrency,
  DEFAULT_SOLO_PRIZES,
  DEFAULT_SQUAD_PRIZES,
  getTournamentPrizeDistribution,
  getTournamentPrizePositions,
  calculateDeterministicPrizeDistribution,
  normalizeEntryType,
  normalizeRewardType,
  getRewardCurrency,
  isDiamondPrizeType
} from '../types';

export interface CreateTournamentParams {
  title: string;
  game?: string; // 'FREE FIRE MAX'
  format: TournamentFormat;
  entryType?: TournamentEntryType; // 'FREE_ADS' | 'PAID_IN_GAME' | 'FREE_IN_GAME'
  status?: TournamentStatus;
  maxParticipants: number; // Total players (Solo) or total teams (Squad)
  participantsPerMatch?: number; // e.g. 48 for Solo, 12 for Squad
  qualifiersCount?: number; // dynamically calculated / admin set
  advancingPerMatch?: number; // e.g. 3
  entryFee?: number; // ₹ Entry fee for PAID_IN_GAME, 0 for FREE
  adsRequired?: number; // Default 5
  prizeType?: PrizeType;
  rewardType?: PrizeType;
  rewardCurrency?: RewardCurrency;
  rewardAmount?: number;
  totalPrizeValue?: number;
  prizePool?: number; // Total prize pool in ₹ or Diamonds
  prizePositionCount?: number;
  prizePositions?: PrizePosition[]; // Custom positions (1st, 2nd, 3rd, ...)
  prizeDistribution?: PrizeDistribution;
  firstPrize?: number;
  secondPrize?: number;
  thirdPrize?: number;
  fourthPrize?: number;
  fifthPrize?: number;
  startDate: string;
  startTime: string;
  bannerUrl?: string;
  description: string;
  rules: string;
  createdBy: string;
}

export interface UpdateTournamentParams {
  title: string;
  format?: TournamentFormat;
  entryType?: TournamentEntryType;
  maxParticipants: number;
  participantsPerMatch?: number;
  qualifiersCount?: number;
  advancingPerMatch?: number;
  adsRequired?: number;
  prizeType?: PrizeType;
  rewardType?: PrizeType;
  rewardCurrency?: RewardCurrency;
  rewardAmount?: number;
  totalPrizeValue?: number;
  prizePool?: number;
  prizePositionCount?: number;
  prizePositions?: PrizePosition[];
  prizeDistribution?: PrizeDistribution;
  startDate: string;
  startTime: string;
  bannerUrl?: string;
  description: string;
  rules: string;
  status?: TournamentStatus;
  entryFee?: number;
}

export async function createTournamentWithMatches(params: CreateTournamentParams): Promise<Tournament> {
  const tournamentId = `tourn_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const batch = writeBatch(db);

  const totalCapacity = Number(params.maxParticipants) || (params.format === 'SOLO' ? 96 : 24);
  const participantsPerMatch = Number(params.participantsPerMatch) || (params.format === 'SOLO' ? 48 : 12);
  
  // Calculate qualifiers count dynamically if not provided or invalid
  const calculatedMinQualifiers = Math.max(1, Math.ceil(totalCapacity / participantsPerMatch));
  const qualifiersCount = Number(params.qualifiersCount) > 0 ? Number(params.qualifiersCount) : calculatedMinQualifiers;
  const advancingPerMatch = Number(params.advancingPerMatch) > 0 ? Number(params.advancingPerMatch) : 3;

  // Prize & Reward configuration
  const prizeType: PrizeType = normalizeRewardType(params.rewardType || params.prizeType);
  const rewardCurrency: RewardCurrency = params.rewardCurrency || getRewardCurrency(prizeType);
  let rawPositions: PrizePosition[] = params.prizePositions || [];

  if (!rawPositions || rawPositions.length === 0) {
    const totalVal = Number(params.totalPrizeValue) || Number(params.prizePool) || (isDiamondPrizeType(prizeType) ? 1890 : 5000);
    const posCount = Number(params.prizePositionCount) || 3;
    rawPositions = calculateDeterministicPrizeDistribution(totalVal, posCount, prizeType);
  }

  // Filter out any zero or invalid positions - ONLY active positive positions allowed
  const cleanPositions: PrizePosition[] = rawPositions
    .filter((p) => Number(p.amount) > 0)
    .map((p, idx) => {
      const posObj: PrizePosition = {
        rank: p.rank || p.position || idx + 1,
        position: p.position || p.rank || idx + 1,
        label: p.label || `${idx + 1}th Place`,
        amount: Number(p.amount) || 0,
        prizeType: p.prizeType || prizeType,
      };
      if (p.diamondPackageId) posObj.diamondPackageId = p.diamondPackageId;
      if (p.diamondPackageLabel) posObj.diamondPackageLabel = p.diamondPackageLabel;
      if (p.customPrizeDetails) posObj.customPrizeDetails = p.customPrizeDetails;
      if (p.giftCardType) posObj.giftCardType = p.giftCardType;
      return posObj;
    })
    .sort((a, b) => a.position - b.position);

  const totalPrizeValue = Number(params.totalPrizeValue) || 
    Number(params.prizePool) || 
    cleanPositions.reduce((acc, p) => acc + p.amount, 0);

  const p1 = cleanPositions.find(p => p.position === 1)?.amount || 0;
  const p2 = cleanPositions.find(p => p.position === 2)?.amount || 0;
  const p3 = cleanPositions.find(p => p.position === 3)?.amount || 0;
  const p4 = cleanPositions.find(p => p.position === 4)?.amount || 0;
  const p5 = cleanPositions.find(p => p.position === 5)?.amount || 0;

  const prizeDistribution: PrizeDistribution = {
    first: p1,
    second: p2,
    third: p3,
    fourth: p4,
    fifth: p5,
  };

  const finalSlots = qualifiersCount * advancingPerMatch;
  const entryType: TournamentEntryType = normalizeEntryType(params.entryType, params.entryFee);
  const entryFee = entryType === 'PAID_IN_GAME' ? (Number(params.entryFee) || 0) : 0;
  const adsRequired = entryType === 'FREE_ADS' ? (params.adsRequired !== undefined ? params.adsRequired : 5) : 0;

  const tournament: Tournament = {
    id: tournamentId,
    title: params.title || 'Free Fire Tournament',
    game: params.game || 'FREE FIRE MAX',
    format: params.format || 'SOLO',
    entryType,
    maxParticipants: totalCapacity,
    participantsPerMatch,
    qualifiersCount,
    advancingPerMatch,
    entryFee,
    adsRequired,
    prizeType,
    rewardType: prizeType,
    rewardCurrency,
    rewardAmount: totalPrizeValue,
    totalPrizeValue,
    prizePool: totalPrizeValue,
    prizePositionCount: cleanPositions.length,
    prizePositions: cleanPositions,
    prizeDistribution,
    firstPrize: p1,
    secondPrize: p2,
    thirdPrize: p3,
    fourthPrize: p4,
    fifthPrize: p5,
    startDate: params.startDate || new Date().toISOString().split('T')[0],
    startTime: params.startTime || '18:00 IST',
    bannerUrl: params.bannerUrl || '',
    status: params.status || 'REGISTRATION_OPEN',
    description: params.description || '',
    rules: params.rules || '',
    playersPerQualifier: participantsPerMatch,
    finalSlots,
    registeredCount: 0,
    createdAt: new Date().toISOString(),
    createdBy: params.createdBy || 'Admin',
  };

  const tournDocRef = doc(db, 'tournaments', tournamentId);
  batch.set(tournDocRef, sanitizeForFirestore(tournament));

  // Generate Qualifier Matches EXACTLY based on admin configuration
  for (let i = 1; i <= qualifiersCount; i++) {
    const matchId = `${tournamentId}_match_${i}`;
    const matchRef = doc(db, 'matches', matchId);
    
    const matchData: TournamentMatch = {
      id: matchId,
      tournamentId: tournamentId,
      matchNumber: i,
      name: `Qualifier Match #${i}`,
      stage: 'QUALIFIER',
      capacity: participantsPerMatch,
      currentCount: 0,
      status: i === 1 ? 'ACTIVE' : 'WAITING',
      scheduledTime: `${tournament.startDate} ${tournament.startTime}`,
      roomStatus: 'LOCKED',
      mapName: 'Bermuda',
      createdAt: new Date().toISOString(),
    };
    batch.set(matchRef, sanitizeForFirestore(matchData));

    // Initial Room Credentials Doc
    const roomRef = doc(db, 'rooms', matchId);
    batch.set(roomRef, sanitizeForFirestore({
      id: matchId,
      tournamentId,
      matchId,
      matchName: `Qualifier Match #${i}`,
      roomId: '',
      roomPassword: '',
      status: 'LOCKED',
      updatedAt: new Date().toISOString(),
    }));
  }

  // Generate Grand Final Match
  const finalMatchNumber = qualifiersCount + 1;
  const finalMatchId = `${tournamentId}_match_${finalMatchNumber}`;
  const finalMatchRef = doc(db, 'matches', finalMatchId);

  const finalMatchData: TournamentMatch = {
    id: finalMatchId,
    tournamentId: tournamentId,
    matchNumber: finalMatchNumber,
    name: `Grand Final (Top ${advancingPerMatch} from Each Qualifier Advance)`,
    stage: 'FINAL',
    capacity: Math.min(participantsPerMatch, finalSlots),
    currentCount: 0,
    status: 'LOCKED', // Must remain locked until qualifiers complete
    scheduledTime: `${tournament.startDate} Final Stage`,
    roomStatus: 'LOCKED',
    mapName: 'Purgatory / Bermuda',
    createdAt: new Date().toISOString(),
  };
  batch.set(finalMatchRef, sanitizeForFirestore(finalMatchData));

  const finalRoomRef = doc(db, 'rooms', finalMatchId);
  batch.set(finalRoomRef, sanitizeForFirestore({
    id: finalMatchId,
    tournamentId,
    matchId: finalMatchId,
    matchName: 'Grand Final',
    roomId: '',
    roomPassword: '',
    status: 'LOCKED',
    updatedAt: new Date().toISOString(),
  }));

  await batch.commit();
  return tournament;
}

export function listenTournaments(callback: (tournaments: Tournament[]) => void): () => void {
  const q = query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const list: Tournament[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Tournament);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to tournaments:', err);
  });
}

export async function getTournaments(): Promise<Tournament[]> {
  const q = query(collection(db, 'tournaments'), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  const list: Tournament[] = [];
  snap.forEach((doc) => list.push(doc.data() as Tournament));
  return list;
}

export async function getTournamentById(id: string): Promise<Tournament | null> {
  const docRef = doc(db, 'tournaments', id);
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return snap.data() as Tournament;
  }
  return null;
}

export async function updateTournamentStatus(id: string, status: TournamentStatus): Promise<void> {
  const docRef = doc(db, 'tournaments', id);
  const updates: Record<string, any> = { 
    status,
    updatedAt: new Date().toISOString(),
  };

  // If tournament is started or completed, create a prize snapshot if not already present
  if (status === 'ONGOING' || status === 'COMPLETED') {
    try {
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const tourn = snap.data() as Tournament;
        if (!tourn.prizeSnapshot) {
          const cleanPositions = (tourn.prizePositions || [])
            .filter((p) => Number(p.amount) > 0)
            .map((p, idx) => ({
              rank: p.rank || p.position || idx + 1,
              position: p.position || p.rank || idx + 1,
              label: p.label || `${idx + 1}th Place`,
              amount: Number(p.amount) || 0,
              prizeType: p.prizeType || tourn.prizeType || 'AMAZON GIFT CARD',
            }));

          const totalVal = Number(tourn.totalPrizeValue) || Number(tourn.prizePool) || cleanPositions.reduce((acc, p) => acc + p.amount, 0);

          updates.prizeSnapshot = {
            totalPrizeValue: totalVal,
            prizeType: tourn.prizeType || 'AMAZON GIFT CARD',
            prizePositionCount: cleanPositions.length,
            prizePositions: cleanPositions,
            finalizedAt: new Date().toISOString(),
          };
        }
      }
    } catch (e) {
      console.warn('Prize snapshot check notice:', e);
    }
  }

  await updateDoc(docRef, sanitizeForFirestore(updates));
}

export async function updateTournamentDetails(id: string, params: UpdateTournamentParams): Promise<void> {
  const docRef = doc(db, 'tournaments', id);

  const prizeType: PrizeType = normalizeRewardType(params.rewardType || params.prizeType);
  const rewardCurrency: RewardCurrency = params.rewardCurrency || getRewardCurrency(prizeType);
  let rawPositions: PrizePosition[] = params.prizePositions || [];

  if (!rawPositions || rawPositions.length === 0) {
    const totalVal = Number(params.totalPrizeValue) || Number(params.prizePool) || (isDiamondPrizeType(prizeType) ? 1890 : 5000);
    const posCount = Number(params.prizePositionCount) || 3;
    rawPositions = calculateDeterministicPrizeDistribution(totalVal, posCount, prizeType);
  }

  // Filter to strictly positive active positions
  const cleanPositions: PrizePosition[] = rawPositions
    .filter((p) => Number(p.amount) > 0)
    .map((p, idx) => {
      const posObj: PrizePosition = {
        rank: p.rank || p.position || idx + 1,
        position: p.position || p.rank || idx + 1,
        label: p.label || `${idx + 1}th Place`,
        amount: Number(p.amount) || 0,
        prizeType: p.prizeType || prizeType,
      };
      if (p.diamondPackageId) posObj.diamondPackageId = p.diamondPackageId;
      if (p.diamondPackageLabel) posObj.diamondPackageLabel = p.diamondPackageLabel;
      if (p.customPrizeDetails) posObj.customPrizeDetails = p.customPrizeDetails;
      if (p.giftCardType) posObj.giftCardType = p.giftCardType;
      return posObj;
    })
    .sort((a, b) => a.position - b.position);

  const totalPrizeValue = Number(params.totalPrizeValue) || 
    Number(params.prizePool) || 
    cleanPositions.reduce((acc, p) => acc + p.amount, 0);

  const p1 = cleanPositions.find(p => p.position === 1)?.amount || 0;
  const p2 = cleanPositions.find(p => p.position === 2)?.amount || 0;
  const p3 = cleanPositions.find(p => p.position === 3)?.amount || 0;
  const p4 = cleanPositions.find(p => p.position === 4)?.amount || 0;
  const p5 = cleanPositions.find(p => p.position === 5)?.amount || 0;

  const prizeDistribution: PrizeDistribution = {
    first: p1,
    second: p2,
    third: p3,
    fourth: p4,
    fifth: p5,
  };

  const normEntryType = normalizeEntryType(params.entryType, params.entryFee);
  const actualEntryFee = normEntryType === 'PAID_IN_GAME' ? (Number(params.entryFee) || 0) : 0;
  const actualAdsRequired = normEntryType === 'FREE_ADS' ? (params.adsRequired !== undefined ? params.adsRequired : 5) : 0;

  const updatePayload: Record<string, any> = {
    title: params.title || '',
    maxParticipants: Number(params.maxParticipants) || 0,
    participantsPerMatch: Number(params.participantsPerMatch) || 48,
    qualifiersCount: Number(params.qualifiersCount) || 2,
    advancingPerMatch: Number(params.advancingPerMatch) || 3,
    entryType: normEntryType,
    entryFee: actualEntryFee,
    adsRequired: actualAdsRequired,
    prizeType,
    rewardType: prizeType,
    rewardCurrency,
    rewardAmount: totalPrizeValue,
    totalPrizeValue,
    prizePool: totalPrizeValue,
    prizePositionCount: cleanPositions.length,
    prizePositions: cleanPositions,
    prizeDistribution,
    firstPrize: p1,
    secondPrize: p2,
    thirdPrize: p3,
    fourthPrize: p4,
    fifthPrize: p5,
    startDate: params.startDate || '',
    startTime: params.startTime || '',
    bannerUrl: params.bannerUrl || '',
    description: params.description || '',
    rules: params.rules || '',
    updatedAt: new Date().toISOString(),
  };

  if (params.format) {
    updatePayload.format = params.format;
  }

  if (params.status) {
    updatePayload.status = params.status;
  }

  await updateDoc(docRef, sanitizeForFirestore(updatePayload));
}

export async function deleteTournament(id: string): Promise<void> {
  if (!id) throw new Error('Tournament ID is required for deletion');

  const docRefsToDelete = new Map<string, any>();

  // 1. Tournament document
  const tournRef = doc(db, 'tournaments', id);
  docRefsToDelete.set(tournRef.path, tournRef);

  const safeCollect = async (fetcher: () => Promise<void>) => {
    try {
      await fetcher();
    } catch (err) {
      console.warn('Subcollection fetch notice during tournament deletion:', err);
    }
  };

  // 2. All matches belonging to this tournament
  await safeCollect(async () => {
    const matchesQuery = query(collection(db, 'matches'), where('tournamentId', '==', id));
    const matchesSnap = await getDocs(matchesQuery);
    matchesSnap.forEach((mDoc) => {
      docRefsToDelete.set(mDoc.ref.path, mDoc.ref);
      const roomRef = doc(db, 'rooms', mDoc.id);
      docRefsToDelete.set(roomRef.path, roomRef);
    });
  });

  // 3. Any additional room documents created with tournamentId
  await safeCollect(async () => {
    const roomsQuery = query(collection(db, 'rooms'), where('tournamentId', '==', id));
    const roomsSnap = await getDocs(roomsQuery);
    roomsSnap.forEach((rDoc) => {
      docRefsToDelete.set(rDoc.ref.path, rDoc.ref);
    });
  });

  // 4. All registrations for this tournament
  await safeCollect(async () => {
    const regsQuery = query(collection(db, 'registrations'), where('tournamentId', '==', id));
    const regsSnap = await getDocs(regsQuery);
    regsSnap.forEach((regDoc) => {
      docRefsToDelete.set(regDoc.ref.path, regDoc.ref);
    });
  });

  // 5. All results for this tournament
  await safeCollect(async () => {
    const resultsQuery = query(collection(db, 'results'), where('tournamentId', '==', id));
    const resultsSnap = await getDocs(resultsQuery);
    resultsSnap.forEach((resDoc) => {
      docRefsToDelete.set(resDoc.ref.path, resDoc.ref);
    });
  });

  // 6. Any anti-cheat reports for this tournament
  await safeCollect(async () => {
    const acQuery = query(collection(db, 'antiCheatReports'), where('tournamentId', '==', id));
    const acSnap = await getDocs(acQuery);
    acSnap.forEach((acDoc) => {
      docRefsToDelete.set(acDoc.ref.path, acDoc.ref);
    });
  });

  // 7. Any screen recordings submitted for this tournament
  await safeCollect(async () => {
    const recQuery = query(collection(db, 'recordings'), where('tournamentId', '==', id));
    const recSnap = await getDocs(recQuery);
    recSnap.forEach((recDoc) => {
      docRefsToDelete.set(recDoc.ref.path, recDoc.ref);
    });
  });

  // 8. Any adEntryProgress records for this tournament
  await safeCollect(async () => {
    const adQuery = query(collection(db, 'adEntryProgress'), where('tournamentId', '==', id));
    const adSnap = await getDocs(adQuery);
    adSnap.forEach((adDoc) => {
      docRefsToDelete.set(adDoc.ref.path, adDoc.ref);
    });
  });

  // 9. Any prizeDeliveries records for this tournament
  await safeCollect(async () => {
    const pdelQuery = query(collection(db, 'prizeDeliveries'), where('tournamentId', '==', id));
    const pdelSnap = await getDocs(pdelQuery);
    pdelSnap.forEach((pdelDoc) => {
      docRefsToDelete.set(pdelDoc.ref.path, pdelDoc.ref);
    });
  });

  // Execute chunked atomic deletions
  const allRefs = Array.from(docRefsToDelete.values());
  const BATCH_SIZE = 400;

  for (let i = 0; i < allRefs.length; i += BATCH_SIZE) {
    const chunk = allRefs.slice(i, i + BATCH_SIZE);
    const batch = writeBatch(db);
    for (const ref of chunk) {
      batch.delete(ref);
    }
    await batch.commit();
  }
}
