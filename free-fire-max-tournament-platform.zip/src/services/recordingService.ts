import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { MatchRecording, POVType, RecordingStatus } from '../types';

export async function submitMatchRecording(params: {
  playerId: string;
  playerName: string;
  freeFireUid: string;
  ign: string;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName?: string;
  videoUrl: string;
  povType: POVType;
  notes?: string;
}): Promise<MatchRecording> {
  const recordingId = `rec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  const recording: MatchRecording = {
    id: recordingId,
    playerId: params.playerId,
    playerName: params.playerName,
    freeFireUid: params.freeFireUid,
    ign: params.ign,
    tournamentId: params.tournamentId,
    tournamentTitle: params.tournamentTitle || '',
    matchId: params.matchId,
    matchName: params.matchName || '',
    videoUrl: params.videoUrl.trim(),
    povType: params.povType,
    notes: params.notes || '',
    status: 'PENDING',
    submittedAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'recordings', recordingId), recording);
  return recording;
}

export function listenUserRecordings(
  playerId: string, 
  callback: (recordings: MatchRecording[]) => void
): () => void {
  const q = query(
    collection(db, 'recordings'),
    where('playerId', '==', playerId),
    orderBy('submittedAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: MatchRecording[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as MatchRecording);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to player recordings:', err);
  });
}

export function listenAllRecordings(callback: (recordings: MatchRecording[]) => void): () => void {
  const q = query(collection(db, 'recordings'), orderBy('submittedAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const list: MatchRecording[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as MatchRecording);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to all recordings:', err);
  });
}

export async function updateRecordingReview(
  recordingId: string, 
  status: RecordingStatus, 
  adminFeedback?: string,
  reviewedBy?: string
): Promise<void> {
  const docRef = doc(db, 'recordings', recordingId);
  await updateDoc(docRef, {
    status,
    reviewedAt: new Date().toISOString(),
    adminFeedback: adminFeedback || '',
    reviewedBy: reviewedBy || 'Admin'
  });
}

export const reviewRecording = updateRecordingReview;
