import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  arrayUnion 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { SupportTicket, SupportMessage, SupportCategory, SupportTicketStatus } from '../types';

export interface CreateTicketParams {
  userId: string;
  playerName: string;
  playerEmail?: string;
  freeFireUid: string;
  category: SupportCategory;
  subject: string;
  message: string;
  tournamentId?: string;
  tournamentTitle?: string;
  matchId?: string;
  matchName?: string;
}

export async function createSupportTicket(params: CreateTicketParams): Promise<SupportTicket> {
  const ticketRef = doc(collection(db, 'support_tickets'));
  const now = new Date().toISOString();
  const ticketCode = `TICKET-${Math.floor(1000 + Math.random() * 9000)}`;

  const initialMessage: SupportMessage = {
    id: `msg_${Date.now()}`,
    senderUid: params.userId,
    senderName: params.playerName,
    senderRole: 'player',
    message: params.message.trim(),
    createdAt: now,
  };

  const newTicket: SupportTicket = {
    id: ticketRef.id,
    ticketId: ticketCode,
    userId: params.userId,
    playerName: params.playerName.trim(),
    playerEmail: params.playerEmail || '',
    freeFireUid: params.freeFireUid.trim(),
    category: params.category,
    subject: params.subject.trim(),
    message: params.message.trim(),
    tournamentId: params.tournamentId || '',
    tournamentTitle: params.tournamentTitle || '',
    matchId: params.matchId || '',
    matchName: params.matchName || '',
    status: 'OPEN',
    messages: [initialMessage],
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(ticketRef, newTicket);
  return newTicket;
}

export function listenPlayerTickets(userId: string, callback: (tickets: SupportTicket[]) => void): () => void {
  const q = query(
    collection(db, 'support_tickets'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(
    q,
    (snap) => {
      const list: SupportTicket[] = [];
      snap.forEach((d) => list.push(d.data() as SupportTicket));
      callback(list);
    },
    (err) => {
      console.warn('listenPlayerTickets snapshot error:', err);
      callback([]);
    }
  );
}

export function listenAllSupportTickets(callback: (tickets: SupportTicket[]) => void): () => void {
  const q = query(
    collection(db, 'support_tickets'),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(
    q,
    (snap) => {
      const list: SupportTicket[] = [];
      snap.forEach((d) => list.push(d.data() as SupportTicket));
      callback(list);
    },
    (err) => {
      console.warn('listenAllSupportTickets snapshot error:', err);
      callback([]);
    }
  );
}

export async function addTicketMessage(
  ticketId: string, 
  senderUid: string, 
  senderName: string, 
  senderRole: 'player' | 'admin', 
  messageText: string,
  newStatus?: SupportTicketStatus
): Promise<void> {
  const ticketRef = doc(db, 'support_tickets', ticketId);
  const now = new Date().toISOString();

  const newMessage: SupportMessage = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    senderUid,
    senderName,
    senderRole,
    message: messageText.trim(),
    createdAt: now,
  };

  const updatePayload: any = {
    messages: arrayUnion(newMessage),
    updatedAt: now,
  };

  if (senderRole === 'admin') {
    updatePayload.adminResponse = messageText.trim();
    updatePayload.assignedAdmin = senderName;
    if (newStatus) {
      updatePayload.status = newStatus;
    } else {
      updatePayload.status = 'IN REVIEW';
    }
  } else {
    // If player replies to a resolved/closed ticket, reopen it
    if (newStatus) {
      updatePayload.status = newStatus;
    }
  }

  await updateDoc(ticketRef, updatePayload);
}

export async function updateTicketStatus(
  ticketId: string, 
  status: SupportTicketStatus, 
  adminNotes?: string,
  assignedAdmin?: string
): Promise<void> {
  const ticketRef = doc(db, 'support_tickets', ticketId);
  const now = new Date().toISOString();

  const updatePayload: any = {
    status,
    updatedAt: now,
  };

  if (adminNotes !== undefined) {
    updatePayload.adminNotes = adminNotes.trim();
  }

  if (assignedAdmin) {
    updatePayload.assignedAdmin = assignedAdmin;
  }

  if (status === 'RESOLVED' || status === 'CLOSED') {
    updatePayload.resolvedAt = now;
  }

  await updateDoc(ticketRef, updatePayload);
}
