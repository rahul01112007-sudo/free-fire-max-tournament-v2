import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc,
  runTransaction, 
  collection, 
  query, 
  where, 
  getDocs,
  orderBy,
  onSnapshot 
} from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { Registration, Tournament } from '../types';

export interface AdminPaymentRestrictions {
  requireSecurityPin: boolean;
  securityPin: string; // e.g. "7788"
  strictDuplicateUtrBlock: boolean;
  requireBankStatementCheckbox: boolean;
  minUtrLength: number; // e.g. 8
  requireAdminNotes: boolean;
  autoBlockIfMatchFull: boolean;
}

export const DEFAULT_PAYMENT_RESTRICTIONS: AdminPaymentRestrictions = {
  requireSecurityPin: true,
  securityPin: '7788',
  strictDuplicateUtrBlock: true,
  requireBankStatementCheckbox: true,
  minUtrLength: 8,
  requireAdminNotes: true,
  autoBlockIfMatchFull: true,
};

const RESTRICTIONS_STORAGE_KEY = 'ff_admin_payment_restrictions_v1';

export function getPaymentRestrictions(): AdminPaymentRestrictions {
  try {
    const raw = localStorage.getItem(RESTRICTIONS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_PAYMENT_RESTRICTIONS, ...parsed };
    }
  } catch (e) {
    console.error('Failed to parse payment restrictions from localStorage:', e);
  }
  return DEFAULT_PAYMENT_RESTRICTIONS;
}

export function savePaymentRestrictions(restrictions: AdminPaymentRestrictions): void {
  try {
    localStorage.setItem(RESTRICTIONS_STORAGE_KEY, JSON.stringify(restrictions));
  } catch (e) {
    console.error('Failed to save payment restrictions to localStorage:', e);
  }
}

export interface PaymentIntent {
  orderId: string;
  tournamentId: string;
  userId: string;
  amount: number;
  currency: string;
  createdAt: string;
  status: 'CREATED' | 'SUCCESS' | 'FAILED';
  transactionId?: string;
  verifiedAt?: string;
}

export interface PaymentVerificationResult {
  success: boolean;
  transactionId: string;
  amount: number;
  paymentMethod: 'UPI' | 'ONLINE' | 'CARD' | 'WALLET' | 'CASH';
  verifiedAt?: string;
  error?: string;
  isManualPending?: boolean;
}

export interface ManualPaymentParams {
  tournamentId: string;
  tournamentTitle: string;
  playerId?: string;
  playerName: string;
  ign: string;
  freeFireUid: string;
  phone: string;
  amount: number;
  paymentMethod: 'UPI' | 'ONLINE' | 'CARD' | 'WALLET' | 'CASH';
  utrNumber: string;
  adminName: string;
  adminNotes?: string;
  format?: 'SOLO' | 'SQUAD';
  teamName?: string;
}

/**
 * Creates a unique payment order for a tournament entry fee.
 */
export async function createPaymentOrder(
  tournamentId: string,
  userId: string,
  entryFee: number
): Promise<PaymentIntent> {
  const effectiveUserId = auth.currentUser?.uid || userId;
  const orderId = `ORDER_${Date.now()}_${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
  const now = new Date().toISOString();

  const intent: PaymentIntent = {
    orderId,
    tournamentId,
    userId: effectiveUserId,
    amount: entryFee,
    currency: 'INR',
    createdAt: now,
    status: 'CREATED',
  };

  const orderRef = doc(db, 'payment_orders', orderId);
  await setDoc(orderRef, sanitizeForFirestore(intent));
  return intent;
}

/**
 * Verifies the tournament entry payment idempotently.
 */
export async function verifyTournamentPayment(
  orderId: string,
  tournamentId: string,
  userId: string,
  expectedAmount: number,
  paymentMethod: 'UPI' | 'ONLINE' | 'CARD' | 'WALLET' | 'CASH' = 'UPI',
  userProvidedUtr?: string
): Promise<PaymentVerificationResult> {
  if (expectedAmount <= 0) {
    throw new Error('Invalid tournament entry fee amount.');
  }

  const effectiveUserId = auth.currentUser?.uid || userId;
  const txnId = userProvidedUtr?.trim() 
    ? `TXN_${userProvidedUtr.trim()}` 
    : `TXN_${Date.now()}_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

  // Execute atomic transaction to prevent duplicate payment / replay attacks
  const result = await runTransaction(db, async (transaction) => {
    const processedTxnRef = doc(db, 'processed_payments', txnId);
    const processedSnap = await transaction.get(processedTxnRef);

    if (processedSnap.exists()) {
      throw new Error(`Duplicate transaction detected. Transaction reference ${txnId} has already been processed.`);
    }

    const orderRef = doc(db, 'payment_orders', orderId);
    const orderSnap = await transaction.get(orderRef);

    if (orderSnap.exists()) {
      const orderData = orderSnap.data() as PaymentIntent;
      if (orderData.amount !== expectedAmount) {
        throw new Error(`Payment amount mismatch: Expected ₹${expectedAmount}, got ₹${orderData.amount}`);
      }
      transaction.update(orderRef, sanitizeForFirestore({
        status: 'SUCCESS',
        transactionId: txnId,
        verifiedAt: new Date().toISOString(),
      }));
    }

    const now = new Date().toISOString();
    const paymentRecord = {
      id: txnId,
      orderId,
      tournamentId,
      userId: effectiveUserId,
      amount: expectedAmount,
      currency: 'INR',
      paymentMethod,
      verified: true,
      verifiedAt: now,
      createdAt: now,
    };

    transaction.set(processedTxnRef, sanitizeForFirestore(paymentRecord));

    return {
      success: true,
      transactionId: txnId,
      amount: expectedAmount,
      paymentMethod,
      verifiedAt: now,
    };
  });

  return result;
}

/**
 * Player Action: Submits manual payment details (UTR / Transaction reference) for Admin Confirmation.
 */
export async function submitManualTournamentPayment(
  orderId: string,
  tournamentId: string,
  userId: string,
  expectedAmount: number,
  utrNumber: string,
  paymentMethod: 'UPI' | 'ONLINE' | 'CARD' | 'WALLET' | 'CASH' = 'UPI'
): Promise<PaymentVerificationResult> {
  if (!utrNumber || !utrNumber.trim()) {
    throw new Error('Please enter your valid 12-digit UPI Reference / UTR Number.');
  }

  const cleanUtr = utrNumber.trim();
  const effectiveUserId = auth.currentUser?.uid || userId;
  const txnId = cleanUtr.startsWith('TXN_') ? cleanUtr : `TXN_${cleanUtr}`;

  const result = await runTransaction(db, async (transaction) => {
    const processedTxnRef = doc(db, 'processed_payments', txnId);
    const processedSnap = await transaction.get(processedTxnRef);

    if (processedSnap.exists()) {
      const data = processedSnap.data();
      if (data.status !== 'PENDING_APPROVAL' && data.verified) {
        throw new Error(`This UPI Reference / UTR (${cleanUtr}) has already been used and verified.`);
      }
    }

    const orderRef = doc(db, 'payment_orders', orderId);
    const orderSnap = await transaction.get(orderRef);

    if (orderSnap.exists()) {
      transaction.update(orderRef, sanitizeForFirestore({
        status: 'SUCCESS',
        transactionId: txnId,
      }));
    }

    const now = new Date().toISOString();
    const paymentRecord = {
      id: txnId,
      orderId,
      tournamentId,
      userId: effectiveUserId,
      amount: expectedAmount,
      currency: 'INR',
      paymentMethod,
      utrNumber: cleanUtr,
      verified: false,
      status: 'PENDING_APPROVAL',
      createdAt: now,
    };

    transaction.set(processedTxnRef, sanitizeForFirestore(paymentRecord));

    return {
      success: true,
      transactionId: txnId,
      amount: expectedAmount,
      paymentMethod,
      isManualPending: true,
    };
  });

  return result;
}

/**
 * Admin Action: Confirms a player's entry payment.
 * Marks registration paymentStatus as 'VERIFIED' and saves admin signature, timestamp & notes.
 */
export async function confirmPlayerPayment(
  registrationId: string,
  adminName: string,
  adminNotes?: string
): Promise<void> {
  const regRef = doc(db, 'registrations', registrationId);
  const now = new Date().toISOString();

  await updateDoc(regRef, sanitizeForFirestore({
    paymentStatus: 'VERIFIED',
    verifiedAt: now,
    verifiedBy: adminName || 'Admin Desk',
    paymentNotes: adminNotes ? adminNotes.trim() : 'Confirmed by Admin Desk',
    updatedAt: now,
  }));
}

/**
 * Admin Action: Rejects a player's entry payment.
 * Marks registration paymentStatus as 'REJECTED' with clear reason.
 */
export async function rejectPlayerPayment(
  registrationId: string,
  adminName: string,
  reason: string
): Promise<void> {
  const regRef = doc(db, 'registrations', registrationId);
  const now = new Date().toISOString();

  await updateDoc(regRef, sanitizeForFirestore({
    paymentStatus: 'REJECTED',
    paymentNotes: reason?.trim() || 'Payment verification rejected by admin.',
    verifiedBy: adminName || 'Admin Desk',
    updatedAt: now,
  }));
}

/**
 * Checks if a UTR number or Transaction ID is already used across registrations.
 */
export async function checkDuplicateUtr(
  utrNumber: string,
  excludeRegistrationId?: string
): Promise<{ isDuplicate: boolean; matchedRegistration?: Registration }> {
  if (!utrNumber || !utrNumber.trim()) {
    return { isDuplicate: false };
  }

  const cleanUtr = utrNumber.trim().toLowerCase();
  const q = query(collection(db, 'registrations'));
  const snap = await getDocs(q);

  for (const docSnap of snap.docs) {
    const data = docSnap.data() as Registration;
    if (excludeRegistrationId && data.id === excludeRegistrationId) continue;

    const existingUtr = (data.utrNumber || data.paymentTransactionId || '').toLowerCase();
    if (existingUtr && (existingUtr === cleanUtr || existingUtr.includes(cleanUtr) || cleanUtr.includes(existingUtr))) {
      return { isDuplicate: true, matchedRegistration: data };
    }
  }

  return { isDuplicate: false };
}

/**
 * Admin Action: Manually registers and confirms a paid player (e.g. offline cash, direct UPI transfer).
 */
export async function manualRegisterPaidPlayer(
  params: ManualPaymentParams
): Promise<Registration> {
  // 1. Fetch tournament
  const tournRef = doc(db, 'tournaments', params.tournamentId);
  const tournSnap = await getDoc(tournRef);
  if (!tournSnap.exists()) {
    throw new Error('Selected tournament does not exist.');
  }
  const tourn = tournSnap.data() as Tournament;

  // 2. Fetch available match
  const matchesQuery = query(
    collection(db, 'matches'),
    where('tournamentId', '==', params.tournamentId),
    where('status', 'in', ['ACTIVE', 'WAITING'])
  );
  const matchesSnap = await getDocs(matchesQuery);
  const availableMatchDoc = matchesSnap.docs.find(d => {
    const data = d.data();
    return (data.currentCount || 0) < (data.capacity || 48);
  });

  if (!availableMatchDoc) {
    throw new Error('No available match room found with open slots in this tournament.');
  }

  const matchData = availableMatchDoc.data();
  const newSeatNumber = (matchData.currentCount || 0) + 1;
  const regId = `REG_${params.tournamentId}_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
  const now = new Date().toISOString();
  const effectiveUserId = params.playerId || `OFFLINE_${params.freeFireUid.trim()}`;

  const newReg: Registration = {
    id: regId,
    tournamentId: params.tournamentId,
    tournamentTitle: tourn.title,
    format: params.format || tourn.format || 'SOLO',
    entryType: 'PAID_IN_GAME',
    playerId: effectiveUserId,
    playerName: params.playerName.trim(),
    freeFireUid: params.freeFireUid.trim(),
    ign: params.ign.trim(),
    phone: params.phone.trim(),
    teamName: params.teamName ? params.teamName.trim() : undefined,
    matchId: matchData.id,
    matchNumber: matchData.matchNumber || 1,
    matchName: matchData.name || 'Qualifier Match 1',
    seatNumber: newSeatNumber,
    paymentStatus: 'VERIFIED',
    paymentMethod: params.paymentMethod || 'UPI',
    entryFeePaid: params.amount,
    utrNumber: params.utrNumber.trim() || `MANUAL_${Date.now()}`,
    paymentTransactionId: `TXN_${params.utrNumber.trim() || Date.now()}`,
    paymentNotes: params.adminNotes ? params.adminNotes.trim() : `Manually confirmed by ${params.adminName}`,
    createdAt: now,
    verifiedAt: now,
    verifiedBy: params.adminName || 'Admin Desk',
  };

  await runTransaction(db, async (tx) => {
    const rRef = doc(db, 'registrations', regId);
    const mRef = doc(db, 'matches', matchData.id);
    const tRef = doc(db, 'tournaments', params.tournamentId);

    tx.set(rRef, sanitizeForFirestore(newReg));
    tx.update(mRef, {
      currentCount: newSeatNumber,
      updatedAt: now,
    });
    tx.update(tRef, {
      registeredCount: (tourn.registeredCount || 0) + 1,
      updatedAt: now,
    });
  });

  return newReg;
}

