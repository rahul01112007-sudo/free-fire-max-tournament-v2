import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { MatchResult, MatchStage, ResultWinner, TournamentFormat } from '../types';
import { createPrizeDeliveriesFromResult } from './prizeDeliveryService';

export async function publishMatchResult(params: {
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName: string;
  stage: MatchStage;
  format: TournamentFormat;
  publishedBy: string;
  winners: ResultWinner[];
  notes?: string;
}): Promise<MatchResult> {
  const resultId = `res_${params.matchId}`;

  const result: MatchResult = {
    id: resultId,
    tournamentId: params.tournamentId,
    tournamentTitle: params.tournamentTitle || '',
    matchId: params.matchId,
    matchName: params.matchName,
    stage: params.stage,
    format: params.format,
    publishedAt: new Date().toISOString(),
    publishedBy: params.publishedBy,
    winners: params.winners,
    notes: params.notes || '',
  };

  const batch = writeBatch(db);

  // Save result
  const resRef = doc(db, 'results', resultId);
  batch.set(resRef, sanitizeForFirestore(result));

  // Mark match as COMPLETED
  const matchRef = doc(db, 'matches', params.matchId);
  batch.update(matchRef, {
    status: 'COMPLETED',
  });

  await batch.commit();

  // Create prize delivery ledger records for verified ranks
  try {
    await createPrizeDeliveriesFromResult(result, null, params.publishedBy);
  } catch (e) {
    console.warn('Prize delivery creation notice:', e);
  }

  return result;
}

export function listenTournamentResults(
  tournamentId: string, 
  callback: (results: MatchResult[]) => void
): () => void {
  const q = query(
    collection(db, 'results'),
    where('tournamentId', '==', tournamentId),
    orderBy('publishedAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: MatchResult[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as MatchResult);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to tournament results:', err);
  });
}

export function listenAllResults(callback: (results: MatchResult[]) => void): () => void {
  const q = query(collection(db, 'results'), orderBy('publishedAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const list: MatchResult[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as MatchResult);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to all results:', err);
  });
}
