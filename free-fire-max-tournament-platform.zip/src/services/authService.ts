import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  updateProfile,
  sendPasswordResetEmail,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs,
  limit 
} from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { UserProfile, UserRole } from '../types';

export const MASTER_ADMIN_EMAIL = 'rahul01112007@gmail.com';
export const SUPER_ADMIN_EMAIL = MASTER_ADMIN_EMAIL;

export function formatAuthError(error: any): string {
  const code = error?.code || '';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Invalid email or password. Please check your spelling or use "Forgot Password" to reset your password.';
    case 'auth/email-already-in-use':
      return 'This email is already registered. Please sign in with your password, or use "Forgot Password" if you forgot it.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters long.';
    case 'auth/too-many-requests':
      return 'Too many failed attempts. Access to this account has been temporarily disabled. You can restore it immediately by resetting your password.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your internet connection.';
    default:
      return error?.message || 'Authentication failed. Please verify your credentials.';
  }
}

export async function resetUserPassword(email: string): Promise<void> {
  const normalizedEmail = email.toLowerCase().trim();
  if (!normalizedEmail) {
    throw new Error('Please enter a valid email address first.');
  }
  try {
    await sendPasswordResetEmail(auth, normalizedEmail);
  } catch (err: any) {
    throw new Error(formatAuthError(err));
  }
}

export async function checkAdminExists(): Promise<boolean> {
  // The master admin is permanently defined by the master account
  return true;
}

export async function registerPlayer(params: {
  name: string;
  email: string;
  password: string;
  freeFireUid?: string;
  ign?: string;
  phone?: string;
}): Promise<UserProfile> {
  const normalizedEmail = params.email.toLowerCase().trim();
  if (normalizedEmail === MASTER_ADMIN_EMAIL.toLowerCase()) {
    throw new Error('This email is reserved exclusively for the Master Administrator. Administrative accounts cannot be registered through player signup.');
  }
  let user: FirebaseUser;

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, normalizedEmail, params.password);
    user = userCredential.user;
  } catch (authErr: any) {
    if (authErr.code === 'auth/email-already-in-use') {
      try {
        // Authenticate with the provided credentials if account exists
        const userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, params.password);
        user = userCredential.user;
      } catch {
        throw new Error('This email is already registered. Please sign in with your password, or use "Forgot Password".');
      }
    } else {
      throw new Error(formatAuthError(authErr));
    }
  }

  try {
    await updateProfile(user, {
      displayName: params.name || user.displayName || 'Player',
    });
  } catch (e) {
    console.warn('Error updating profile display name:', e);
  }

  const isMasterAdmin = normalizedEmail === MASTER_ADMIN_EMAIL.toLowerCase();

  // Check if profile exists to merge existing stats or update
  const docRef = doc(db, 'users', user.uid);
  const existingSnap = await getDoc(docRef);
  let existingProfile: Partial<UserProfile> = {};
  if (existingSnap.exists()) {
    existingProfile = existingSnap.data() as UserProfile;
  }

  const profile: UserProfile = {
    uid: user.uid,
    email: normalizedEmail,
    displayName: params.name || existingProfile.displayName || (isMasterAdmin ? 'Master Administrator' : 'Player'),
    role: isMasterAdmin ? 'admin' : 'player',
    status: existingProfile.status || 'active',
    freeFireUid: params.freeFireUid?.trim() || existingProfile.freeFireUid || '',
    ign: params.ign?.trim() || existingProfile.ign || params.name,
    phone: params.phone?.trim() || existingProfile.phone || '',
    createdAt: existingProfile.createdAt || new Date().toISOString(),
  };

  await setDoc(docRef, profile, { merge: true });

  // If master admin, securely sync /admins/{uid} doc
  if (isMasterAdmin) {
    try {
      await setDoc(doc(db, 'admins', user.uid), {
        uid: user.uid,
        email: normalizedEmail,
        isMasterAdmin: true,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (e) {
      console.warn('Could not sync admins doc:', e);
    }
  }

  return profile;
}

export async function signInUser(email: string, password: string): Promise<{ user: FirebaseUser; profile: UserProfile }> {
  const normalizedEmail = email.toLowerCase().trim();
  let userCredential;
  try {
    userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, password);
  } catch (err: any) {
    throw new Error(formatAuthError(err));
  }
  const user = userCredential.user;

  const isMasterAdminEmail = normalizedEmail === MASTER_ADMIN_EMAIL.toLowerCase();
  const docRef = doc(db, 'users', user.uid);
  const docSnap = await getDoc(docRef);

  let profile: UserProfile;

  if (docSnap.exists()) {
    profile = docSnap.data() as UserProfile;
    // Auto-promote master admin email only
    if (isMasterAdminEmail && (profile.role !== 'admin' || profile.status !== 'active')) {
      profile = {
        ...profile,
        role: 'admin',
        status: 'active',
      };
      await updateDoc(docRef, { role: 'admin', status: 'active' });
    } else if (!isMasterAdminEmail && profile.role === 'admin') {
      // Demote any non-master admin account that might have had admin role
      profile = {
        ...profile,
        role: 'player',
      };
      await updateDoc(docRef, { role: 'player' });
    }
  } else {
    // If not found in firestore, create profile
    const role: UserRole = isMasterAdminEmail ? 'admin' : 'player';
    profile = {
      uid: user.uid,
      email: user.email || normalizedEmail,
      displayName: user.displayName || (isMasterAdminEmail ? 'Master Administrator' : 'Player'),
      role,
      status: 'active',
      createdAt: new Date().toISOString(),
    };
    await setDoc(docRef, profile, { merge: true });
  }

  // If master admin, guarantee /admins/{uid} doc
  if (isMasterAdminEmail) {
    try {
      await setDoc(doc(db, 'admins', user.uid), {
        uid: user.uid,
        email: normalizedEmail,
        isMasterAdmin: true,
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (e) {
      console.warn('Could not sync admins doc:', e);
    }
  }

  // Return the user and profile so banned state can be displayed with exact reason
  return { user, profile };
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const docRef = doc(db, 'users', uid);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return docSnap.data() as UserProfile;
  }
  return null;
}

export async function updateUserProfile(uid: string, data: Partial<UserProfile>): Promise<void> {
  // Prevent updating security fields from client
  const { role, status, uid: _uid, email: _email, ...safeData } = data;
  const docRef = doc(db, 'users', uid);
  const cleanData: Record<string, any> = {
    updatedAt: new Date().toISOString(),
  };
  for (const [k, v] of Object.entries(safeData)) {
    if (v !== undefined) {
      cleanData[k] = v;
    }
  }
  await updateDoc(docRef, cleanData);
}

export async function adminUpdateUserStatus(uid: string, status: 'active' | 'banned' | 'suspended'): Promise<void> {
  const docRef = doc(db, 'users', uid);
  await updateDoc(docRef, { 
    status,
    isBanned: status === 'banned',
    updatedAt: new Date().toISOString(),
  });
}

export async function banPlayer(uid: string, reason?: string, adminName?: string): Promise<void> {
  const docRef = doc(db, 'users', uid);
  const now = new Date().toISOString();
  await updateDoc(docRef, { 
    status: 'banned',
    isBanned: true,
    banReason: reason?.trim() || 'Violation of competitive fair play rules',
    bannedAt: now,
    bannedBy: adminName || 'Tournament Administrator',
    updatedAt: now,
  });
}

export async function unbanPlayer(uid: string): Promise<void> {
  const docRef = doc(db, 'users', uid);
  const now = new Date().toISOString();
  await updateDoc(docRef, { 
    status: 'active',
    isBanned: false,
    banReason: '',
    unbannedAt: now,
    updatedAt: now,
  });
}

export async function signOutUser(): Promise<void> {
  await signOut(auth);
}
