export interface AdminLockoutStatus {
  isLocked: boolean;
  remainingSeconds: number;
  failedAttempts: number;
  attemptsRemaining: number;
  lockedUntil: number | null;
}

const STORAGE_KEY = 'ff_admin_security_lockout';
export const MAX_FAILED_ATTEMPTS = 3;
export const LOCKOUT_DURATION_SECONDS = 300; // 5 minutes = 300s
export const LOCKOUT_DURATION_MS = LOCKOUT_DURATION_SECONDS * 1000;

interface StoredLockoutData {
  failedAttempts: number;
  lockedUntil: number | null;
  lastFailedAt: number | null;
}

function getStoredData(): StoredLockoutData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return { failedAttempts: 0, lockedUntil: null, lastFailedAt: null };
    }
    return JSON.parse(raw);
  } catch {
    return { failedAttempts: 0, lockedUntil: null, lastFailedAt: null };
  }
}

function setStoredData(data: StoredLockoutData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.warn('Could not persist admin lockout state:', err);
  }
}

export function getAdminLockoutStatus(): AdminLockoutStatus {
  const data = getStoredData();
  const now = Date.now();

  if (data.lockedUntil && now < data.lockedUntil) {
    const remainingSeconds = Math.max(0, Math.ceil((data.lockedUntil - now) / 1000));
    return {
      isLocked: true,
      remainingSeconds,
      failedAttempts: data.failedAttempts,
      attemptsRemaining: 0,
      lockedUntil: data.lockedUntil,
    };
  }

  // If lockout was active but time has passed, automatically unlock and reset
  if (data.lockedUntil && now >= data.lockedUntil) {
    const resetData: StoredLockoutData = {
      failedAttempts: 0,
      lockedUntil: null,
      lastFailedAt: null,
    };
    setStoredData(resetData);
    return {
      isLocked: false,
      remainingSeconds: 0,
      failedAttempts: 0,
      attemptsRemaining: MAX_FAILED_ATTEMPTS,
      lockedUntil: null,
    };
  }

  const failedAttempts = Math.min(data.failedAttempts || 0, MAX_FAILED_ATTEMPTS);
  const attemptsRemaining = Math.max(0, MAX_FAILED_ATTEMPTS - failedAttempts);

  return {
    isLocked: false,
    remainingSeconds: 0,
    failedAttempts,
    attemptsRemaining,
    lockedUntil: null,
  };
}

export function recordAdminFailedAttempt(): AdminLockoutStatus {
  const current = getAdminLockoutStatus();
  const now = Date.now();

  if (current.isLocked) {
    return current;
  }

  const newFailedAttempts = current.failedAttempts + 1;
  const isNowLocked = newFailedAttempts >= MAX_FAILED_ATTEMPTS;
  const lockedUntil = isNowLocked ? now + LOCKOUT_DURATION_MS : null;

  const updatedData: StoredLockoutData = {
    failedAttempts: newFailedAttempts,
    lockedUntil,
    lastFailedAt: now,
  };

  setStoredData(updatedData);

  return {
    isLocked: isNowLocked,
    remainingSeconds: isNowLocked ? LOCKOUT_DURATION_SECONDS : 0,
    failedAttempts: newFailedAttempts,
    attemptsRemaining: Math.max(0, MAX_FAILED_ATTEMPTS - newFailedAttempts),
    lockedUntil,
  };
}

export function clearAdminLockout(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.warn('Could not clear admin lockout state:', err);
  }
}
