import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  query, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { AntiCheatReason, AntiCheatReport, ReportStatus } from '../types';
import { adminUpdateUserStatus } from './authService';

export async function submitAntiCheatReport(params: {
  reporterUid: string;
  reporterName: string;
  reporterEmail?: string;
  suspectUid?: string;
  suspectIgn: string;
  suspectFfUid: string;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName?: string;
  reason: AntiCheatReason;
  description: string;
  evidenceUrl: string;
}): Promise<AntiCheatReport> {
  const reportId = `report_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  
  const report: AntiCheatReport = {
    id: reportId,
    reporterUid: params.reporterUid,
    reporterName: params.reporterName,
    reporterEmail: params.reporterEmail || '',
    suspectUid: params.suspectUid || '',
    suspectIgn: params.suspectIgn.trim(),
    suspectFfUid: params.suspectFfUid.trim(),
    tournamentId: params.tournamentId,
    tournamentTitle: params.tournamentTitle || '',
    matchId: params.matchId,
    matchName: params.matchName || '',
    reason: params.reason,
    description: params.description.trim(),
    evidenceUrl: params.evidenceUrl.trim(),
    status: 'PENDING',
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'antiCheatReports', reportId), report);
  return report;
}

export function listenAntiCheatReports(callback: (reports: AntiCheatReport[]) => void): () => void {
  const q = query(collection(db, 'antiCheatReports'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const list: AntiCheatReport[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as AntiCheatReport);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to anti-cheat reports:', err);
  });
}

export async function updateReportStatus(
  reportId: string, 
  status: ReportStatus, 
  adminName: string, 
  adminNotes?: string,
  suspectUid?: string
): Promise<void> {
  const docRef = doc(db, 'antiCheatReports', reportId);
  await updateDoc(docRef, {
    status,
    reviewedAt: new Date().toISOString(),
    reviewedBy: adminName,
    adminNotes: adminNotes || '',
  });

  // If status is BANNED and suspect has a UID, update user status to banned
  if (status === 'BANNED' && suspectUid) {
    await adminUpdateUserStatus(suspectUid, 'banned');
  }
}
