import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { PrizeDelivery, PrizeDeliveryStatus, PrizeType, MatchResult, Tournament, FREE_FIRE_DIAMOND_PACKAGES, isDiamondPrizeType } from '../types';

const PRIZE_DELIVERY_COLLECTION = 'prizeDeliveries';

/**
 * Listen to all prize deliveries (for Admin Desk)
 */
export function listenAllPrizeDeliveries(callback: (deliveries: PrizeDelivery[]) => void): () => void {
  const q = query(
    collection(db, PRIZE_DELIVERY_COLLECTION),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: PrizeDelivery[] = [];
    snapshot.forEach((docSnap) => {
      list.push({ id: docSnap.id, ...docSnap.data() } as PrizeDelivery);
    });
    callback(list);
  }, (err) => {
    console.warn('Prize deliveries listener notice:', err.message);
  });
}

/**
 * Listen to prize deliveries for a specific winning user/player
 */
export function listenUserPrizeDeliveries(
  userUid: string,
  userIgn: string,
  callback: (deliveries: PrizeDelivery[]) => void
): () => void {
  const q = query(
    collection(db, PRIZE_DELIVERY_COLLECTION),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: PrizeDelivery[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data() as PrizeDelivery;
      if (
        (userUid && data.winnerUid === userUid) ||
        (userIgn && data.winnerIgn?.toLowerCase() === userIgn.toLowerCase())
      ) {
        list.push({ id: docSnap.id, ...data });
      }
    });
    callback(list);
  }, (err) => {
    console.warn('User prize deliveries listener notice:', err.message);
  });
}

/**
 * Create or update a prize delivery entry
 */
export async function savePrizeDelivery(delivery: Omit<PrizeDelivery, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): Promise<string> {
  const now = new Date().toISOString();
  const deliveryId = delivery.id || `pdel_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const docRef = doc(db, PRIZE_DELIVERY_COLLECTION, deliveryId);

  const data: PrizeDelivery = {
    ...delivery,
    id: deliveryId,
    createdAt: now,
    updatedAt: now,
  };

  await setDoc(docRef, sanitizeForFirestore(data), { merge: true });
  return deliveryId;
}

/**
 * Update prize delivery status & gift card details (Admin only)
 */
export async function updatePrizeDeliveryStatus(
  deliveryId: string,
  updates: {
    status: PrizeDeliveryStatus;
    giftCardProvider?: string;
    deliveryReference?: string;
    deliveryDate?: string;
    adminNotes?: string;
    winnerVerified?: boolean;
    antiCheatCleared?: boolean;
    deliveredBy?: string;
  }
): Promise<void> {
  const docRef = doc(db, PRIZE_DELIVERY_COLLECTION, deliveryId);
  await updateDoc(docRef, sanitizeForFirestore({
    ...updates,
    updatedAt: new Date().toISOString(),
  }));
}

/**
 * Mark a winner as ELIGIBLE_FOR_PRIZE after result verification and anti-cheat checks pass
 */
export async function markWinnerEligibleForPrize(deliveryId: string, adminName: string): Promise<void> {
  const docRef = doc(db, PRIZE_DELIVERY_COLLECTION, deliveryId);
  await updateDoc(docRef, sanitizeForFirestore({
    status: 'ELIGIBLE_FOR_PRIZE',
    winnerVerified: true,
    antiCheatCleared: true,
    adminNotes: `Verified & Anti-Cheat Cleared by ${adminName}`,
    updatedAt: new Date().toISOString(),
  }));
}

/**
 * Manually deliver prize and mark as SENT (Admin only)
 */
export async function markPrizeAsSent(
  deliveryId: string,
  details: {
    deliveryReference: string;
    deliveryDate: string;
    recipientEmail?: string;
    recipientPhone?: string;
    adminNotes?: string;
    adminName: string;
  }
): Promise<void> {
  const docRef = doc(db, PRIZE_DELIVERY_COLLECTION, deliveryId);
  const snap = await getDoc(docRef);
  if (!snap.exists()) {
    throw new Error('Prize delivery record not found.');
  }

  const existing = snap.data() as PrizeDelivery;
  if (existing.status !== 'ELIGIBLE_FOR_PRIZE' && existing.status !== 'PROCESSING') {
    throw new Error('Only winners marked as "ELIGIBLE FOR PRIZE" (after anti-cheat check) can be sent prizes.');
  }

  await updateDoc(docRef, sanitizeForFirestore({
    status: 'SENT',
    deliveryReference: details.deliveryReference.trim(),
    deliveryDate: details.deliveryDate || new Date().toISOString(),
    winnerEmail: details.recipientEmail?.trim() || existing.winnerEmail || '',
    winnerPhone: details.recipientPhone?.trim() || existing.winnerPhone || '',
    adminNotes: details.adminNotes?.trim() || existing.adminNotes || '',
    deliveredBy: details.adminName,
    updatedAt: new Date().toISOString(),
  }));
}

/**
 * Initialize prize delivery entries when results are published
 */
export async function createPrizeDeliveriesFromResult(
  result: MatchResult,
  tournament?: Tournament | null,
  adminName?: string
): Promise<void> {
  if (!result.winners || result.winners.length === 0) return;

  const defaultPrizeType: PrizeType = tournament?.prizeType || 'FREE FIRE DIAMONDS';

  for (const w of result.winners) {
    if (w.prizeAmount && w.prizeAmount > 0) {
      const deliveryId = `pdel_${result.tournamentId}_${result.matchId}_rank${w.rank}`;
      const docRef = doc(db, PRIZE_DELIVERY_COLLECTION, deliveryId);
      const existing = await getDoc(docRef);

      if (!existing.exists()) {
        const pType: PrizeType = w.prizeType || defaultPrizeType;
        const matchedPkg = isDiamondPrizeType(pType) 
          ? FREE_FIRE_DIAMOND_PACKAGES.find(p => p.diamonds === w.prizeAmount)
          : undefined;

        const newDelivery: PrizeDelivery = {
          id: deliveryId,
          tournamentId: result.tournamentId,
          tournamentTitle: result.tournamentTitle || tournament?.title || 'Tournament',
          matchId: result.matchId,
          matchName: result.matchName,
          winnerUid: w.participantId && w.participantId.startsWith('user_') ? w.participantId : undefined,
          winnerName: w.name || w.ign,
          winnerIgn: w.ign,
          winnerFfUid: w.ffUid,
          prizeRank: w.rank,
          prizeType: pType,
          prizeValue: w.prizeAmount,
          diamondPackageId: matchedPkg?.id,
          diamondPackage: matchedPkg ? `${matchedPkg.label} (${matchedPkg.diamonds} 💎)` : undefined,
          status: 'ANTI_CHEAT_UNDER_REVIEW',
          giftCardProvider: isDiamondPrizeType(pType) ? 'Free Fire Official Top-Up' : pType.replace(' GIFT CARD', '').replace(' VOUCHER', ''),
          deliveryReference: '',
          adminNotes: `Winner of ${result.matchName} Rank #${w.rank}. Awaiting anti-cheat review.`,
          winnerVerified: false,
          antiCheatCleared: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          deliveredBy: adminName,
        };
        await setDoc(docRef, sanitizeForFirestore(newDelivery));
      }
    }
  }
}
