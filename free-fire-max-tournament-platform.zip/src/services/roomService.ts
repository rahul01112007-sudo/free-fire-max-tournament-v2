import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { RoomCredentials } from '../types';

export async function saveRoomCredentials(params: {
  matchId: string;
  tournamentId: string;
  matchName?: string;
  roomId: string;
  roomPassword: string;
  customRules?: string;
  adminName?: string;
}): Promise<void> {
  const docRef = doc(db, 'rooms', params.matchId);
  const existing = await getDoc(docRef);

  const data: RoomCredentials = {
    id: params.matchId,
    tournamentId: params.tournamentId,
    matchId: params.matchId,
    matchName: params.matchName || '',
    roomId: params.roomId.trim(),
    roomPassword: params.roomPassword.trim(),
    status: existing.exists() ? (existing.data().status as any) : 'LOCKED',
    customRules: params.customRules || 'No emulator, No hack, Spectator off, Default gun attributes.',
    updatedAt: new Date().toISOString(),
    updatedBy: params.adminName || 'Admin',
  };

  await setDoc(docRef, data, { merge: true });
}

export async function releaseRoomCredentials(matchId: string, adminName: string): Promise<void> {
  const roomRef = doc(db, 'rooms', matchId);
  const matchRef = doc(db, 'matches', matchId);

  const updateData = {
    status: 'RELEASED' as const,
    releasedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    updatedBy: adminName,
  };

  await updateDoc(roomRef, updateData);
  await updateDoc(matchRef, { roomStatus: 'RELEASED' });
}

export async function lockRoomCredentials(matchId: string, adminName: string): Promise<void> {
  const roomRef = doc(db, 'rooms', matchId);
  const matchRef = doc(db, 'matches', matchId);

  const updateData = {
    status: 'LOCKED' as const,
    updatedAt: new Date().toISOString(),
    updatedBy: adminName,
  };

  await updateDoc(roomRef, updateData);
  await updateDoc(matchRef, { roomStatus: 'LOCKED' });
}

export function listenRoomCredentials(
  matchId: string, 
  callback: (credentials: RoomCredentials | null) => void
): () => void {
  const docRef = doc(db, 'rooms', matchId);
  return onSnapshot(docRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.data() as RoomCredentials);
    } else {
      callback(null);
    }
  }, (err) => {
    console.error(`Error listening to room credentials for ${matchId}:`, err);
  });
}

export function listenTournamentRooms(
  tournamentId: string, 
  callback: (rooms: Record<string, RoomCredentials>) => void
): () => void {
  const q = query(collection(db, 'rooms'), where('tournamentId', '==', tournamentId));
  return onSnapshot(q, (snapshot) => {
    const map: Record<string, RoomCredentials> = {};
    snapshot.forEach((docSnap) => {
      map[docSnap.id] = docSnap.data() as RoomCredentials;
    });
    callback(map);
  }, (err) => {
    console.error('Error listening to tournament rooms:', err);
  });
}
