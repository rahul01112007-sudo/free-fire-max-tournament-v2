import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  runTransaction 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { 
  Registration, 
  SquadMember, 
  Tournament, 
  TournamentFormat, 
  TournamentMatch, 
  TournamentEntryType,
  AdEntryProgress 
} from '../types';

export interface SoloRegistrationParams {
  tournamentId: string;
  playerId: string;
  playerName: string;
  freeFireUid: string;
  ign: string;
  phone: string;
  paymentTransactionId?: string;
  utrNumber?: string;
  paymentMethod?: 'UPI' | 'FREE' | 'WALLET' | 'ONLINE' | 'CARD' | 'CASH';
  entryFeePaid?: number;
  autoVerify?: boolean;
  isManualPending?: boolean;
}

export interface SquadRegistrationParams {
  tournamentId: string;
  teamName: string;
  teamLeaderUid: string;
  captain: SquadMember;
  members: SquadMember[];
  phone: string;
  paymentTransactionId?: string;
  utrNumber?: string;
  paymentMethod?: 'UPI' | 'FREE' | 'WALLET' | 'ONLINE' | 'CARD' | 'CASH';
  entryFeePaid?: number;
  autoVerify?: boolean;
  isManualPending?: boolean;
}

export async function checkPlayerAlreadyRegistered(tournamentId: string, playerId: string): Promise<boolean> {
  const q = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId),
    where('playerId', '==', playerId)
  );
  const snap = await getDocs(q);
  return !snap.empty;
}

export async function checkTeamAlreadyRegistered(tournamentId: string, teamLeaderUid: string, teamName: string): Promise<boolean> {
  const q1 = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId),
    where('teamLeaderUid', '==', teamLeaderUid)
  );
  const snap1 = await getDocs(q1);
  if (!snap1.empty) return true;

  const q2 = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId),
    where('teamName', '==', teamName.trim())
  );
  const snap2 = await getDocs(q2);
  return !snap2.empty;
}

export async function registerSoloPlayer(params: SoloRegistrationParams): Promise<Registration> {
  const { tournamentId, playerId } = params;

  if (!params.freeFireUid || !params.freeFireUid.trim()) {
    throw new Error('Free Fire UID is required for tournament registration.');
  }

  // Use Firestore transaction to guarantee atomic seat assignment & verification
  const registration = await runTransaction(db, async (transaction) => {
    // 1. Validate Tournament
    const tournRef = doc(db, 'tournaments', tournamentId);
    const tournSnap = await transaction.get(tournRef);
    if (!tournSnap.exists()) {
      throw new Error('Tournament does not exist.');
    }
    const tournament = tournSnap.data() as Tournament;

    if (tournament.status === 'REGISTRATION_CLOSED' || tournament.status === 'COMPLETED' || tournament.status === 'CANCELLED') {
      throw new Error(`Tournament registration is currently ${tournament.status.toLowerCase().replace('_', ' ')}.`);
    }

    if (tournament.registeredCount >= tournament.maxParticipants) {
      throw new Error('Tournament has reached full capacity.');
    }

    const entryType: TournamentEntryType = tournament.entryType || (tournament.entryFee && tournament.entryFee > 0 ? 'PAID_IN_GAME' : 'FREE_ADS');
    const adProgressRef = doc(db, 'adEntryProgress', `${playerId}_${tournamentId}`);

    // 2. Validate Entry requirements based on entryType
    if (entryType === 'FREE_ADS') {
      const adProgressSnap = await transaction.get(adProgressRef);
      if (!adProgressSnap.exists()) {
        throw new Error('Please watch 5 verified rewarded ads to unlock your free tournament entry ticket.');
      }

      const adProgress = adProgressSnap.data() as AdEntryProgress;
      const adsRequired = adProgress.adsRequired || tournament.adsRequired || 5;
      const adsCompleted = adProgress.adsCompleted || 0;

      if (!adProgress.entryUnlocked && adsCompleted < adsRequired) {
        throw new Error(`Entry ticket locked. You have watched ${adsCompleted}/${adsRequired} rewarded ads.`);
      }

      if (adProgress.ticketStatus === 'USED') {
        throw new Error('Your entry ticket has already been used for this tournament. Only one registration is allowed per ticket.');
      }
    } else if (entryType === 'PAID_IN_GAME') {
      // Validate verified payment transaction record
      const rawTxn = params.paymentTransactionId || params.utrNumber;
      if (!rawTxn) {
        throw new Error('Verified payment transaction reference is required for paid entry.');
      }
      const txnKey = rawTxn.startsWith('TXN_') ? rawTxn : `TXN_${rawTxn}`;
      const processedRef = doc(db, 'processed_payments', txnKey);
      const processedSnap = await transaction.get(processedRef);

      if (!processedSnap.exists()) {
        throw new Error('Verified payment record not found. Please complete the payment verification step.');
      }
    }

    // 3. Check for duplicate registration in THIS tournament
    const regDocId = `reg_${tournamentId}_${playerId}`;
    const existingRegRef = doc(db, 'registrations', regDocId);
    const existingRegSnap = await transaction.get(existingRegRef);
    if (existingRegSnap.exists()) {
      throw new Error('You are already registered for this tournament.');
    }

    // 4. Find available qualifier match based on dynamic configured capacity
    const matchesQuery = query(
      collection(db, 'matches'),
      where('tournamentId', '==', tournamentId),
      where('stage', '==', 'QUALIFIER'),
      orderBy('matchNumber', 'asc')
    );
    const matchesSnap = await getDocs(matchesQuery);

    let assignedMatch: TournamentMatch | null = null;
    let targetMatchDocRef: any = null;

    for (const matchDoc of matchesSnap.docs) {
      const matchData = matchDoc.data() as TournamentMatch;
      if (matchData.status === 'LOCKED' || matchData.status === 'COMPLETED') {
        continue;
      }
      if (matchData.currentCount < matchData.capacity) {
        assignedMatch = matchData;
        targetMatchDocRef = matchDoc.ref;
        break;
      }
    }

    if (!assignedMatch || !targetMatchDocRef) {
      throw new Error('No available qualifier matches with vacant seats. Match capacity reached.');
    }

    const matchSnap = await transaction.get(targetMatchDocRef);
    if (!matchSnap.exists()) {
      throw new Error('Assigned match not found.');
    }
    const freshMatchData = matchSnap.data() as TournamentMatch;
    if (freshMatchData.currentCount >= freshMatchData.capacity) {
      throw new Error('Match slot was filled by another participant. Please try again.');
    }

    const assignedSeat = freshMatchData.currentCount + 1;
    const newCurrentCount = freshMatchData.currentCount + 1;
    const isNowFull = newCurrentCount >= freshMatchData.capacity;

    // Update match document
    transaction.update(targetMatchDocRef, {
      currentCount: newCurrentCount,
      status: isNowFull ? 'FULL' : 'ACTIVE',
    });

    // Update tournament registeredCount
    const newTournCount = tournament.registeredCount + 1;
    transaction.update(tournRef, {
      registeredCount: newTournCount,
      status: newTournCount >= tournament.maxParticipants ? 'REGISTRATION_CLOSED' : tournament.status,
    });

    const now = new Date().toISOString();

    // Consume the entry ticket atomically if ad-based
    if (entryType === 'FREE_ADS') {
      transaction.update(adProgressRef, {
        ticketStatus: 'USED',
        usedAt: now,
        registrationId: regDocId,
        updatedAt: now,
      });
    }

    const entryFeePaid = entryType === 'PAID_IN_GAME' ? (tournament.entryFee || params.entryFeePaid || 0) : 0;
    const paymentMethod = params.paymentMethod || (entryType === 'PAID_IN_GAME' ? 'UPI' : 'FREE');
    const utr = params.paymentTransactionId || params.utrNumber || (entryType === 'FREE_ADS' ? 'FREE_5_ADS_VERIFIED' : 'FREE_IN_GAME_VERIFIED');

    // Paid tournaments ALWAYS require admin verification before room credentials & entry card unlock
    const isPaid = entryType === 'PAID_IN_GAME' || entryFeePaid > 0;
    const isManual = isPaid || Boolean(params.isManualPending);
    const newRegistration: Registration = {
      id: regDocId,
      tournamentId,
      tournamentTitle: tournament.title || '',
      format: 'SOLO',
      entryType,
      playerId,
      playerName: params.playerName?.trim() || 'Player',
      freeFireUid: params.freeFireUid.trim(),
      ign: params.ign?.trim() || params.playerName?.trim() || 'Player',
      phone: params.phone?.trim() || '',
      matchId: freshMatchData.id,
      matchNumber: freshMatchData.matchNumber,
      matchName: freshMatchData.name || `Qualifier Match #${freshMatchData.matchNumber}`,
      seatNumber: assignedSeat,
      paymentStatus: isPaid ? 'PENDING' : (isManual ? 'PENDING' : 'VERIFIED'),
      paymentMethod,
      entryFeePaid,
      paymentTransactionId: utr,
      utrNumber: utr,
      paymentNotes: isPaid ? 'Submitted for Admin Manual Confirmation' : (isManual ? 'Submitted for Admin Manual Confirmation' : 'Free Entry Verified'),
      createdAt: now,
      verifiedAt: isPaid ? undefined : (isManual ? undefined : now),
      verifiedBy: isPaid ? undefined : (isManual ? undefined : (entryType === 'FREE_ADS' ? 'REWARDED_AD_VERIFIED' : 'FREE_ENTRY_SYSTEM')),
    };

    transaction.set(existingRegRef, sanitizeForFirestore(newRegistration));
    return newRegistration;
  });

  return registration;
}

export async function registerSquadTeam(params: SquadRegistrationParams): Promise<Registration> {
  const { tournamentId, teamLeaderUid, teamName, captain, members } = params;
  const teamId = `team_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  if (!captain.freeFireUid || !captain.freeFireUid.trim()) {
    throw new Error('Captain Free Fire UID is required for squad registration.');
  }

  const registration = await runTransaction(db, async (transaction) => {
    // 1. Validate Tournament
    const tournRef = doc(db, 'tournaments', tournamentId);
    const tournSnap = await transaction.get(tournRef);
    if (!tournSnap.exists()) {
      throw new Error('Tournament does not exist.');
    }
    const tournament = tournSnap.data() as Tournament;

    if (tournament.status === 'REGISTRATION_CLOSED' || tournament.status === 'COMPLETED' || tournament.status === 'CANCELLED') {
      throw new Error('Tournament registration is closed.');
    }

    if (tournament.registeredCount >= tournament.maxParticipants) {
      throw new Error('Tournament has reached full capacity.');
    }

    const entryType: TournamentEntryType = tournament.entryType || (tournament.entryFee && tournament.entryFee > 0 ? 'PAID_IN_GAME' : 'FREE_ADS');
    const adProgressRef = doc(db, 'adEntryProgress', `${teamLeaderUid}_${tournamentId}`);

    // 2. Validate Entry requirements
    if (entryType === 'FREE_ADS') {
      const adProgressSnap = await transaction.get(adProgressRef);
      if (!adProgressSnap.exists()) {
        throw new Error('Please watch 5 verified rewarded ads to unlock free tournament entry for your squad.');
      }

      const adProgress = adProgressSnap.data() as AdEntryProgress;
      const adsRequired = adProgress.adsRequired || tournament.adsRequired || 5;
      const adsCompleted = adProgress.adsCompleted || 0;

      if (!adProgress.entryUnlocked && adsCompleted < adsRequired) {
        throw new Error(`Squad entry locked. You have watched ${adsCompleted}/${adsRequired} rewarded ads.`);
      }

      if (adProgress.ticketStatus === 'USED') {
        throw new Error('Your squad entry ticket has already been used for this tournament. Only one registration is allowed per ticket.');
      }
    } else if (entryType === 'PAID_IN_GAME') {
      const rawTxn = params.paymentTransactionId || params.utrNumber;
      if (!rawTxn) {
        throw new Error('Verified payment transaction reference is required for paid entry.');
      }
      const txnKey = rawTxn.startsWith('TXN_') ? rawTxn : `TXN_${rawTxn}`;
      const processedRef = doc(db, 'processed_payments', txnKey);
      const processedSnap = await transaction.get(processedRef);

      if (!processedSnap.exists()) {
        throw new Error('Verified payment record not found. Please complete the payment verification step.');
      }
    }

    const regDocId = `reg_${tournamentId}_${teamLeaderUid}`;
    const existingRegRef = doc(db, 'registrations', regDocId);
    const existingRegSnap = await transaction.get(existingRegRef);
    if (existingRegSnap.exists()) {
      throw new Error('Your team is already registered for this tournament.');
    }

    // 3. Find available qualifier match based on dynamic capacity
    const matchesQuery = query(
      collection(db, 'matches'),
      where('tournamentId', '==', tournamentId),
      where('stage', '==', 'QUALIFIER'),
      orderBy('matchNumber', 'asc')
    );
    const matchesSnap = await getDocs(matchesQuery);

    let assignedMatch: TournamentMatch | null = null;
    let targetMatchDocRef: any = null;

    for (const matchDoc of matchesSnap.docs) {
      const matchData = matchDoc.data() as TournamentMatch;
      if (matchData.status === 'LOCKED' || matchData.status === 'COMPLETED') {
        continue;
      }
      if (matchData.currentCount < matchData.capacity) {
        assignedMatch = matchData;
        targetMatchDocRef = matchDoc.ref;
        break;
      }
    }

    if (!assignedMatch || !targetMatchDocRef) {
      throw new Error('No available qualifier matches for squad teams. Capacity reached.');
    }

    const matchSnap = await transaction.get(targetMatchDocRef);
    if (!matchSnap.exists()) {
      throw new Error('Assigned match not found.');
    }
    const freshMatchData = matchSnap.data() as TournamentMatch;
    if (freshMatchData.currentCount >= freshMatchData.capacity) {
      throw new Error('Match slot was filled by another squad team. Please try again.');
    }

    const assignedTeamSlot = freshMatchData.currentCount + 1;
    const newCurrentCount = freshMatchData.currentCount + 1;
    const isNowFull = newCurrentCount >= freshMatchData.capacity;

    transaction.update(targetMatchDocRef, {
      currentCount: newCurrentCount,
      status: isNowFull ? 'FULL' : 'ACTIVE',
    });

    const newTournCount = tournament.registeredCount + 1;
    transaction.update(tournRef, {
      registeredCount: newTournCount,
      status: newTournCount >= tournament.maxParticipants ? 'REGISTRATION_CLOSED' : tournament.status,
    });

    const now = new Date().toISOString();

    // Consume the squad entry ticket atomically if ad-based
    if (entryType === 'FREE_ADS') {
      transaction.update(adProgressRef, {
        ticketStatus: 'USED',
        usedAt: now,
        registrationId: regDocId,
        updatedAt: now,
      });
    }

    const allMembers: SquadMember[] = [captain, ...members].map((m) => {
      const cleanMember: SquadMember = {
        name: m.name?.trim() || '',
        freeFireUid: m.freeFireUid?.trim() || '',
        ign: m.ign?.trim() || m.name?.trim() || '',
      };
      if (m.phone && m.phone.trim()) {
        cleanMember.phone = m.phone.trim();
      }
      return cleanMember;
    });

    const entryFeePaid = entryType === 'PAID_IN_GAME' ? (tournament.entryFee || params.entryFeePaid || 0) : 0;
    const paymentMethod = params.paymentMethod || (entryType === 'PAID_IN_GAME' ? 'UPI' : 'FREE');
    const utr = params.paymentTransactionId || params.utrNumber || (entryType === 'FREE_ADS' ? 'FREE_5_ADS_VERIFIED' : 'FREE_IN_GAME_VERIFIED');

    const isPaid = entryType === 'PAID_IN_GAME' || entryFeePaid > 0;
    const isManual = isPaid || Boolean(params.isManualPending);
    const newRegistration: Registration = {
      id: regDocId,
      tournamentId,
      tournamentTitle: tournament.title || '',
      format: 'SQUAD',
      entryType,
      playerId: teamLeaderUid,
      playerName: captain.name?.trim() || 'Captain',
      freeFireUid: captain.freeFireUid.trim(),
      ign: captain.ign?.trim() || captain.name?.trim() || 'Captain',
      phone: params.phone?.trim() || '',
      teamId,
      teamName: teamName.trim(),
      teamLeaderUid,
      members: allMembers,
      matchId: freshMatchData.id,
      matchNumber: freshMatchData.matchNumber,
      matchName: freshMatchData.name || `Qualifier Match #${freshMatchData.matchNumber}`,
      seatNumber: assignedTeamSlot,
      paymentStatus: isPaid ? 'PENDING' : (isManual ? 'PENDING' : 'VERIFIED'),
      paymentMethod,
      entryFeePaid,
      paymentTransactionId: utr,
      utrNumber: utr,
      paymentNotes: isPaid ? 'Submitted for Admin Manual Confirmation' : (isManual ? 'Submitted for Admin Manual Confirmation' : 'Free Entry Verified'),
      createdAt: now,
      verifiedAt: isPaid ? undefined : (isManual ? undefined : now),
      verifiedBy: isPaid ? undefined : (isManual ? undefined : (entryType === 'FREE_ADS' ? 'REWARDED_AD_VERIFIED' : 'FREE_ENTRY_SYSTEM')),
    };

    transaction.set(existingRegRef, sanitizeForFirestore(newRegistration));
    return newRegistration;
  });

  return registration;
}

export function listenUserRegistrations(
  userId: string, 
  callback: (registrations: Registration[]) => void
): () => void {
  const q = query(
    collection(db, 'registrations'),
    where('playerId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: Registration[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Registration);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to user registrations:', err);
  });
}

export function listenTournamentRegistrations(
  tournamentId: string,
  callback: (registrations: Registration[]) => void
): () => void {
  const q = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: Registration[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Registration);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to tournament registrations:', err);
  });
}

export function listenMatchRegistrations(
  matchId: string,
  callback: (registrations: Registration[]) => void
): () => void {
  const q = query(
    collection(db, 'registrations'),
    where('matchId', '==', matchId),
    orderBy('seatNumber', 'asc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: Registration[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Registration);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to match registrations:', err);
  });
}

export async function verifyRegistrationPayment(
  registrationId: string, 
  adminName: string
): Promise<void> {
  const docRef = doc(db, 'registrations', registrationId);
  await updateDoc(docRef, sanitizeForFirestore({
    paymentStatus: 'VERIFIED',
    verifiedAt: new Date().toISOString(),
    verifiedBy: adminName || 'Head Administrator',
    updatedAt: new Date().toISOString(),
  }));
}

export async function rejectRegistrationPayment(
  registrationId: string, 
  reason?: string
): Promise<void> {
  const docRef = doc(db, 'registrations', registrationId);
  await updateDoc(docRef, sanitizeForFirestore({
    paymentStatus: 'REJECTED',
    paymentNotes: reason?.trim() || 'Verification failed.',
    updatedAt: new Date().toISOString(),
  }));
}

export async function getAllRegistrations(): Promise<Registration[]> {
  const q = query(collection(db, 'registrations'), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  const list: Registration[] = [];
  snap.forEach((doc) => list.push(doc.data() as Registration));
  return list;
}
