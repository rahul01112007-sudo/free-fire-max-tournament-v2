import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  writeBatch, 
  query, 
  where, 
  orderBy, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { sanitizeForFirestore } from './firestoreUtils';
import { Registration, Tournament } from '../types';

export interface CancelTournamentParams {
  tournamentId: string;
  cancellationReason: string;
  adminName: string;
}

export interface ProcessRefundParams {
  registrationId: string;
  tournamentId: string;
  refundUtr: string;
  refundAmount: number;
  refundUpiId?: string;
  refundNotes?: string;
  adminName: string;
}

/**
 * Checks whether a registration was denied/rejected by the admin (e.g. fake payment / unverified UTR).
 */
export function isRegistrationDenied(reg: Partial<Registration> | null | undefined): boolean {
  if (!reg) return false;
  const status = String(reg.paymentStatus || '').toUpperCase();
  return status === 'REJECTED' || status === 'DENIED';
}

/**
 * Player action: submits or updates their UPI ID for refund transfer on a cancelled tournament.
 */
export async function submitPlayerRefundUpi(
  registrationId: string,
  refundUpiId: string
): Promise<void> {
  if (!registrationId) throw new Error('Registration ID is required.');
  const trimmed = refundUpiId.trim();
  if (!trimmed) throw new Error('Please enter a valid UPI ID (e.g. yourname@okhdfcbank or 9876543210@paytm).');

  const now = new Date().toISOString();
  const regRef = doc(db, 'registrations', registrationId);

  // Check if player registration was denied/rejected for fake payment
  const regSnap = await getDoc(regRef);
  if (regSnap.exists()) {
    const regData = regSnap.data() as Registration;
    if (isRegistrationDenied(regData)) {
      throw new Error('Registration was denied due to fake or unverified payment proof. This entry is not eligible for a refund.');
    }
  }

  await updateDoc(regRef, sanitizeForFirestore({
    refundUpiId: trimmed,
    refundUpiSubmittedAt: now,
    refundStatus: 'PENDING',
    paymentNotes: `Player provided UPI ID for refund payout: ${trimmed}`,
    updatedAt: now,
  }));
}

export interface BatchRefundParams {
  tournamentId: string;
  baseUtrPrefix?: string;
  batchNotes?: string;
  adminName: string;
}

/**
 * Cancels a tournament mid-way and prepares all registered players for refund.
 * Preserves all participant, payment, and UTR history so admins can safely return funds.
 * Skips registrations that were denied/rejected by the admin due to fake payments.
 */
export async function cancelTournamentWithRefunds(params: CancelTournamentParams): Promise<{
  totalRegistrations: number;
  paidRegistrations: number;
  totalRefundAmount: number;
}> {
  const { tournamentId, cancellationReason, adminName } = params;
  if (!tournamentId) throw new Error('Tournament ID is required.');

  // 1. Fetch Tournament Doc
  const tournRef = doc(db, 'tournaments', tournamentId);
  const tournSnap = await getDoc(tournRef);
  if (!tournSnap.exists()) {
    throw new Error('Tournament not found.');
  }
  const tourn = tournSnap.data() as Tournament;

  // 2. Fetch All Registrations for this Tournament
  const regsQuery = query(collection(db, 'registrations'), where('tournamentId', '==', tournamentId));
  const regsSnap = await getDocs(regsQuery);

  let totalRegistrations = 0;
  let paidRegistrations = 0;
  let totalRefundAmount = 0;

  const now = new Date().toISOString();
  const batch = writeBatch(db);

  regsSnap.forEach((regDoc) => {
    totalRegistrations++;
    const reg = regDoc.data() as Registration;

    // Strict Rule: If payment/registration was denied or rejected (e.g. fake payment, invalid UTR),
    // they did NOT pay genuine verified money. They are NOT eligible for a refund.
    if (isRegistrationDenied(reg)) {
      batch.update(regDoc.ref, sanitizeForFirestore({
        refundStatus: 'NONE',
        refundAmount: 0,
        refundNotes: 'Ineligible for refund: Registration was denied by Admin Desk due to unverified or fake payment proof.',
        updatedAt: now,
      }));
      return; // Do NOT count towards paidRegistrations, totalRefundAmount or refundsRequiredCount!
    }

    const isPaid = reg.entryType === 'PAID_IN_GAME' || (reg.entryFeePaid && reg.entryFeePaid > 0) || reg.paymentMethod !== 'FREE';
    const fee = reg.entryFeePaid || (isPaid ? (tourn.entryFee || 0) : 0);

    if (isPaid && fee > 0) {
      paidRegistrations++;
      totalRefundAmount += fee;
      // Mark as pending refund if not already refunded
      if (reg.refundStatus !== 'REFUNDED') {
        batch.update(regDoc.ref, sanitizeForFirestore({
          refundStatus: 'PENDING',
          refundAmount: fee,
          paymentNotes: `Tournament cancelled: ${cancellationReason}. Refund pending.`,
          updatedAt: now,
        }));
      }
    } else {
      // Free / Ad-based entry: automatically mark restored
      batch.update(regDoc.ref, sanitizeForFirestore({
        refundStatus: 'REFUNDED',
        refundAmount: 0,
        refundNotes: 'Tournament cancelled by admin. Free ad pass restored to player.',
        refundedAt: now,
        refundedBy: adminName || 'Admin Desk',
        updatedAt: now,
      }));
    }
  });

  // 3. Update Tournament Document
  const refundStatus = paidRegistrations > 0 ? 'PENDING' : 'COMPLETED';
  batch.update(tournRef, sanitizeForFirestore({
    status: 'CANCELLED',
    cancellationReason: cancellationReason.trim() || 'Tournament cancelled mid-way by admin without completing.',
    cancelledAt: now,
    cancelledBy: adminName || 'Admin Desk',
    refundStatus,
    refundsRequiredCount: paidRegistrations,
    refundsCompletedCount: 0,
    totalRefundAmount,
    updatedAt: now,
  }));

  await batch.commit();

  return {
    totalRegistrations,
    paidRegistrations,
    totalRefundAmount,
  };
}

/**
 * Admin action: records an individual player's refund with exact UTR and notes.
 */
export async function processPlayerRefund(params: ProcessRefundParams): Promise<void> {
  const { registrationId, tournamentId, refundUtr, refundAmount, refundNotes, adminName } = params;
  if (!registrationId) throw new Error('Registration ID is required.');
  if (!refundUtr || !refundUtr.trim()) throw new Error('Refund UTR / Transaction Reference ID is required.');

  const now = new Date().toISOString();
  const regRef = doc(db, 'registrations', registrationId);

  const updatePayload: Record<string, any> = {
    paymentStatus: 'REFUNDED',
    refundStatus: 'REFUNDED',
    refundUtr: refundUtr.trim(),
    refundAmount: Number(refundAmount) || 0,
    refundNotes: refundNotes?.trim() || 'Refund sent via UPI to registered player.',
    refundedAt: now,
    refundedBy: adminName || 'Admin Desk',
    updatedAt: now,
  };
  if (params.refundUpiId && params.refundUpiId.trim()) {
    updatePayload.refundUpiId = params.refundUpiId.trim();
  }

  await updateDoc(regRef, sanitizeForFirestore(updatePayload));

  // Re-check tournament refund totals
  if (tournamentId) {
    try {
      const regsQuery = query(collection(db, 'registrations'), where('tournamentId', '==', tournamentId));
      const snap = await getDocs(regsQuery);

      let totalPaid = 0;
      let completedRefunds = 0;

      snap.forEach((d) => {
        const reg = d.data() as Registration;
        const isPaid = reg.entryType === 'PAID_IN_GAME' || (reg.entryFeePaid && reg.entryFeePaid > 0) || reg.paymentMethod !== 'FREE';
        if (isPaid && (reg.entryFeePaid || 0) > 0) {
          totalPaid++;
          if (reg.refundStatus === 'REFUNDED') {
            completedRefunds++;
          }
        }
      });

      const tournRef = doc(db, 'tournaments', tournamentId);
      const isAllDone = totalPaid > 0 && completedRefunds >= totalPaid;

      await updateDoc(tournRef, sanitizeForFirestore({
        refundsRequiredCount: totalPaid,
        refundsCompletedCount: completedRefunds,
        refundStatus: isAllDone ? 'COMPLETED' : completedRefunds > 0 ? 'PARTIAL' : 'PENDING',
        updatedAt: now,
      }));
    } catch (e) {
      console.warn('Could not update tournament aggregate refund status:', e);
    }
  }
}

/**
 * Batch refunds all remaining pending players for a cancelled tournament.
 */
export async function batchRefundTournamentPlayers(params: BatchRefundParams): Promise<number> {
  const { tournamentId, baseUtrPrefix, batchNotes, adminName } = params;
  if (!tournamentId) throw new Error('Tournament ID is required.');

  const regsQuery = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId)
  );
  const snap = await getDocs(regsQuery);

  const now = new Date().toISOString();
  const batch = writeBatch(db);
  let count = 0;

  snap.forEach((d) => {
    const reg = d.data() as Registration;
    // Skip registrations that were denied / rejected for fake payment
    if (isRegistrationDenied(reg)) {
      return;
    }

    if (reg.refundStatus !== 'REFUNDED') {
      count++;
      const fee = reg.entryFeePaid || 0;
      const utr = baseUtrPrefix?.trim() 
        ? `${baseUtrPrefix.trim()}-${reg.seatNumber}` 
        : `UPI-REFUND-${Date.now()}-${reg.seatNumber}`;

      batch.update(d.ref, sanitizeForFirestore({
        paymentStatus: 'REFUNDED',
        refundStatus: 'REFUNDED',
        refundUtr: utr,
        refundAmount: fee,
        refundNotes: batchNotes?.trim() || 'Batch refund issued by Admin Desk via UPI.',
        refundedAt: now,
        refundedBy: adminName || 'Admin Desk',
        updatedAt: now,
      }));
    }
  });

  const tournRef = doc(db, 'tournaments', tournamentId);
  batch.update(tournRef, sanitizeForFirestore({
    refundStatus: 'COMPLETED',
    refundsCompletedCount: count,
    updatedAt: now,
  }));

  await batch.commit();
  return count;
}

/**
 * Realtime listener for tournament registrations for the Refund Desk.
 */
export function listenTournamentRegistrationsForRefund(
  tournamentId: string,
  callback: (registrations: Registration[]) => void
): () => void {
  const q = query(
    collection(db, 'registrations'),
    where('tournamentId', '==', tournamentId),
    orderBy('seatNumber', 'asc')
  );

  return onSnapshot(q, (snapshot) => {
    const list: Registration[] = [];
    snapshot.forEach((doc) => {
      list.push(doc.data() as Registration);
    });
    callback(list);
  }, (err) => {
    console.error('Error listening to refund registrations:', err);
  });
}
