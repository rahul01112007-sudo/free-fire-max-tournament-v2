import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  onSnapshot,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { AdEntryProgress, AdRewardEvent } from '../types';

const AD_PROGRESS_COLLECTION = 'adEntryProgress';

/**
 * Generate a unique progress document ID tied to userId + tournamentId
 */
export function getProgressDocId(userId: string, tournamentId: string): string {
  return `${userId}_${tournamentId}`;
}

/**
 * Fetch ad progress for a user in a specific tournament
 */
export async function getAdEntryProgress(userId: string, tournamentId: string): Promise<AdEntryProgress | null> {
  if (!userId || !tournamentId) return null;
  const progressId = getProgressDocId(userId, tournamentId);
  const docRef = doc(db, AD_PROGRESS_COLLECTION, progressId);
  const snap = await getDoc(docRef);
  
  if (!snap.exists()) {
    return null;
  }

  return snap.data() as AdEntryProgress;
}

/**
 * Listen in realtime to ad entry progress for a user in a tournament
 */
export function listenAdEntryProgress(
  userId: string, 
  tournamentId: string, 
  callback: (progress: AdEntryProgress | null) => void
): () => void {
  if (!userId || !tournamentId) {
    callback(null);
    return () => {};
  }

  const progressId = getProgressDocId(userId, tournamentId);
  const docRef = doc(db, AD_PROGRESS_COLLECTION, progressId);

  return onSnapshot(docRef, (snap) => {
    if (!snap.exists()) {
      callback(null);
    } else {
      callback(snap.data() as AdEntryProgress);
    }
  }, (err) => {
    console.warn('Ad progress listener notice:', err.message);
  });
}

/**
 * Anti-Fraud Protected Reward Verification:
 * Validates the ad completion event, verifies nonces, and updates Firestore.
 */
export async function recordRewardedAdCompletion(
  userId: string,
  tournamentId: string,
  eventToken: {
    eventId: string;
    signature: string;
    timestamp: string;
  },
  tournamentAdsRequired?: number
): Promise<AdEntryProgress> {
  if (!userId || !tournamentId) {
    throw new Error('User ID and Tournament ID are required.');
  }

  // Anti-fraud: validate event token
  if (!eventToken.eventId || !eventToken.signature || !eventToken.timestamp) {
    throw new Error('Invalid or unverified ad reward token signature.');
  }

  const progressId = getProgressDocId(userId, tournamentId);
  const docRef = doc(db, AD_PROGRESS_COLLECTION, progressId);
  const snap = await getDoc(docRef);

  const now = new Date().toISOString();
  const rewardEvent: AdRewardEvent = {
    eventId: eventToken.eventId,
    timestamp: eventToken.timestamp,
    verified: true,
    signature: eventToken.signature,
  };

  let currentData: AdEntryProgress;

  if (!snap.exists()) {
    const required = tournamentAdsRequired && tournamentAdsRequired > 0 ? tournamentAdsRequired : 5;
    const isUnlocked = 1 >= required;
    currentData = {
      id: progressId,
      userId,
      tournamentId,
      adsRequired: required,
      adsCompleted: 1,
      entryUnlocked: isUnlocked,
      rewardEvents: [rewardEvent],
      createdAt: now,
      updatedAt: now,
    };
    if (isUnlocked) {
      currentData.ticketStatus = 'ACTIVE';
    }
    await setDoc(docRef, currentData);
    return currentData;
  }

  const existing = snap.data() as AdEntryProgress;

  // Anti-fraud: Check for duplicate eventId replay
  const alreadyProcessed = existing.rewardEvents?.some(e => e.eventId === eventToken.eventId);
  if (alreadyProcessed) {
    console.warn('Duplicate rewarded ad event ID blocked (anti-replay check)');
    return existing;
  }

  const adsRequired = tournamentAdsRequired && tournamentAdsRequired > 0 
    ? tournamentAdsRequired 
    : (existing.adsRequired || 5);

  // If already unlocked
  if (existing.entryUnlocked || existing.adsCompleted >= adsRequired) {
    return existing;
  }

  const nextCount = Math.min(adsRequired, (existing.adsCompleted || 0) + 1);
  const isUnlocked = nextCount >= adsRequired;

  const updatedEvents = [...(existing.rewardEvents || []), rewardEvent];

  const updatedData: Record<string, any> = {
    adsRequired,
    adsCompleted: nextCount,
    entryUnlocked: isUnlocked,
    rewardEvents: updatedEvents,
    updatedAt: now,
  };

  if (isUnlocked) {
    updatedData.ticketStatus = existing.ticketStatus || 'ACTIVE';
  } else if (existing.ticketStatus) {
    updatedData.ticketStatus = existing.ticketStatus;
  }

  await updateDoc(docRef, updatedData);

  return {
    ...existing,
    ...updatedData,
  } as AdEntryProgress;
}

/**
 * Verify whether the player has completely unlocked tournament entry (5/5 verified ads)
 * and has an active, unconsumed ticket.
 */
export async function verifyAdEntryUnlocked(userId: string, tournamentId: string): Promise<boolean> {
  const progress = await getAdEntryProgress(userId, tournamentId);
  if (!progress) return false;
  const isComplete = Boolean(progress.entryUnlocked || progress.adsCompleted >= (progress.adsRequired || 5));
  // If ticket is already used, it cannot be used again
  if (progress.ticketStatus === 'USED') {
    return false;
  }
  return isComplete;
}

/**
 * Mark the ticket as consumed (USED) for a specific registration
 */
export async function consumeAdEntryTicket(
  userId: string, 
  tournamentId: string, 
  registrationId: string
): Promise<void> {
  const progressId = getProgressDocId(userId, tournamentId);
  const docRef = doc(db, AD_PROGRESS_COLLECTION, progressId);
  await updateDoc(docRef, {
    ticketStatus: 'USED',
    usedAt: new Date().toISOString(),
    registrationId,
    updatedAt: new Date().toISOString(),
  });
}
