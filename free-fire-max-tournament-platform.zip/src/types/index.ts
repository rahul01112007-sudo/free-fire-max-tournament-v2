export type UserRole = 'player' | 'admin';
export type UserStatus = 'active' | 'banned' | 'suspended';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  status: UserStatus;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: string;
  bannedBy?: string;
  unbannedAt?: string;
  createdAt: string;
  freeFireUid?: string;
  ign?: string; // In-Game Name
  phone?: string;
  avatarUrl?: string;
  deviceType?: 'MOBILE' | 'EMULATOR';
}

export type TournamentFormat = 'SOLO' | 'SQUAD';
export type TournamentStatus = 'UPCOMING' | 'REGISTRATION_OPEN' | 'REGISTRATION_CLOSED' | 'ONGOING' | 'COMPLETED' | 'CANCELLED';
export type TournamentEntryType = 'FREE_ADS' | 'PAID_IN_GAME' | 'FREE_IN_GAME' | 'PAID_IN_GAME_REWARD' | 'FREE_IN_GAME_REWARD' | 'PAID';
export type RewardCurrency = 'DIAMONDS' | 'INR' | 'VOUCHER' | 'CUSTOM';

export type PrizeType = 
  | 'FREE FIRE DIAMONDS'
  | 'IN_GAME_DIAMONDS'
  | 'AMAZON GIFT CARD'
  | 'GOOGLE PLAY GIFT CARD'
  | 'GOOGLE PLAY REDEEM CODE'
  | 'FLIPKART GIFT CARD'
  | 'FLIPKART VOUCHER'
  | 'OTHER GIFT CARD'
  | 'CUSTOM PRIZE'
  | 'CUSTOM SPONSOR PRIZE';

export interface DiamondPackage {
  id: string;
  diamonds: number;
  label: string;
  badge?: string;
}

export const FREE_FIRE_DIAMOND_PACKAGES: DiamondPackage[] = [
  { id: 'dia_100', diamonds: 100, label: '100 Diamonds' },
  { id: 'dia_210', diamonds: 210, label: '210 Diamonds' },
  { id: 'dia_310', diamonds: 310, label: '310 Diamonds' },
  { id: 'dia_520', diamonds: 520, label: '520 Diamonds', badge: 'POPULAR' },
  { id: 'dia_530', diamonds: 530, label: '530 Diamonds' },
  { id: 'dia_1060', diamonds: 1060, label: '1060 Diamonds', badge: 'BEST VALUE' },
  { id: 'dia_1080', diamonds: 1080, label: '1080 Diamonds' },
  { id: 'dia_2180', diamonds: 2180, label: '2180 Diamonds', badge: 'PRO TIER' },
  { id: 'dia_2200', diamonds: 2200, label: '2200 Diamonds' },
  { id: 'dia_5600', diamonds: 5600, label: '5600 Diamonds', badge: 'MEGA' },
  { id: 'dia_11500', diamonds: 11500, label: '11500 Diamonds', badge: 'CHAMPION' },
];

export interface PrizePosition {
  rank?: number; // 1, 2, 3...
  position: number; // 1, 2, 3...
  label: string;
  amount: number;
  prizeType?: PrizeType;
  diamondPackageId?: string;
  diamondPackageLabel?: string;
  giftCardType?: string;
  customPrizeDetails?: string;
}

export interface PrizeDistribution {
  first: number;
  second: number;
  third: number;
  fourth: number;
  fifth: number;
}

export const DEFAULT_SOLO_PRIZES: PrizeDistribution = {
  first: 4000,
  second: 2000,
  third: 1000,
  fourth: 600,
  fifth: 400,
};

export const DEFAULT_SQUAD_PRIZES: PrizeDistribution = {
  first: 3500,
  second: 1800,
  third: 900,
  fourth: 500,
  fifth: 300,
};

export const DEFAULT_DIAMOND_SOLO_PRIZES: PrizeDistribution = {
  first: 1060,
  second: 520,
  third: 310,
  fourth: 210,
  fifth: 100,
};

export const DEFAULT_DIAMOND_SQUAD_PRIZES: PrizeDistribution = {
  first: 2180,
  second: 1060,
  third: 520,
  fourth: 310,
  fifth: 210,
};

/**
 * Normalizes entry type to canonical standard values.
 */
export function normalizeEntryType(entryType?: string, entryFee?: number): 'FREE_ADS' | 'PAID_IN_GAME' | 'FREE_IN_GAME' {
  if (!entryType) {
    return (entryFee && entryFee > 0) ? 'PAID_IN_GAME' : 'FREE_ADS';
  }
  const upper = String(entryType).toUpperCase();
  if (upper === 'PAID_IN_GAME' || upper === 'PAID_IN_GAME_REWARD' || upper === 'PAID') {
    return 'PAID_IN_GAME';
  }
  if (upper === 'FREE_IN_GAME' || upper === 'FREE_IN_GAME_REWARD') {
    return 'FREE_IN_GAME';
  }
  return 'FREE_ADS';
}

/**
 * Normalizes prize/reward type to canonical standard values.
 */
export function normalizeRewardType(rewardType?: string, prizeType?: string): PrizeType {
  const target = rewardType || prizeType;
  if (!target) return 'FREE FIRE DIAMONDS';
  const upper = String(target).toUpperCase().trim();
  if (upper === 'FREE FIRE DIAMONDS' || upper === 'FREE_FIRE_DIAMONDS' || upper === 'IN_GAME_DIAMONDS' || upper === 'DIAMONDS') {
    return 'FREE FIRE DIAMONDS';
  }
  if (upper.includes('AMAZON')) return 'AMAZON GIFT CARD';
  if (upper.includes('GOOGLE PLAY') || upper.includes('GOOGLE_PLAY')) {
    return upper.includes('CODE') ? 'GOOGLE PLAY REDEEM CODE' : 'GOOGLE PLAY GIFT CARD';
  }
  if (upper.includes('FLIPKART')) {
    return upper.includes('VOUCHER') ? 'FLIPKART VOUCHER' : 'FLIPKART GIFT CARD';
  }
  if (upper.includes('SPONSOR')) return 'CUSTOM SPONSOR PRIZE';
  if (upper.includes('CUSTOM')) return 'CUSTOM PRIZE';
  return target as PrizeType;
}

export function isDiamondPrizeType(prizeType?: PrizeType | string): boolean {
  if (!prizeType) return false;
  const upper = String(prizeType).toUpperCase().trim();
  return (
    upper === 'FREE FIRE DIAMONDS' ||
    upper === 'FREE_FIRE_DIAMONDS' ||
    upper === 'IN_GAME_DIAMONDS' ||
    upper === 'DIAMONDS'
  );
}

export function getRewardCurrency(prizeType?: PrizeType | string): RewardCurrency {
  if (isDiamondPrizeType(prizeType)) return 'DIAMONDS';
  if (prizeType === 'CUSTOM PRIZE' || prizeType === 'CUSTOM SPONSOR PRIZE') return 'CUSTOM';
  if (
    prizeType === 'AMAZON GIFT CARD' ||
    prizeType === 'GOOGLE PLAY REDEEM CODE' ||
    prizeType === 'GOOGLE PLAY GIFT CARD' ||
    prizeType === 'FLIPKART VOUCHER' ||
    prizeType === 'FLIPKART GIFT CARD' ||
    prizeType === 'OTHER GIFT CARD'
  ) return 'VOUCHER';
  return 'INR';
}

/**
 * Returns dynamic tournament entry badge text based on exact saved tournament config.
 * - FREE_ADS: "FREE ENTRY • WATCH 5 ADS"
 * - PAID_IN_GAME: "₹20 PAID ENTRY" (or configured fee)
 * - FREE_IN_GAME: "FREE ENTRY • IN-GAME REWARD"
 */
export function formatTournamentEntryBadge(t?: Partial<Tournament> | null): string {
  if (!t) return 'FREE ENTRY • WATCH 5 ADS';
  const norm = normalizeEntryType(t.entryType, t.entryFee);
  if (norm === 'PAID_IN_GAME') {
    return `₹${t.entryFee || 0} PAID ENTRY`;
  }
  if (norm === 'FREE_IN_GAME') {
    return 'FREE ENTRY • IN-GAME REWARD';
  }
  return `FREE ENTRY • WATCH ${t.adsRequired || 5} ADS`;
}

/**
 * Returns dynamic entry fee badge text based on exact saved tournament config.
 * - FREE_ADS: "Free (5 Ads)"
 * - PAID_IN_GAME: "Paid ₹20"
 * - FREE_IN_GAME: "Free Entry"
 */
export function formatEntryFeeDisplay(t?: Partial<Tournament> | null): string {
  if (!t) return 'Free (5 Ads)';
  const norm = normalizeEntryType(t.entryType, t.entryFee);
  if (norm === 'PAID_IN_GAME') {
    return `Paid ₹${t.entryFee || 0}`;
  }
  if (norm === 'FREE_IN_GAME') {
    return 'Free Entry';
  }
  return `Free (${t.adsRequired || 5} Ads)`;
}

/**
 * Returns the exact entry type used for THAT specific tournament registration record.
 * - Free tournament -> "Free (5 Ads)"
 * - Paid ₹20 tournament -> "Paid ₹20"
 * - Paid ₹50 tournament -> "Paid ₹50"
 * - Free In-Game Reward tournament -> "Free Entry"
 */
export function formatRegistrationEntryTicket(reg?: Partial<Registration> | null, tourn?: Partial<Tournament> | null): string {
  if (!reg && !tourn) return 'Free (5 Ads)';
  const entryType = reg?.entryType || tourn?.entryType;
  const entryFee = reg?.entryFeePaid || tourn?.entryFee;
  const norm = normalizeEntryType(entryType, entryFee);
  if (norm === 'PAID_IN_GAME') {
    return `Paid ₹${entryFee || 0}`;
  }
  if (norm === 'FREE_IN_GAME') {
    return 'Free Entry';
  }
  const ads = tourn?.adsRequired || 5;
  return `Free (${ads} Ads)`;
}

export function getPrizePoolLabel(prizeType?: PrizeType | string): string {
  return isDiamondPrizeType(prizeType) ? 'REWARD POOL' : 'PRIZE POOL';
}

/**
 * Formats reward or prize amount cleanly according to the selected Reward Type.
 * If Diamonds: "💎 1,060 Diamonds" or "💎 1,060" (NEVER adds ₹ to Diamonds).
 * If Amazon Gift Card: "₹1,000 Amazon Gift Card" or "₹1,000"
 * If Google Play: "₹1,000 Google Play Code" or "₹1,000"
 * If Flipkart: "₹1,000 Flipkart Voucher" or "₹1,000"
 */
export function formatPrizeAmount(amount: number, prizeType?: PrizeType | string, withLabel = false): string {
  const num = Number(amount) || 0;
  if (isDiamondPrizeType(prizeType)) {
    return withLabel ? `💎 ${num.toLocaleString()} Diamonds` : `💎 ${num.toLocaleString()}`;
  }
  if (prizeType === 'AMAZON GIFT CARD') {
    return withLabel ? `₹${num.toLocaleString()} Amazon Gift Card` : `₹${num.toLocaleString()}`;
  }
  if (prizeType === 'GOOGLE PLAY GIFT CARD' || prizeType === 'GOOGLE PLAY REDEEM CODE') {
    return withLabel ? `₹${num.toLocaleString()} Google Play Redeem Code` : `₹${num.toLocaleString()}`;
  }
  if (prizeType === 'FLIPKART GIFT CARD' || prizeType === 'FLIPKART VOUCHER') {
    return withLabel ? `₹${num.toLocaleString()} Flipkart Voucher` : `₹${num.toLocaleString()}`;
  }
  if (prizeType === 'CUSTOM PRIZE' || prizeType === 'CUSTOM SPONSOR PRIZE') {
    return withLabel ? (num > 0 ? `₹${num.toLocaleString()} Sponsor Reward` : 'Sponsor Reward') : `₹${num.toLocaleString()}`;
  }
  return `₹${num.toLocaleString()}`;
}

export function formatRewardDisplay(position: PrizePosition, defaultPrizeType?: PrizeType): string {
  const pType = position.prizeType || defaultPrizeType || 'FREE FIRE DIAMONDS';
  const num = Number(position.amount) || 0;
  if (isDiamondPrizeType(pType)) {
    return `💎 ${num.toLocaleString()} Diamonds`;
  }
  if (pType === 'AMAZON GIFT CARD') {
    return `₹${num.toLocaleString()} Amazon Gift Card`;
  }
  if (pType === 'GOOGLE PLAY GIFT CARD' || pType === 'GOOGLE PLAY REDEEM CODE') {
    return `₹${num.toLocaleString()} Google Play Redeem Code`;
  }
  if (pType === 'FLIPKART GIFT CARD' || pType === 'FLIPKART VOUCHER') {
    return `₹${num.toLocaleString()} Flipkart Voucher`;
  }
  if (pType === 'OTHER GIFT CARD') {
    return `₹${num.toLocaleString()} Gift Card`;
  }
  if (pType === 'CUSTOM PRIZE' || pType === 'CUSTOM SPONSOR PRIZE') {
    return position.customPrizeDetails || `₹${num.toLocaleString()} Custom Sponsor Prize`;
  }
  return `₹${num.toLocaleString()}`;
}

export const DEFAULT_PRIZE_WEIGHTS: Record<number, number[]> = {
  1: [1.0],
  2: [0.60, 0.40],
  3: [0.50, 0.30, 0.20],
  4: [0.45, 0.25, 0.18, 0.12],
  5: [0.40, 0.25, 0.15, 0.12, 0.08],
  6: [0.36, 0.22, 0.16, 0.12, 0.08, 0.06],
  7: [0.34, 0.20, 0.15, 0.11, 0.08, 0.07, 0.05],
  8: [0.32, 0.18, 0.14, 0.11, 0.09, 0.07, 0.05, 0.04],
  9: [0.30, 0.18, 0.13, 0.10, 0.08, 0.07, 0.06, 0.05, 0.03],
  10: [0.28, 0.17, 0.12, 0.10, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03],
};

/**
 * Calculates a deterministic prize distribution for a given total value and number of positions.
 * Guarantees that the sum of all positions exactly equals totalPrizeValue.
 */
export function calculateDeterministicPrizeDistribution(
  totalPrizeValue: number,
  positionCount: number,
  prizeType: PrizeType = 'AMAZON GIFT CARD'
): PrizePosition[] {
  const count = Math.max(1, Math.min(10, Math.floor(positionCount || 1)));
  const total = Math.max(1, Math.floor(totalPrizeValue || 0));

  let rawWeights = DEFAULT_PRIZE_WEIGHTS[count];
  if (!rawWeights) {
    // Generate exponential decay weights if count > 10
    rawWeights = [];
    let sum = 0;
    for (let i = 0; i < count; i++) {
      const w = Math.pow(0.7, i);
      rawWeights.push(w);
      sum += w;
    }
    rawWeights = rawWeights.map((w) => w / sum);
  }

  const weightSum = rawWeights.reduce((acc, w) => acc + w, 0);
  const normalizedWeights = rawWeights.map((w) => w / weightSum);

  const amounts: number[] = [];
  let allocated = 0;

  for (let i = 0; i < count; i++) {
    if (i === count - 1) {
      // Last element gets exact remainder
      const remainder = total - allocated;
      amounts.push(Math.max(1, remainder));
    } else {
      const amt = Math.max(1, Math.round(total * normalizedWeights[i]));
      amounts.push(amt);
      allocated += amt;
    }
  }

  // Adjust difference to rank 1 (or top ranks) to ensure exact sum === totalPrizeValue
  const currentSum = amounts.reduce((acc, a) => acc + a, 0);
  const diff = total - currentSum;
  if (diff !== 0) {
    amounts[0] = Math.max(1, amounts[0] + diff);
  }

  return amounts.map((amt, idx) => {
    const rank = idx + 1;
    let label = `${rank}th Place`;
    if (rank === 1) label = '1st Place';
    else if (rank === 2) label = '2nd Place';
    else if (rank === 3) label = '3rd Place';

    return {
      rank,
      position: rank,
      label,
      amount: amt,
      prizeType,
    };
  });
}

export function getTournamentPrizePositions(t?: Partial<Tournament> | null): PrizePosition[] {
  if (!t) {
    return calculateDeterministicPrizeDistribution(5000, 3, 'AMAZON GIFT CARD');
  }

  // 1. If active prizePositions array exists on the tournament
  if (t.prizePositions && Array.isArray(t.prizePositions) && t.prizePositions.length > 0) {
    const validPositions = t.prizePositions
      .filter((p) => Number(p.amount) > 0)
      .map((p, idx) => ({
        rank: p.rank || p.position || idx + 1,
        position: p.position || p.rank || idx + 1,
        label: p.label || `${p.position || idx + 1}th Place`,
        amount: Number(p.amount) || 0,
        prizeType: p.prizeType || t.prizeType || 'AMAZON GIFT CARD',
      }))
      .sort((a, b) => a.position - b.position);

    if (validPositions.length > 0) {
      return validPositions;
    }
  }

  // 2. If prizeDistribution legacy object exists
  if (t.prizeDistribution) {
    const list: PrizePosition[] = [];
    if (t.prizeDistribution.first > 0) {
      list.push({ rank: 1, position: 1, label: '1st Place', amount: t.prizeDistribution.first, prizeType: t.prizeType });
    }
    if (t.prizeDistribution.second > 0) {
      list.push({ rank: 2, position: 2, label: '2nd Place', amount: t.prizeDistribution.second, prizeType: t.prizeType });
    }
    if (t.prizeDistribution.third > 0) {
      list.push({ rank: 3, position: 3, label: '3rd Place', amount: t.prizeDistribution.third, prizeType: t.prizeType });
    }
    if (t.prizeDistribution.fourth && t.prizeDistribution.fourth > 0) {
      list.push({ rank: 4, position: 4, label: '4th Place', amount: t.prizeDistribution.fourth, prizeType: t.prizeType });
    }
    if (t.prizeDistribution.fifth && t.prizeDistribution.fifth > 0) {
      list.push({ rank: 5, position: 5, label: '5th Place', amount: t.prizeDistribution.fifth, prizeType: t.prizeType });
    }
    if (list.length > 0) return list;
  }

  // 3. Fallback dynamically calculated from total prize value
  const total = Number(t.totalPrizeValue) || Number(t.prizePool) || 5000;
  const count = Number(t.prizePositionCount) || 3;
  return calculateDeterministicPrizeDistribution(total, count, t.prizeType || 'AMAZON GIFT CARD');
}

export function getTournamentPrizeDistribution(t?: Partial<Tournament> | null): PrizeDistribution {
  const positions = getTournamentPrizePositions(t);
  const p1 = positions.find(p => p.position === 1)?.amount || 0;
  const p2 = positions.find(p => p.position === 2)?.amount || 0;
  const p3 = positions.find(p => p.position === 3)?.amount || 0;
  const p4 = positions.find(p => p.position === 4)?.amount || 0;
  const p5 = positions.find(p => p.position === 5)?.amount || 0;
  return { first: p1, second: p2, third: p3, fourth: p4, fifth: p5 };
}

export interface PrizeSnapshot {
  totalPrizeValue: number;
  prizeType: PrizeType;
  prizePositionCount: number;
  prizePositions: PrizePosition[];
  finalizedAt: string;
}

export interface Tournament {
  id: string;
  title: string;
  game: string; // 'FREE FIRE MAX'
  format: TournamentFormat;
  entryType?: TournamentEntryType; // 'FREE_ADS' | 'PAID_IN_GAME' | 'FREE_IN_GAME'
  maxParticipants: number; // Total players (Solo) or Total teams (Squad)
  participantsPerMatch: number; // e.g. 48 for Solo, 12 for Squad
  qualifiersCount: number; // e.g. 2, 4, 11
  advancingPerMatch: number; // e.g. 3
  entryFee: number; // Entry fee in ₹ (0 for FREE entry)
  adsRequired: number; // default 5 (for FREE_ADS)
  prizeType: PrizeType;
  rewardType?: PrizeType; // Alias for prizeType
  rewardCurrency?: RewardCurrency; // 'DIAMONDS' | 'INR' | 'VOUCHER' | 'CUSTOM'
  rewardAmount?: number; // Total rewards amount (Diamonds or INR)
  totalPrizeValue: number; // Total prize pool / Diamonds (e.g. 50, 100, 500, 1000, 5000, 10000)
  prizePool: number; // Alias for compatibility with totalPrizeValue
  prizePositionCount: number; // e.g. 1 to 10
  prizePositions: PrizePosition[]; // Custom winner positions (contains ONLY active >0 positions)
  prizeDistribution: PrizeDistribution; // 1st - 5th compatibility
  prizeSnapshot?: PrizeSnapshot;
  nonCashDisclaimer?: string;
  diamondRewardUnit?: string;
  firstPrize: number;
  secondPrize: number;
  thirdPrize: number;
  fourthPrize?: number;
  fifthPrize?: number;
  startDate: string;
  startTime: string;
  bannerUrl?: string;
  status: TournamentStatus;
  description: string;
  rules: string;
  playersPerQualifier: number; // alias for participantsPerMatch
  finalSlots: number;
  registeredCount: number;
  createdAt: string;
  createdBy: string;
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  refundStatus?: 'NONE' | 'PENDING' | 'PARTIAL' | 'COMPLETED';
  refundsRequiredCount?: number;
  refundsCompletedCount?: number;
  totalRefundAmount?: number;
}

export type MatchStage = 'QUALIFIER' | 'SEMIFINAL' | 'FINAL';
export type MatchStatus = 'WAITING' | 'ACTIVE' | 'FULL' | 'LOCKED' | 'COMPLETED';

export interface TournamentMatch {
  id: string;
  tournamentId: string;
  matchNumber: number;
  name: string;
  stage: MatchStage;
  matchType?: string;
  capacity: number;
  currentCount: number;
  status: MatchStatus;
  scheduledTime: string;
  roomStatus: 'LOCKED' | 'RELEASED';
  mapName?: string;
  createdAt: string;
}

export type PaymentStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'REFUNDED';
export type RefundStatus = 'NONE' | 'PENDING' | 'REFUNDED';

export interface SquadMember {
  name: string;
  freeFireUid: string;
  ign: string;
  phone?: string;
}

export interface Registration {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  format: TournamentFormat;
  entryType?: TournamentEntryType;
  playerId: string;
  playerName: string;
  freeFireUid: string;
  ign: string;
  phone: string;
  teamId?: string;
  teamName?: string;
  teamLeaderUid?: string;
  members?: SquadMember[];
  matchId: string;
  matchNumber: number;
  matchName: string;
  seatNumber: number;
  paymentStatus: PaymentStatus;
  paymentMethod: 'UPI' | 'FREE' | 'WALLET' | 'ONLINE' | 'CARD' | 'CASH';
  entryFeePaid?: number;
  paymentTransactionId?: string;
  utrNumber: string;
  paymentNotes?: string;
  createdAt: string;
  verifiedAt?: string;
  verifiedBy?: string;
  refundStatus?: RefundStatus;
  refundAmount?: number;
  refundUtr?: string;
  refundedAt?: string;
  refundedBy?: string;
  refundNotes?: string;
  refundUpiId?: string;
  refundUpiSubmittedAt?: string;
}

export interface AdRewardEvent {
  eventId: string;
  timestamp: string;
  verified: boolean;
  signature: string;
}

export interface AdEntryProgress {
  id: string; // `${userId}_${tournamentId}`
  userId: string;
  tournamentId: string;
  adsRequired: number; // 5
  adsCompleted: number; // 0 - 5
  entryUnlocked: boolean;
  ticketStatus?: 'ACTIVE' | 'USED';
  usedAt?: string;
  registrationId?: string;
  rewardEvents: AdRewardEvent[];
  createdAt: string;
  updatedAt: string;
}

export interface RoomCredentials {
  id: string; // usually tournamentId_matchId
  tournamentId: string;
  matchId: string;
  matchName?: string;
  roomId: string;
  roomPassword: string;
  status: 'LOCKED' | 'RELEASED';
  customRules?: string;
  releasedAt?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export type AntiCheatReason = 
  | 'AIMBOT'
  | 'WALLHACK'
  | 'SPEEDHACK'
  | 'NO_RECOIL'
  | 'TEAMING'
  | 'EMULATOR_IN_MOBILE_MATCH'
  | 'MACRO_OR_SCRIPTS'
  | 'OTHER';

export type ReportStatus = 'PENDING' | 'UNDER_REVIEW' | 'BANNED' | 'DISMISSED';

export interface AntiCheatReport {
  id: string;
  reporterUid: string;
  reporterName: string;
  reporterEmail?: string;
  suspectUid?: string;
  suspectIgn: string;
  suspectFfUid: string;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName?: string;
  reason: AntiCheatReason;
  description: string;
  evidenceUrl: string;
  status: ReportStatus;
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  adminNotes?: string;
}

export type RecordingStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type POVType = 'FULL_GAMEPLAY' | 'LAST_ZONES' | 'KILL_MOMENTS' | 'SPEC_PROOF';

export interface MatchRecording {
  id: string;
  playerId: string;
  playerName: string;
  freeFireUid: string;
  ign: string;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName?: string;
  videoUrl: string;
  povType: POVType;
  notes?: string;
  status: RecordingStatus;
  submittedAt: string;
  reviewedAt?: string;
  adminFeedback?: string;
}

export interface ResultWinner {
  rank: number;
  participantId: string; // playerId or teamName
  name: string;
  ign: string;
  ffUid: string;
  kills: number;
  placementPoints: number;
  totalPoints: number;
  qualified: boolean;
  prizeAmount?: number;
  prizeType?: PrizeType;
}

export interface MatchResult {
  id: string;
  tournamentId: string;
  tournamentTitle?: string;
  matchId: string;
  matchName: string;
  stage: MatchStage;
  format: TournamentFormat;
  publishedAt: string;
  publishedBy: string;
  winners: ResultWinner[];
  notes?: string;
}

export type PrizeDeliveryStatus = 
  | 'PENDING'
  | 'PROCESSING'
  | 'DELIVERED'
  | 'FAILED'
  | 'CANCELLED'
  | 'RESULT_UNDER_REVIEW' 
  | 'ANTI_CHEAT_UNDER_REVIEW' 
  | 'ELIGIBLE_FOR_PRIZE' 
  | 'SENT' 
  | 'CLAIMED' 
  | 'HELD_SUSPICIOUS';

export interface PrizeDelivery {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  matchId?: string;
  matchName?: string;
  winnerUid?: string;
  winnerName: string;
  winnerIgn: string;
  winnerFfUid: string;
  winnerEmail?: string;
  winnerPhone?: string;
  prizeRank: number;
  prizeType: PrizeType;
  prizeValue: number;
  diamondPackage?: string;
  diamondPackageId?: string;
  status: PrizeDeliveryStatus;
  giftCardProvider?: string;
  deliveryReference?: string; // Top-up transaction ID or Gift card voucher code
  deliveryDate?: string;
  deliveredAt?: string;
  adminNotes?: string;
  issueReason?: string;
  winnerVerified?: boolean;
  antiCheatCleared?: boolean;
  createdAt: string;
  updatedAt: string;
  deliveredBy?: string;
}

export type SupportCategory = 
  | 'Account Issue'
  | 'Tournament Issue'
  | 'Match/Room Issue'
  | 'Entry/Payment Issue'
  | 'Prize/Reward Issue'
  | 'Cheating Report'
  | 'Technical Problem'
  | 'Other';

export type SupportTicketStatus = 'OPEN' | 'IN REVIEW' | 'RESOLVED' | 'CLOSED';

export interface SupportMessage {
  id: string;
  senderUid: string;
  senderName: string;
  senderRole: 'player' | 'admin';
  message: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string; // Firestore document ID
  ticketId: string; // User-facing ticket code e.g. TICKET-7482
  userId: string;
  playerName: string;
  playerEmail?: string;
  freeFireUid: string;
  category: SupportCategory;
  subject: string;
  message: string;
  tournamentId?: string;
  tournamentTitle?: string;
  matchId?: string;
  matchName?: string;
  status: SupportTicketStatus;
  adminNotes?: string;
  adminResponse?: string;
  assignedAdmin?: string;
  messages: SupportMessage[];
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
}
