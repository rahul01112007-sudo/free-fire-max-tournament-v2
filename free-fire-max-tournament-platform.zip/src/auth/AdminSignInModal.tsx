import React, { useState } from 'react';
import { Shield, Lock, Mail, AlertCircle, KeyRound, CheckCircle2 } from 'lucide-react';
import { Modal } from '../components/Modal';
import { signInUser, signOutUser, resetUserPassword, MASTER_ADMIN_EMAIL } from '../services/authService';
import { useAuth } from '../context/AuthContext';

interface AdminSignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminSignInModal: React.FC<AdminSignInModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [email, setEmail] = useState(MASTER_ADMIN_EMAIL);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetMode, setResetMode] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResetSuccess(null);

    const normalizedEmail = email.toLowerCase().trim();

    if (resetMode) {
      if (!normalizedEmail) {
        setError('Please enter your administrator email address.');
        return;
      }
      try {
        setResetLoading(true);
        await resetUserPassword(normalizedEmail);
        setResetSuccess(`Password reset email sent to ${normalizedEmail}! Please check your inbox (and spam folder) to set a new password, then log in.`);
      } catch (err: any) {
        setError(err.message || 'Failed to send password reset email.');
      } finally {
        setResetLoading(false);
      }
      return;
    }

    if (normalizedEmail !== MASTER_ADMIN_EMAIL.toLowerCase()) {
      setError(`Access Denied: Only the Master Administrator (${MASTER_ADMIN_EMAIL}) has authority to log into the Admin Desk.`);
      return;
    }

    try {
      setLoading(true);
      const { profile } = await signInUser(normalizedEmail, password);

      if (profile.role !== 'admin' || normalizedEmail !== MASTER_ADMIN_EMAIL.toLowerCase()) {
        await signOutUser();
        setError('Access Denied: Master administrator authentication is required.');
        return;
      }

      if (profile.status !== 'active') {
        await signOutUser();
        setError('Your administrator privileges are suspended.');
        return;
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      console.warn('Admin login notice:', err?.message || err);
      setError(err.message || 'Invalid administrator email or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="admin-signin-modal"
      isOpen={isOpen}
      onClose={() => {
        setResetMode(false);
        setError(null);
        setResetSuccess(null);
        onClose();
      }}
      title={resetMode ? 'Reset Administrator Password' : 'Admin Portal Login'}
      subtitle={resetMode ? 'We will send a password reset link to the master administrator email' : 'Master Administrator Desk • Authorized Access Only'}
      maxWidth="md"
    >
      <form id="admin-signin-form" onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div id="admin-signin-error" className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex flex-col gap-2">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{error}</span>
            </div>
            {!resetMode && (
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setResetMode(true);
                }}
                className="self-start text-xs text-amber-300 hover:text-amber-200 underline font-semibold mt-1 cursor-pointer"
              >
                Forgot your password? Send reset email
              </button>
            )}
          </div>
        )}

        {resetSuccess && (
          <div id="admin-reset-success" className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <span className="leading-relaxed">{resetSuccess}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
            Administrator Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              id="admin-email-input"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="rahul01112007@gmail.com"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 focus:ring-1 focus:ring-red-500 text-sm text-white placeholder:text-slate-600 outline-none transition-all"
            />
          </div>
        </div>

        {!resetMode ? (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                Password
              </label>
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setResetSuccess(null);
                  setResetMode(true);
                }}
                className="text-xs text-orange-400 hover:text-orange-300 hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="admin-password-input"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-red-500 focus:ring-1 focus:ring-red-500 text-sm text-white placeholder:text-slate-600 outline-none transition-all"
              />
            </div>
          </div>
        ) : null}

        <div className="pt-2">
          {resetMode ? (
            <div className="space-y-2">
              <button
                id="admin-reset-submit-button"
                type="submit"
                disabled={resetLoading}
                className="w-full py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {resetLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <KeyRound className="w-4 h-4" />
                )}
                {resetLoading ? 'Sending Reset Email...' : 'SEND PASSWORD RESET LINK'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setResetMode(false);
                  setError(null);
                }}
                className="w-full py-2 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                Back to Admin Sign In
              </button>
            </div>
          ) : (
            <button
              id="admin-login-submit-button"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-red-600 via-rose-600 to-orange-600 hover:from-red-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Shield className="w-4 h-4" />
              )}
              {loading ? 'Authenticating Master Admin...' : 'SIGN IN TO MASTER ADMIN DESK'}
            </button>
          )}
        </div>
      </form>
    </Modal>
  );
};
