import React, { useState } from 'react';
import { User, Lock, Mail, Phone, Gamepad2, AlertCircle, Sparkles, LogIn, UserPlus, KeyRound, CheckCircle2 } from 'lucide-react';
import { Modal } from '../components/Modal';
import { registerPlayer, signInUser, resetUserPassword } from '../services/authService';

interface PlayerSignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialMode?: 'signin' | 'signup';
}

export const PlayerSignInModal: React.FC<PlayerSignInModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'signin',
}) => {
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [freeFireUid, setFreeFireUid] = useState('');
  const [ign, setIgn] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResetSuccess(null);

    if (mode === 'forgot') {
      if (!email.trim()) {
        setError('Please provide your email address.');
        return;
      }
      try {
        setLoading(true);
        await resetUserPassword(email);
        setResetSuccess(`Password reset email sent to ${email.trim()}! Follow the link in your inbox to set a new password, then sign in.`);
      } catch (err: any) {
        setError(err.message || 'Failed to send password reset email.');
      } finally {
        setLoading(false);
      }
      return;
    }

    try {
      setLoading(true);

      if (mode === 'signup') {
        if (password.length < 6) {
          setError('Password must be at least 6 characters.');
          setLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError('Passwords do not match.');
          setLoading(false);
          return;
        }

        await registerPlayer({
          name: name.trim(),
          email: email.trim(),
          password,
          freeFireUid: freeFireUid.trim(),
          ign: ign.trim(),
          phone: phone.trim(),
        });
      } else {
        await signInUser(email.trim(), password);
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      console.warn('Auth notice:', err?.message || err);
      setError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="player-auth-modal"
      isOpen={isOpen}
      onClose={() => {
        setMode(initialMode);
        setError(null);
        setResetSuccess(null);
        onClose();
      }}
      title={
        mode === 'forgot'
          ? 'Reset Password'
          : mode === 'signin'
          ? 'Player Sign In'
          : 'Create Player Account'
      }
      subtitle={
        mode === 'forgot'
          ? 'Enter your registered email to receive a password reset link'
          : mode === 'signin'
          ? 'Access your tournament matches, room credentials & results'
          : 'Join Free Fire MAX esports tournaments and compete for prize pools'
      }
      maxWidth="md"
    >
      {/* Tab Switcher */}
      {mode !== 'forgot' && (
        <div className="flex rounded-xl bg-slate-950 p-1 mb-5 border border-slate-800">
          <button
            id="tab-player-signin"
            type="button"
            onClick={() => {
              setMode('signin');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              mode === 'signin'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            SIGN IN
          </button>
          <button
            id="tab-player-signup"
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              mode === 'signup'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            REGISTER ACCOUNT
          </button>
        </div>
      )}

      {error && (
        <div id="player-auth-error" className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs flex flex-col gap-2 mb-4">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{error}</span>
          </div>
          {error.includes('already registered') && (
            <div className="mt-1 pt-2 border-t border-rose-900/50 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setMode('signin');
                }}
                className="text-xs text-orange-400 hover:text-orange-300 underline font-semibold flex items-center gap-1"
              >
                <LogIn className="w-3 h-3" />
                Sign in with this email
              </button>
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setMode('forgot');
                }}
                className="text-xs text-amber-300 hover:text-amber-200 underline font-semibold flex items-center gap-1"
              >
                <KeyRound className="w-3 h-3" />
                Reset Password
              </button>
            </div>
          )}
          {!error.includes('already registered') && mode === 'signin' && (
            <button
              type="button"
              onClick={() => {
                setError(null);
                setMode('forgot');
              }}
              className="self-start text-xs text-amber-300 hover:text-amber-200 underline font-semibold mt-1 flex items-center gap-1"
            >
              <KeyRound className="w-3 h-3" />
              Forgot password? Click here to reset
            </button>
          )}
        </div>
      )}

      {resetSuccess && (
        <div id="player-reset-success" className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-start gap-2.5 mb-4">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
          <span className="leading-relaxed">{resetSuccess}</span>
        </div>
      )}

      <form id="player-auth-form" onSubmit={handleSubmit} className="space-y-3.5">
        {mode === 'signup' && (
          <>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                Full Name <span className="text-orange-500">*</span>
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="player-reg-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  In-Game Name (IGN) <span className="text-orange-500">*</span>
                </label>
                <div className="relative">
                  <Gamepad2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="player-reg-ign"
                    type="text"
                    required
                    value={ign}
                    onChange={(e) => setIgn(e.target.value)}
                    placeholder="e.g. RAhul_VIP99"
                    className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  Free Fire UID <span className="text-orange-500">*</span>
                </label>
                <input
                  id="player-reg-ffuid"
                  type="text"
                  required
                  value={freeFireUid}
                  onChange={(e) => setFreeFireUid(e.target.value)}
                  placeholder="e.g. 1092837465"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                WhatsApp / Phone Number <span className="text-orange-500">*</span>
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="player-reg-phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 9876543210"
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
                />
              </div>
            </div>
          </>
        )}

        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
            Email Address <span className="text-orange-500">*</span>
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              id="player-email-input"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="player@gmail.com"
              className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
            />
          </div>
        </div>

        {mode !== 'forgot' && (
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                Password <span className="text-orange-500">*</span>
              </label>
              {mode === 'signin' && (
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setResetSuccess(null);
                    setMode('forgot');
                  }}
                  className="text-xs text-orange-400 hover:text-orange-300 hover:underline"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="player-password-input"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
              />
            </div>
          </div>
        )}

        {mode === 'signup' && (
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
              Confirm Password <span className="text-orange-500">*</span>
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                id="player-confirm-password-input"
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repeat password"
                className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-orange-500 text-xs text-white placeholder:text-slate-600 outline-none"
              />
            </div>
          </div>
        )}

        <div className="pt-2">
          {mode === 'forgot' ? (
            <div className="space-y-2">
              <button
                id="player-reset-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md shadow-orange-600/30 transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span className="inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <KeyRound className="w-3.5 h-3.5" />
                )}
                {loading ? 'Sending Email...' : 'Send Password Reset Link'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  setError(null);
                }}
                className="w-full py-2 text-xs text-slate-400 hover:text-white transition-colors"
              >
                Back to Sign In
              </button>
            </div>
          ) : (
            <button
              id="player-submit-auth-btn"
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-md shadow-orange-600/30 transition-all flex items-center justify-center gap-2"
            >
              {loading && <span className="inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {loading ? 'Processing...' : mode === 'signin' ? 'Sign In & Enter' : 'Register Player Account'}
            </button>
          )}
        </div>
      </form>
    </Modal>
  );
};
