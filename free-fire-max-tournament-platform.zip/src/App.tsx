import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Gamepad2, 
  Medal, 
  Video, 
  User, 
  Shield, 
  LogIn, 
  LogOut, 
  Flame, 
  Key, 
  ShieldAlert,
  Menu,
  X,
  Headphones,
  LifeBuoy,
  History
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';

// Auth Modals & Pages
import { PlayerSignInModal } from './auth/PlayerSignInModal';
import { AdminLoginPage } from './admin/AdminLoginPage';

// Player Views
import { PlayerTournamentsView } from './player/PlayerTournamentsView';
import { MyMatchView } from './player/MyMatchView';
import { PlayerHistoryView } from './player/PlayerHistoryView';
import { PlayerResultsView } from './player/PlayerResultsView';
import { PlayerRecordingsView } from './player/PlayerRecordingsView';
import { PlayerProfileView } from './player/PlayerProfileView';
import { PlayerSupportView } from './player/PlayerSupportView';

// Ban Screen & Admin Panel
import { BannedPlayerScreen } from './components/BannedPlayerScreen';
import { AdminPanel } from './admin/AdminPanel';

type PlayerTab = 'tournaments' | 'mymatch' | 'history' | 'results' | 'recordings' | 'support' | 'profile';

const MainLayout: React.FC = () => {
  const { currentUser, userProfile, isAdmin, isBanned, signOut } = useAuth();
  
  const [activeTab, setActiveTab] = useState<PlayerTab>('tournaments');
  const [currentRoute, setCurrentRoute] = useState<'PLAYER' | 'ADMIN'>(() => {
    const p = window.location.pathname;
    const h = window.location.hash;
    const s = window.location.search;
    if (p.startsWith('/admin') || h.startsWith('#/admin') || s.includes('route=admin')) {
      return 'ADMIN';
    }
    return 'PLAYER';
  });

  const navigateTo = (route: 'PLAYER' | 'ADMIN', targetPath?: string) => {
    const path = targetPath || (route === 'ADMIN' ? '/admin' : '/');
    try {
      window.history.pushState(null, '', path);
    } catch {
      window.location.hash = path;
    }
    setCurrentRoute(route);
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    const handleLocationChange = () => {
      const p = window.location.pathname;
      const h = window.location.hash;
      const s = window.location.search;
      if (p.startsWith('/admin') || h.startsWith('#/admin') || s.includes('route=admin')) {
        setCurrentRoute('ADMIN');
      } else {
        setCurrentRoute('PLAYER');
      }
    };
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  // Modals
  const [isPlayerSignInOpen, setIsPlayerSignInOpen] = useState(false);
  const [showBannedAppealModal, setShowBannedAppealModal] = useState(false);

  // If on Admin Route (/admin)
  if (currentRoute === 'ADMIN') {
    if (isAdmin) {
      return <AdminPanel onExitToPlayerView={() => navigateTo('PLAYER', '/')} />;
    }
    return (
      <AdminLoginPage
        onLoginSuccess={() => navigateTo('ADMIN', '/admin')}
        onGoToPlayerPortal={() => navigateTo('PLAYER', '/')}
      />
    );
  }

  // If user is banned and not an admin in admin view, LOCK viewport with full-screen overlay
  if (isBanned && !isAdmin) {
    return (
      <div className="relative min-h-screen bg-slate-950 text-white">
        <BannedPlayerScreen
          userProfile={userProfile}
          onSignOut={signOut}
          onOpenSupport={() => setShowBannedAppealModal(true)}
        />

        {/* Appeal / Support Modal for Banned Player */}
        {showBannedAppealModal && (
          <div className="fixed inset-0 z-[10000] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
            <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Headphones className="w-5 h-5 text-orange-400" />
                  Submit Ban Appeal / Contact Support
                </h3>
                <button
                  onClick={() => setShowBannedAppealModal(false)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <PlayerSupportView />
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div id="app-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-orange-500 selection:text-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-15 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo & Brand */}
          <div 
            onClick={() => setActiveTab('tournaments')}
            className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group shrink-0"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-orange-600 via-amber-600 to-red-600 p-0.5 shadow-lg shadow-orange-600/30">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Flame className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500 group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs sm:text-sm font-black tracking-wider text-white uppercase">
                  FREE FIRE MAX
                </span>
                <span className="px-1.5 py-0.2 rounded bg-orange-600/20 text-orange-400 text-[9px] sm:text-[10px] font-black border border-orange-500/30">
                  ESPORTS
                </span>
              </div>
              <span className="text-[9px] sm:text-[10px] text-slate-400 block tracking-tight">
                Live Tournaments & Brackets
              </span>
            </div>
          </div>

          {/* Desktop Nav Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1 rounded-2xl border border-slate-800/80">
            <button
              id="tab-nav-tournaments"
              onClick={() => setActiveTab('tournaments')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'tournaments'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              Tournaments
            </button>

            <button
              id="tab-nav-mymatch"
              onClick={() => setActiveTab('mymatch')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'mymatch'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              My Match
            </button>

            <button
              id="tab-nav-history"
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              History & Refunds
            </button>

            <button
              id="tab-nav-results"
              onClick={() => setActiveTab('results')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'results'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Medal className="w-3.5 h-3.5" />
              Leaderboards
            </button>

            <button
              id="tab-nav-recordings"
              onClick={() => setActiveTab('recordings')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'recordings'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              POV Submissions
            </button>

            <button
              id="tab-nav-support"
              onClick={() => setActiveTab('support')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'support'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Headphones className="w-3.5 h-3.5" />
              Support Team
            </button>

            <button
              id="tab-nav-profile"
              onClick={() => setActiveTab('profile')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              Profile
            </button>
          </nav>

          {/* Right Action Desk (Auth & Admin - Responsive for Desktop & Mobile) */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {isAdmin && (
              <button
                id="btn-switch-to-admin"
                onClick={() => navigateTo('ADMIN', '/admin')}
                className="px-2.5 sm:px-3.5 py-1.5 sm:py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1 shadow-md shadow-red-600/30 transition-all cursor-pointer min-h-[36px]"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Admin Panel</span>
                <span className="sm:hidden">Admin</span>
              </button>
            )}

            {!currentUser ? (
              <div className="flex items-center gap-1.5">
                <button
                  id="btn-player-login-header"
                  onClick={() => setIsPlayerSignInOpen(true)}
                  className="px-3 sm:px-4 py-1.5 sm:py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-[11px] sm:text-xs uppercase tracking-wider shadow-md shadow-orange-600/20 transition-all flex items-center gap-1 cursor-pointer min-h-[36px]"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-950/80 pl-2 sm:pl-3 pr-1 py-1 rounded-2xl border border-slate-800">
                <div 
                  onClick={() => setActiveTab('profile')}
                  className="text-right cursor-pointer"
                >
                  <span className="text-[11px] sm:text-xs font-bold text-white block leading-tight truncate max-w-[90px] sm:max-w-[120px]">
                    {userProfile?.displayName || 'Player'}
                  </span>
                  <span className="text-[9px] sm:text-[10px] text-amber-400 font-mono block truncate max-w-[90px]">
                    {userProfile?.ign ? `IGN: ${userProfile.ign}` : userProfile?.role}
                  </span>
                </div>
                <button
                  id="btn-signout"
                  onClick={() => signOut()}
                  title="Sign Out"
                  className="p-1.5 sm:p-2 text-slate-400 hover:text-red-400 hover:bg-red-950/40 rounded-xl transition-colors cursor-pointer min-w-[32px] min-h-[32px] flex items-center justify-center"
                >
                  <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Page Body with Mobile Bottom Bar Clearance */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3.5 sm:px-6 lg:px-8 py-4 sm:py-8 pb-24 md:pb-8">
        {activeTab === 'tournaments' && (
          <PlayerTournamentsView
            onNavigateToMyMatch={() => setActiveTab('mymatch')}
            onOpenPlayerAuth={() => setIsPlayerSignInOpen(true)}
            onOpenAdminAuth={() => navigateTo('ADMIN', '/admin')}
          />
        )}

        {activeTab === 'mymatch' && (
          <MyMatchView
            onNavigateToTournaments={() => setActiveTab('tournaments')}
            onOpenPlayerAuth={() => setIsPlayerSignInOpen(true)}
            onNavigateToHistory={() => setActiveTab('history')}
          />
        )}

        {activeTab === 'history' && (
          <PlayerHistoryView
            onNavigateToTournaments={() => setActiveTab('tournaments')}
            onNavigateToSupport={() => setActiveTab('support')}
            onOpenPlayerAuth={() => setIsPlayerSignInOpen(true)}
          />
        )}

        {activeTab === 'results' && <PlayerResultsView />}

        {activeTab === 'recordings' && <PlayerRecordingsView />}

        {activeTab === 'support' && <PlayerSupportView />}

        {activeTab === 'profile' && (
          <PlayerProfileView 
            onOpenPlayerAuth={() => setIsPlayerSignInOpen(true)} 
            onOpenSupport={() => setActiveTab('support')}
          />
        )}
      </main>

      {/* Mobile Ergonomic Bottom Sticky Navigation Bar */}
      <nav 
        id="mobile-bottom-nav" 
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 shadow-2xl px-1.5 pt-2 pb-[max(env(safe-area-inset-bottom),0.6rem)]"
      >
        <div className="grid grid-cols-7 gap-0.5 max-w-lg mx-auto">
          <button
            id="mobile-tab-tournaments"
            onClick={() => setActiveTab('tournaments')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] ${
              activeTab === 'tournaments'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className={`w-4 h-4 mb-0.5 ${activeTab === 'tournaments' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">Tourneys</span>
          </button>

          <button
            id="mobile-tab-mymatch"
            onClick={() => setActiveTab('mymatch')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] relative ${
              activeTab === 'mymatch'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gamepad2 className={`w-4 h-4 mb-0.5 ${activeTab === 'mymatch' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">Match</span>
          </button>

          <button
            id="mobile-tab-history"
            onClick={() => setActiveTab('history')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] relative ${
              activeTab === 'history'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className={`w-4 h-4 mb-0.5 ${activeTab === 'history' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">History</span>
          </button>

          <button
            id="mobile-tab-results"
            onClick={() => setActiveTab('results')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] ${
              activeTab === 'results'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Medal className={`w-4 h-4 mb-0.5 ${activeTab === 'results' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">Results</span>
          </button>

          <button
            id="mobile-tab-recordings"
            onClick={() => setActiveTab('recordings')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] ${
              activeTab === 'recordings'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Video className={`w-4 h-4 mb-0.5 ${activeTab === 'recordings' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">POVs</span>
          </button>

          <button
            id="mobile-tab-support"
            onClick={() => setActiveTab('support')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] ${
              activeTab === 'support'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Headphones className={`w-4 h-4 mb-0.5 ${activeTab === 'support' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">Support</span>
          </button>

          <button
            id="mobile-tab-profile"
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer min-h-[46px] ${
              activeTab === 'profile'
                ? 'text-orange-500 font-bold bg-orange-600/10'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className={`w-4 h-4 mb-0.5 ${activeTab === 'profile' ? 'text-orange-500 scale-110 transition-transform' : ''}`} />
            <span className="text-[8.5px] tracking-tight truncate w-full text-center">Profile</span>
          </button>
        </div>
      </nav>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-slate-900/60 py-6 text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-500" />
            <span className="font-bold text-slate-300">Free Fire MAX Esports Tournament Platform</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Cloud Firestore Realtime Sync</span>
            <span>•</span>
            <span>Atomic Brackets</span>
            <span>•</span>
            <button
              onClick={() => setActiveTab('support')}
              className="text-slate-400 hover:text-orange-400 transition-colors underline cursor-pointer"
            >
              24/7 Support Desk
            </button>
            <span>•</span>
            <button
              id="footer-admin-link"
              onClick={() => navigateTo('ADMIN', '/admin')}
              className="text-slate-400 hover:text-orange-400 transition-colors underline cursor-pointer"
            >
              Admin Gateway (/admin)
            </button>
          </div>
        </div>
      </footer>

      {/* Player Authentication Modal */}
      <PlayerSignInModal
        isOpen={isPlayerSignInOpen}
        onClose={() => setIsPlayerSignInOpen(false)}
        onSuccess={() => {
          setIsPlayerSignInOpen(false);
        }}
      />
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}

export default App;
