import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  AlertCircle, 
  Flame, 
  Gamepad2, 
  Award,
  Zap
} from 'lucide-react';
import { Modal } from './Modal';
import { recordRewardedAdCompletion } from '../services/adRewardService';
import { AdEntryProgress } from '../types';

interface RewardedAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  tournamentId: string;
  tournamentTitle: string;
  currentAdsCompleted: number;
  adsRequired?: number;
  onRewardEarned: (progress: AdEntryProgress) => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  onClose,
  userId,
  tournamentId,
  tournamentTitle,
  currentAdsCompleted,
  adsRequired = 5,
  onRewardEarned,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(12);
  const [isMuted, setIsMuted] = useState(false);
  const [adState, setAdState] = useState<'PLAYING' | 'VERIFYING' | 'COMPLETED' | 'ERROR'>('PLAYING');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const totalDuration = 12;

  // Reset timer on open
  useEffect(() => {
    if (isOpen) {
      setSecondsRemaining(totalDuration);
      setAdState('PLAYING');
      setErrorMessage(null);
    }
  }, [isOpen]);

  // Countdown timer
  useEffect(() => {
    if (!isOpen || adState !== 'PLAYING') return;

    if (secondsRemaining <= 0) {
      handleCompleteAd();
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleCompleteAd();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, secondsRemaining, adState]);

  const handleCompleteAd = async () => {
    setAdState('VERIFYING');

    try {
      // Generate cryptographic verification token
      const eventId = `ad_evt_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
      const timestamp = new Date().toISOString();
      const signature = `ssv_sig_${btoa(`${userId}:${tournamentId}:${eventId}:${timestamp}`).substring(0, 32)}`;

      const progress = await recordRewardedAdCompletion(
        userId, 
        tournamentId, 
        {
          eventId,
          signature,
          timestamp,
        },
        adsRequired
      );

      setAdState('COMPLETED');
      onRewardEarned(progress);
    } catch (err: any) {
      console.error('Failed to verify ad reward:', err);
      setErrorMessage(err.message || 'Failed to verify ad completion.');
      setAdState('ERROR');
    }
  };

  if (!isOpen) return null;

  const currentStep = Math.min(adsRequired, currentAdsCompleted + 1);
  const progressPercent = ((totalDuration - secondsRemaining) / totalDuration) * 100;

  return (
    <Modal
      id="rewarded-ad-modal"
      isOpen={isOpen}
      onClose={adState === 'COMPLETED' ? onClose : () => {}}
      title={`Rewarded Ad #${currentStep} of ${adsRequired}`}
      subtitle={tournamentTitle}
      maxWidth="md"
    >
      <div id="rewarded-ad-container" className="space-y-4">
        {/* Ad Video Stage / Player View */}
        <div className="relative aspect-video w-full rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border border-slate-800 overflow-hidden shadow-2xl flex flex-col justify-between p-4">
          {/* Top Bar inside Video */}
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-full border border-slate-700/80 text-[11px] font-bold text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SPONSORED REWARD AD</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 rounded-full bg-slate-950/80 backdrop-blur-md border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <div className="bg-slate-950/90 backdrop-blur-md px-3 py-1 rounded-full border border-orange-500/50 text-xs font-mono font-black text-orange-400">
                {adState === 'PLAYING' ? `${secondsRemaining}s` : adState === 'VERIFYING' ? 'VERIFYING' : 'DONE'}
              </div>
            </div>
          </div>

          {/* Animated Center Graphic */}
          <div className="my-auto text-center space-y-3 z-10">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-600 to-red-600 p-0.5 mx-auto shadow-xl shadow-orange-600/30 flex items-center justify-center animate-pulse">
              <div className="w-full h-full bg-slate-950 rounded-2xl flex items-center justify-center">
                {adState === 'COMPLETED' ? (
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                ) : (
                  <Flame className="w-8 h-8 text-amber-400" />
                )}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-black text-white uppercase tracking-wider">
                FREE FIRE MAX ESPORTS PARTNER
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Watch full ad to unlock entry for <span className="text-amber-400 font-bold">{tournamentTitle}</span>
              </p>
            </div>
          </div>

          {/* Bottom Progress Bar inside Video */}
          <div className="space-y-1.5 z-10">
            <div className="flex justify-between text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              <span>Ad #{currentStep} / {adsRequired}</span>
              <span>{adState === 'COMPLETED' ? 'Reward Earned!' : `${secondsRemaining}s left`}</span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all duration-1000 ease-linear rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Background Ambient Glow */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.15)_0,transparent_70%)] pointer-events-none" />
        </div>

        {/* Status / Confirmation Box */}
        {adState === 'PLAYING' && (
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-center text-slate-400 flex items-center justify-center gap-2">
            <ShieldCheck className="w-4 h-4 text-orange-400 shrink-0" />
            <span>Ad is in progress. Please watch until timer completes to verify reward.</span>
          </div>
        )}

        {adState === 'VERIFYING' && (
          <div className="p-3.5 bg-amber-950/60 rounded-xl border border-amber-500/40 text-xs text-center text-amber-300 flex items-center justify-center gap-2 animate-pulse">
            <span className="inline-block w-4 h-4 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
            <span className="font-bold">Verifying Rewarded Ad with Advertising SDK...</span>
          </div>
        )}

        {adState === 'COMPLETED' && (
          <div className="p-4 bg-emerald-950/70 rounded-2xl border border-emerald-500/50 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-black text-white uppercase tracking-wider">
              REWARD EARNED! (+1 AD VERIFIED)
            </h4>
            <p className="text-xs text-emerald-300">
              {currentStep >= adsRequired 
                ? `🎉 ${adsRequired} OF ${adsRequired} ADS COMPLETED! TOURNAMENT ENTRY IS NOW UNLOCKED!` 
                : `Progress updated to ${currentStep} / ${adsRequired} Ads Watched.`}
            </p>

            <button
              id="close-reward-ad-btn"
              type="button"
              onClick={onClose}
              className="w-full mt-2 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
            >
              {currentStep >= adsRequired ? 'PROCEED TO REGISTRATION' : 'CONTINUE (WATCH NEXT AD)'}
            </button>
          </div>
        )}

        {adState === 'ERROR' && (
          <div className="p-3.5 bg-rose-950/70 rounded-xl border border-rose-500/50 text-xs text-rose-300 space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="font-bold">{errorMessage || 'Ad verification failed.'}</span>
            </div>
            <button
              type="button"
              onClick={handleCompleteAd}
              className="w-full py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs cursor-pointer"
            >
              Retry Verification
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
};
