import React, { useState } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  X, 
  UserX, 
  CheckCircle2, 
  Flame, 
  Lock,
  Gamepad2
} from 'lucide-react';
import { UserProfile } from '../types';

interface BanPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: UserProfile | null;
  onConfirmBan: (uid: string, reason: string) => Promise<void>;
}

const BAN_REASON_PRESETS = [
  'Fair-play rule violation / Using forbidden 3rd-party config tools',
  'Aimbot, wallhack, or memory injection detected in match POV',
  'Using unauthorized PC emulator in mobile-only lobby',
  'Fake payment UTR / transaction fraud or chargeback abuse',
  'Teaming and match collusion with enemy squad',
  'Toxic behavior, harassment or identity impersonation',
  'Match room credential sharing with unregistered players',
  'Other / Custom Administrative Sanction'
];

export const BanPlayerModal: React.FC<BanPlayerModalProps> = ({
  isOpen,
  onClose,
  player,
  onConfirmBan,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<string>(BAN_REASON_PRESETS[0]);
  const [customReason, setCustomReason] = useState<string>('');
  const [confirmedCheck, setConfirmedCheck] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !player) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmedCheck) {
      setError('Please acknowledge the ban confirmation checkbox.');
      return;
    }

    const finalReason = selectedPreset.startsWith('Other')
      ? (customReason.trim() || 'Administrative sanction for tournament rule violations.')
      : (customReason.trim() ? `${selectedPreset}: ${customReason.trim()}` : selectedPreset);

    try {
      setSubmitting(true);
      setError(null);
      await onConfirmBan(player.uid, finalReason);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to ban player. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div 
        id="ban-player-modal"
        className="relative w-full max-w-lg bg-slate-900 border border-red-500/50 rounded-2xl sm:rounded-3xl p-5 sm:p-7 shadow-2xl space-y-5 animate-in fade-in zoom-in duration-200"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={submitting}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-3.5">
          <div className="p-3 rounded-2xl bg-red-950/80 border border-red-500/50 text-red-400 shrink-0">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-500/30">
              Admin Enforcement
            </span>
            <h3 className="text-lg sm:text-xl font-extrabold text-white mt-1">
              Ban Competitive Player
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Enforce immediate tournament lock and freeze account access.
            </p>
          </div>
        </div>

        {/* Player Snapshot Card */}
        <div className="p-3.5 sm:p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">
            Target Player Information
          </div>
          <div className="grid grid-cols-2 gap-2 font-mono">
            <div>
              <span className="text-slate-500 block text-[10px]">PLAYER NAME</span>
              <span className="text-white font-bold truncate block">{player.displayName || 'Player'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">FREE FIRE UID</span>
              <span className="text-cyan-400 font-bold truncate block">{player.freeFireUid || 'Not Linked'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">IGN (IN-GAME)</span>
              <span className="text-amber-400 font-bold truncate block">{player.ign || player.displayName || '-'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">REGISTERED EMAIL</span>
              <span className="text-slate-300 font-sans truncate block">{player.email}</span>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
              Select Ban Violation Reason <span className="text-red-400">*</span>
            </label>
            <select
              id="ban-reason-select"
              value={selectedPreset}
              onChange={(e) => setSelectedPreset(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-red-500 text-xs text-white outline-none cursor-pointer"
            >
              {BAN_REASON_PRESETS.map((preset, idx) => (
                <option key={idx} value={preset}>
                  {preset}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
              Additional Details / Evidence Notes
            </label>
            <textarea
              id="ban-reason-notes"
              rows={3}
              value={customReason}
              onChange={(e) => setCustomReason(e.target.value)}
              placeholder="Enter specific match ID, timestamp, POV link, or explanation..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-red-500 text-xs text-white placeholder:text-slate-500 outline-none resize-none"
            />
          </div>

          {/* Explicit Confirmation Checkbox */}
          <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/30">
            <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
              <input
                id="confirm-ban-checkbox"
                type="checkbox"
                checked={confirmedCheck}
                onChange={(e) => setConfirmedCheck(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded bg-slate-950 border-slate-700 text-red-600 focus:ring-red-500 cursor-pointer"
              />
              <span className="leading-snug text-slate-300">
                I confirm that this player violates competitive tournament guidelines. Their account will be <strong className="text-red-400">immediately locked</strong> with a full-screen restriction until unbanned.
              </span>
            </label>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-950/80 border border-red-500 text-red-300 text-xs font-bold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              id="confirm-ban-submit-btn"
              type="submit"
              disabled={submitting || !confirmedCheck}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 disabled:opacity-50 text-white text-xs font-extrabold uppercase tracking-wider shadow-lg shadow-red-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              {submitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Locking Account...
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  Ban Player & Lock Account
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
