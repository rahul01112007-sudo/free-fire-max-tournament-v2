import React from 'react';
import { Gem, Check, Sparkles } from 'lucide-react';
import { DiamondPackage, FREE_FIRE_DIAMOND_PACKAGES } from '../types';

interface DiamondPackageSelectorProps {
  id?: string;
  selectedPackageId?: string;
  selectedDiamonds?: number;
  onSelect: (pkg: DiamondPackage) => void;
  disabled?: boolean;
}

export const DiamondPackageSelector: React.FC<DiamondPackageSelectorProps> = ({
  id = 'diamond-package-selector',
  selectedPackageId,
  selectedDiamonds,
  onSelect,
  disabled = false,
}) => {
  return (
    <div id={id} className="w-full space-y-2.5">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
          <Gem className="w-3.5 h-3.5 text-cyan-400" />
          Select Official Free Fire Diamond Package
        </span>
        <span className="text-[10px] text-slate-400 font-mono">
          {FREE_FIRE_DIAMOND_PACKAGES.length} Packages Available
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-2.5 max-h-[320px] overflow-y-auto p-1 rounded-xl bg-slate-950/70 border border-slate-800/80">
        {FREE_FIRE_DIAMOND_PACKAGES.map((pkg) => {
          const isSelected =
            selectedPackageId === pkg.id ||
            (!selectedPackageId && selectedDiamonds === pkg.diamonds);

          return (
            <button
              key={pkg.id}
              type="button"
              id={`diamond-pkg-${pkg.id}`}
              disabled={disabled}
              onClick={() => onSelect(pkg)}
              className={`group relative flex flex-col justify-between p-2.5 sm:p-3 rounded-xl border text-left transition-all cursor-pointer min-h-[76px] select-none ${
                isSelected
                  ? 'bg-cyan-950/80 border-cyan-400 text-white shadow-md shadow-cyan-950/50 ring-1 ring-cyan-400'
                  : 'bg-slate-900/90 hover:bg-slate-800/80 border-slate-800 hover:border-slate-700 text-slate-300'
              } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {/* Badge */}
              {pkg.badge && (
                <span className="absolute -top-2 -right-1 px-1.5 py-0.2 rounded-full text-[8px] font-black uppercase tracking-wider bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 shadow">
                  {pkg.badge}
                </span>
              )}

              {/* Top Row: Diamond Icon & Amount */}
              <div className="flex items-center justify-between gap-1 w-full">
                <div className="flex items-center gap-1.5">
                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950'
                        : 'bg-cyan-950/60 text-cyan-400 border border-cyan-500/30 group-hover:border-cyan-500/60'
                    }`}
                  >
                    <Gem className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs sm:text-sm font-black font-mono tracking-tight text-white">
                    {pkg.diamonds.toLocaleString()}
                  </span>
                </div>

                {isSelected ? (
                  <span className="w-4 h-4 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </span>
                ) : null}
              </div>

              {/* Bottom Row: Label & Action */}
              <div className="mt-2 pt-1 border-t border-slate-800/60 flex items-center justify-between w-full text-[10px]">
                <span className="text-slate-400 truncate max-w-[80px]">
                  Reward: <strong className="text-cyan-300 font-mono">{pkg.diamonds}</strong>
                </span>
                <span
                  className={`font-bold uppercase tracking-wider text-[9px] ${
                    isSelected ? 'text-cyan-300' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                >
                  {isSelected ? 'SELECTED' : 'SELECT'}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
