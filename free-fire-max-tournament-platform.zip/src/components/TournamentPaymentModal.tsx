import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Gem, 
  Copy, 
  Send,
  Clock,
  QrCode
} from 'lucide-react';
import { Modal } from './Modal';
import { Tournament, formatPrizeAmount } from '../types';
import { 
  createPaymentOrder, 
  submitManualTournamentPayment,
  PaymentVerificationResult 
} from '../services/paymentService';

interface TournamentPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament;
  userId: string;
  payerName: string;
  freeFireUid: string;
  onPaymentSuccess: (verification: PaymentVerificationResult) => void;
}

export const TournamentPaymentModal: React.FC<TournamentPaymentModalProps> = ({
  isOpen,
  onClose,
  tournament,
  userId,
  payerName,
  freeFireUid,
  onPaymentSuccess,
}) => {
  const [customUtr, setCustomUtr] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);

  const entryFee = tournament.entryFee || 50;
  const dummyUpiId = 'ignite.esports@upi';

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(dummyUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleProcessPayment = async () => {
    try {
      setLoading(true);
      setError(null);

      if (!customUtr.trim()) {
        throw new Error('Please enter the 12-digit UPI Reference / UTR Number from your payment app.');
      }

      // 1. Create unique order intent
      const order = await createPaymentOrder(tournament.id, userId, entryFee);

      // 2. Submit for manual admin review & verification
      const verification = await submitManualTournamentPayment(
        order.orderId,
        tournament.id,
        userId,
        entryFee,
        customUtr.trim(),
        'UPI'
      );

      if (verification.success) {
        onPaymentSuccess(verification);
        onClose();
      } else {
        throw new Error(verification.error || 'Payment submission failed.');
      }
    } catch (err: any) {
      console.error('Payment processing error:', err);
      setError(err.message || 'Payment processing failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      id="tournament-payment-modal"
      isOpen={isOpen}
      onClose={onClose}
      title="Tournament Entry Fee Payment"
      subtitle={`Secure UPI Payment Desk for ${tournament.title}`}
      maxWidth="md"
    >
      <div className="space-y-4 py-1">
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-rose-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Amount & Non-Cash In-Game Reward Banner */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-slate-950 border border-cyan-500/40 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Entry Fee Payable
            </span>
            <span className="text-xl font-black font-mono text-cyan-400">
              ₹{entryFee.toLocaleString()}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Gem className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-300">Tournament Reward Pool:</span>
            </div>
            <span className="font-extrabold text-cyan-300">
              {formatPrizeAmount(tournament.totalPrizeValue || tournament.prizePool, tournament.prizeType)}
            </span>
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950/60 p-2 rounded-lg border border-slate-800/80 space-y-0.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Non-Cash In-Game Diamonds</span>
            </div>
            <p className="text-[10px] text-slate-400">
              Prizes are credited directly to winner Free Fire UIDs as in-game top-ups.
            </p>
          </div>
        </div>

        {/* Snapshot UID Notice */}
        <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-xs space-y-1">
          <div className="flex justify-between text-slate-400">
            <span>Player IGN:</span>
            <span className="font-bold text-white">{payerName}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Free Fire UID Snapshot:</span>
            <span className="font-mono font-bold text-cyan-400">{freeFireUid}</span>
          </div>
        </div>

        {/* UPI Details & UTR Input */}
        <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-1.5 text-slate-300 font-medium">
              <QrCode className="w-4 h-4 text-cyan-400" />
              <span>Pay to Official UPI ID:</span>
            </div>
            <button
              type="button"
              onClick={handleCopyUpi}
              className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-300 hover:text-cyan-200 bg-cyan-950/80 px-2.5 py-1 rounded-lg border border-cyan-500/40 cursor-pointer font-bold transition-all"
            >
              <Copy className="w-3.5 h-3.5" />
              {copiedUpi ? 'Copied!' : dummyUpiId}
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                Enter 12-Digit UPI Reference / UTR Number: <span className="text-rose-400">*</span>
              </label>
            </div>
            <input
              type="text"
              id="tournament-payment-utr-input"
              value={customUtr}
              onChange={(e) => setCustomUtr(e.target.value)}
              placeholder="e.g. 428910284910 (from Google Pay, PhonePe, Paytm, BHIM)"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-cyan-400 font-mono tracking-wider"
            />
            <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed">
              Step 1: Open Google Pay / PhonePe / Paytm and pay <strong className="text-white">₹{entryFee}</strong> to <span className="text-cyan-300 font-mono">{dummyUpiId}</span>.<br />
              Step 2: Copy the 12-digit UTR/UPI Transaction Reference and paste it above.<br />
              Step 3: Submit for Admin Confirmation. The tournament admin will verify and activate your Tournament Entry Card & Room Credentials.
            </p>
          </div>
        </div>

        <button
          type="button"
          id="pay-and-confirm-tournament-entry-btn"
          disabled={loading || !customUtr.trim()}
          onClick={handleProcessPayment}
          className="w-full py-3.5 bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-cyan-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          {loading ? (
            <span className="inline-block w-4 h-4 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          {loading 
            ? 'Submitting for Admin Confirmation...' 
            : `SUBMIT UTR FOR ADMIN CONFIRMATION (₹${entryFee.toLocaleString()})`}
        </button>
      </div>
    </Modal>
  );
};
