import React from 'react';
import { 
  MatchStatus, 
  PaymentStatus, 
  TournamentFormat, 
  TournamentStatus, 
  ReportStatus, 
  RecordingStatus 
} from '../types';

interface BadgeProps {
  status?: string;
  type?: 'tournament' | 'match' | 'room' | 'payment' | 'format' | 'report' | 'recording';
  className?: string;
}

export const StatusBadge: React.FC<BadgeProps> = ({ status, type = 'match', className = '' }) => {
  if (!status) return null;

  let bg = 'bg-slate-800 text-slate-300 border-slate-700';
  let label = status;

  switch (status) {
    // Tournament Status
    case 'REGISTRATION_OPEN':
      bg = 'bg-emerald-950/80 text-emerald-400 border-emerald-600/50';
      label = 'REGISTRATION OPEN';
      break;
    case 'REGISTRATION_CLOSED':
      bg = 'bg-amber-950/80 text-amber-400 border-amber-600/50';
      label = 'REGISTRATION CLOSED';
      break;
    case 'ONGOING':
      bg = 'bg-cyan-950/80 text-cyan-400 border-cyan-500/50 animate-pulse';
      label = 'LIVE / ONGOING';
      break;
    case 'COMPLETED':
      bg = 'bg-slate-900 text-slate-400 border-slate-700';
      label = 'COMPLETED';
      break;

    // Match Status
    case 'ACTIVE':
      bg = 'bg-orange-950/80 text-orange-400 border-orange-500/60';
      label = 'ACTIVE';
      break;
    case 'WAITING':
      bg = 'bg-blue-950/80 text-blue-400 border-blue-600/50';
      label = 'WAITING';
      break;
    case 'FULL':
      bg = 'bg-rose-950/80 text-rose-400 border-rose-600/50';
      label = 'FULL (48/48)';
      break;
    case 'LOCKED':
      bg = 'bg-purple-950/80 text-purple-400 border-purple-600/50';
      label = 'LOCKED (STAGE 2)';
      break;

    // Room Status
    case 'RELEASED':
      bg = 'bg-emerald-950 text-emerald-300 border-emerald-500 ring-1 ring-emerald-500/40 shadow-sm shadow-emerald-500/20';
      label = 'ROOM RELEASED';
      break;
    case 'ROOM_LOCKED':
      bg = 'bg-slate-900 text-slate-400 border-slate-700';
      label = 'ROOM LOCKED';
      break;

    // Payment Status
    case 'VERIFIED':
      bg = 'bg-emerald-950/80 text-emerald-400 border-emerald-500/50';
      label = 'PAYMENT VERIFIED';
      break;
    case 'PENDING':
      bg = 'bg-amber-950/80 text-amber-300 border-amber-500/50';
      label = 'PAYMENT PENDING';
      break;
    case 'REJECTED':
      bg = 'bg-rose-950/80 text-rose-400 border-rose-600/50';
      label = 'PAYMENT REJECTED';
      break;

    // Format
    case 'SOLO':
      bg = 'bg-amber-950/60 text-amber-400 border-amber-600/40';
      label = 'SOLO (500)';
      break;
    case 'SQUAD':
      bg = 'bg-purple-950/60 text-purple-300 border-purple-600/40';
      label = 'SQUAD (4v4)';
      break;

    // Anti-Cheat
    case 'BANNED':
      bg = 'bg-red-950 text-red-400 border-red-600';
      label = 'PLAYER BANNED';
      break;
    case 'UNDER_REVIEW':
      bg = 'bg-yellow-950 text-yellow-400 border-yellow-600';
      label = 'UNDER REVIEW';
      break;
    case 'DISMISSED':
      bg = 'bg-slate-900 text-slate-400 border-slate-700';
      label = 'DISMISSED';
      break;
      
    // Recording
    case 'APPROVED':
      bg = 'bg-emerald-950 text-emerald-400 border-emerald-600';
      label = 'POV APPROVED';
      break;

    default:
      label = status.replace(/_/g, ' ');
  }

  return (
    <span
      id={`badge-${status.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider border ${bg} ${className}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80" />
      {label}
    </span>
  );
};
