import React from 'react';
import { 
  ShieldAlert, 
  Lock, 
  AlertTriangle, 
  HelpCircle, 
  LogOut, 
  Headphones, 
  Mail, 
  Gamepad2,
  Calendar,
  ShieldX
} from 'lucide-react';
import { UserProfile } from '../types';

interface BannedPlayerScreenProps {
  userProfile: UserProfile | null;
  onSignOut: () => Promise<void>;
  onOpenSupport: () => void;
}

export const BannedPlayerScreen: React.FC<BannedPlayerScreenProps> = ({
  userProfile,
  onSignOut,
  onOpenSupport,
}) => {
  const banReason = userProfile?.banReason || 'Violation of competitive fair play and anti-cheat regulations.';
  const bannedAt = userProfile?.bannedAt 
    ? new Date(userProfile.bannedAt).toLocaleString(undefined, { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric',
        hour: '2-digit', 
        minute: '2-digit' 
      })
    : 'Recent';

  return (
    <div 
      id="fullscreen-banned-screen"
      className="fixed inset-0 z-[9999] bg-slate-950 flex flex-col items-center justify-center p-4 sm:p-6 overflow-y-auto"
    >
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(220,38,38,0.25),rgba(255,255,255,0))]" />
      
      <div className="relative z-10 w-full max-w-xl mx-auto space-y-6 text-center animate-in fade-in zoom-in duration-300">
        {/* Ban Icon with Glow */}
        <div className="relative mx-auto w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-red-600/30 blur-2xl animate-pulse" />
          <div className="relative w-full h-full rounded-3xl bg-gradient-to-br from-red-950 to-slate-900 border-2 border-red-500/80 flex items-center justify-center shadow-2xl shadow-red-900/50">
            <ShieldX className="w-12 h-12 sm:w-14 sm:h-14 text-red-500" />
          </div>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-950/80 border border-red-500/50 text-red-400 text-xs font-black uppercase tracking-widest shadow-lg shadow-red-950/50">
            <Lock className="w-3.5 h-3.5" />
            Competitive Lock Active
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white uppercase">
            Your Account Is Banned
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            Your account has been restricted from entering tournaments, viewing custom room credentials, and accessing competitive leaderboards.
          </p>
        </div>

        {/* Reason Card */}
        <div className="bg-slate-900/90 border border-red-500/40 rounded-2xl sm:rounded-3xl p-5 sm:p-6 text-left space-y-4 shadow-xl">
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-red-400 block mb-1">
              Official Sanction Reason
            </span>
            <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-500/30 text-white font-medium text-xs sm:text-sm leading-relaxed">
              "{banReason}"
            </div>
          </div>

          {/* Player Snapshot */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[10px]">PLAYER</span>
              <span className="text-white font-bold truncate block">
                {userProfile?.displayName || 'Player'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">FREE FIRE UID</span>
              <span className="text-cyan-400 font-bold truncate block">
                {userProfile?.freeFireUid || 'Not Linked'}
              </span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="text-slate-500 block text-[10px]">SANCTION DATE</span>
              <span className="text-slate-300 truncate block text-[11px]">
                {bannedAt}
              </span>
            </div>
          </div>
        </div>

        {/* Help / Unban Notice */}
        <p className="text-xs text-slate-400 leading-relaxed px-4">
          If you believe this penalty was applied in error or have submitted POV recordings for manual review, you can submit an appeal through our 24/7 Support Desk.
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            id="banned-open-support-btn"
            type="button"
            onClick={onOpenSupport}
            className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-orange-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
          >
            <Headphones className="w-4 h-4" />
            Contact 24/7 Support Team
          </button>

          <button
            id="banned-sign-out-btn"
            type="button"
            onClick={() => onSignOut()}
            className="w-full sm:w-auto px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 font-bold rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};
