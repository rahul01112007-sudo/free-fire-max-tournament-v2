import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  Check, 
  Printer, 
  Download, 
  Gamepad2, 
  Calendar, 
  Clock, 
  Users, 
  User, 
  Sparkles, 
  QrCode, 
  Gem, 
  Lock, 
  Unlock,
  KeyRound,
  ExternalLink,
  Share2
} from 'lucide-react';
import { Modal } from './Modal';
import { Registration, RoomCredentials, Tournament, isDiamondPrizeType, formatPrizeAmount } from '../types';
import { listenRoomCredentials } from '../services/roomService';
import { StatusBadge } from './StatusBadge';

interface TournamentEntryCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  registration: Registration | null;
  tournament?: Tournament | null;
  onNavigateToMatch?: () => void;
}

export const TournamentEntryCardModal: React.FC<TournamentEntryCardModalProps> = ({
  isOpen,
  onClose,
  registration,
  tournament,
  onNavigateToMatch,
}) => {
  const [copiedUid, setCopiedUid] = useState(false);
  const [copiedUtr, setCopiedUtr] = useState(false);
  const [copiedRoomId, setCopiedRoomId] = useState(false);
  const [copiedRoomPass, setCopiedRoomPass] = useState(false);
  const [room, setRoom] = useState<RoomCredentials | null>(null);

  useEffect(() => {
    if (!registration) {
      setRoom(null);
      return;
    }

    const unsub = listenRoomCredentials(registration.matchId, (roomData) => {
      setRoom(roomData);
    });

    return () => unsub();
  }, [registration?.matchId]);

  if (!registration) return null;

  const isVerified = registration.paymentStatus === 'VERIFIED' || registration.paymentStatus === 'APPROVED';
  const isPending = registration.paymentStatus === 'PENDING' || registration.paymentStatus === 'PENDING_APPROVAL';
  const isPaid = registration.entryType === 'PAID_IN_GAME' || (registration.entryFeePaid && registration.entryFeePaid > 0);
  const isRoomReleased = isVerified && room?.status === 'RELEASED';

  const handleCopy = (text: string, type: 'uid' | 'utr' | 'roomId' | 'roomPass') => {
    navigator.clipboard.writeText(text);
    if (type === 'uid') {
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 2000);
    } else if (type === 'utr') {
      setCopiedUtr(true);
      setTimeout(() => setCopiedUtr(false), 2000);
    } else if (type === 'roomId') {
      setCopiedRoomId(true);
      setTimeout(() => setCopiedRoomId(false), 2000);
    } else if (type === 'roomPass') {
      setCopiedRoomPass(true);
      setTimeout(() => setCopiedRoomPass(false), 2000);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const voucherCode = `PASS-${(registration.id || 'REG').replace(/[^a-zA-Z0-9]/g, '').slice(-8).toUpperCase()}`;

  return (
    <Modal
      id="tournament-entry-card-modal"
      isOpen={isOpen}
      onClose={onClose}
      title={isVerified ? 'Official Tournament Entry Card' : 'Tournament Registration Card'}
      subtitle={isVerified ? 'Verified & Activated by Tournament Admin' : 'Awaiting Admin Confirmation'}
      maxWidth="lg"
    >
      <div className="space-y-4 py-1">
        {/* Printable/Display Tournament Entry Pass */}
        <div 
          id="official-tournament-pass-card"
          className={`relative rounded-2xl overflow-hidden border transition-all ${
            isVerified 
              ? 'bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-emerald-500/60 shadow-xl shadow-emerald-950/30 ring-1 ring-emerald-500/30' 
              : isPending
              ? 'bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-amber-500/60 shadow-xl shadow-amber-950/20'
              : 'bg-slate-900 border-rose-500/60 shadow-xl shadow-rose-950/20'
          }`}
        >
          {/* Top Banner with Cyber Accent */}
          <div className={`px-4 sm:px-6 py-3.5 border-b flex flex-wrap items-center justify-between gap-2.5 ${
            isVerified
              ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300'
              : isPending
              ? 'bg-amber-950/70 border-amber-500/40 text-amber-300'
              : 'bg-rose-950/70 border-rose-500/40 text-rose-300'
          }`}>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-black ${
                isVerified ? 'bg-emerald-500/20 text-emerald-400' : isPending ? 'bg-amber-500/20 text-amber-400' : 'bg-rose-500/20 text-rose-400'
              }`}>
                {isVerified ? <CheckCircle2 className="w-5 h-5" /> : isPending ? <Clock className="w-5 h-5 animate-pulse" /> : <AlertCircle className="w-5 h-5" />}
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider font-extrabold block">
                  FREE FIRE MAX ESPORTS • OFFICIAL ENTRY PASS
                </span>
                <span className="text-xs font-mono font-bold tracking-widest text-white">
                  {voucherCode}
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border inline-flex items-center gap-1.5 ${
                isVerified
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 ring-1 ring-emerald-500/40'
                  : isPending
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 animate-pulse'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/50'
              }`}>
                {isVerified ? <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> : <Clock className="w-3.5 h-3.5 text-amber-400" />}
                {isVerified ? 'REGISTRATION CONFIRMED' : isPending ? 'PAYMENT UNDER REVIEW' : 'REJECTED'}
              </span>
            </div>
          </div>

          {/* Body Information */}
          <div className="p-4 sm:p-6 space-y-4">
            {/* Tournament Title & Format Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-orange-600/20 border border-orange-500/40 text-orange-400 text-[10px] font-bold uppercase tracking-wider">
                    {registration.format} BRACKET
                  </span>
                  {isPaid ? (
                    <span className="px-2 py-0.5 rounded bg-cyan-600/20 border border-cyan-500/40 text-cyan-300 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                      <Gem className="w-3 h-3 text-cyan-400" />
                      PAID ENTRY (₹{registration.entryFeePaid || 50})
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
                      FREE ADS ENTRY
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-black text-white leading-snug">
                  {registration.tournamentTitle}
                </h3>
              </div>

              {/* Match & Slot Box */}
              <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl text-center sm:text-right shrink-0">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 font-semibold block">
                  ASSIGNED QUALIFIER
                </span>
                <span className="text-xs font-black text-orange-400 block">
                  {registration.matchName}
                </span>
                <span className="text-sm font-black font-mono text-emerald-400 block">
                  {registration.format === 'SOLO' ? `SEAT #${registration.seatNumber}` : `TEAM SLOT #${registration.seatNumber}`}
                </span>
              </div>
            </div>

            {/* Player & Registration Matrix */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-slate-950/80 rounded-xl border border-slate-800/90 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold block">
                  {registration.format === 'SOLO' ? 'PLAYER IGN' : 'SQUAD & CAPTAIN'}
                </span>
                <span className="font-bold text-white text-sm block truncate mt-0.5">
                  {registration.format === 'SOLO' ? registration.ign : `${registration.teamName} (${registration.ign})`}
                </span>
                <span className="text-[11px] text-slate-400 block truncate">
                  {registration.playerName}
                </span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold block">
                  FREE FIRE UID (VERIFIED)
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-mono font-bold text-cyan-300 text-sm">
                    {registration.freeFireUid}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(registration.freeFireUid, 'uid')}
                    className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                    title="Copy UID"
                  >
                    {copiedUid ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
                <span className="text-[10px] text-slate-500 block">Rewards locked to this UID</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold block">
                  TRANSACTION / UTR ID
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-mono font-bold text-amber-300 text-xs truncate max-w-[130px]">
                    {registration.utrNumber || registration.paymentTransactionId || 'FREE_ENTRY'}
                  </span>
                  {registration.utrNumber && (
                    <button
                      type="button"
                      onClick={() => handleCopy(registration.utrNumber || '', 'utr')}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      title="Copy UTR"
                    >
                      {copiedUtr ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 block">{registration.paymentMethod || 'UPI'} • {registration.createdAt.slice(0, 10)}</span>
              </div>
            </div>

            {/* Squad Members Roster if SQUAD */}
            {registration.format === 'SQUAD' && registration.members && (
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 space-y-1.5">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1">
                  <Users className="w-3 h-3" /> Registered Squad Roster (4 Players)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-300">
                  {registration.members.map((m, idx) => (
                    <div key={idx} className="bg-slate-900/90 px-2.5 py-1.5 rounded-lg border border-slate-800">
                      <span className="font-semibold text-white truncate block">
                        {idx === 0 ? '👑 ' : ''}{m.ign}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono block truncate">
                        UID: {m.freeFireUid}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Admin Verification & Confirmation Stamp */}
            {isVerified ? (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-extrabold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>VERIFIED BY ADMIN DESK</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Confirmed by: <strong className="text-white">{registration.verifiedBy || 'Tournament Admin'}</strong>
                    {registration.verifiedAt && ` • ${new Date(registration.verifiedAt).toLocaleDateString()} ${new Date(registration.verifiedAt).toLocaleTimeString()}`}
                  </p>
                  {registration.paymentNotes && (
                    <p className="text-[10px] text-emerald-300/90 italic">
                      "{registration.paymentNotes}"
                    </p>
                  )}
                </div>

                <div className="shrink-0 text-center sm:text-right">
                  <span className="px-3 py-1 rounded-lg bg-emerald-600/30 border border-emerald-500/60 text-emerald-300 font-mono font-bold text-[11px]">
                    STATUS: ACTIVE / SEAT LOCKED
                  </span>
                </div>
              </div>
            ) : isPending ? (
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 space-y-1.5 text-xs text-amber-200">
                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                  <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span>Manual Payment Verification in Progress</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Your registration is recorded and your seat (<strong className="text-white">Seat #{registration.seatNumber}</strong>) is held. The tournament moderator will verify your transaction reference (<strong className="text-cyan-300 font-mono">{registration.utrNumber || registration.paymentTransactionId}</strong>) shortly.
                </p>
              </div>
            ) : null}

            {/* Custom Room Credentials Preview */}
            <div className={`p-3.5 rounded-xl border ${
              isRoomReleased ? 'bg-emerald-950/50 border-emerald-500/60' : 'bg-slate-950 border-slate-800'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white uppercase tracking-wider">
                  {isRoomReleased ? <Unlock className="w-3.5 h-3.5 text-emerald-400" /> : <Lock className="w-3.5 h-3.5 text-slate-400" />}
                  <span>Custom Room Credentials</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  isRoomReleased ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 animate-pulse' : !isVerified ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-slate-900 text-slate-400 border-slate-800'
                }`}>
                  {isRoomReleased ? 'LIVE UNLOCKED' : !isVerified ? 'LOCKED (PAYMENT PENDING)' : 'LOCKED UNTIL MATCH START'}
                </span>
              </div>

              {isRoomReleased && room ? (
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">ROOM ID</span>
                      <span className="font-bold text-white text-sm">{room.roomId}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(room.roomId, 'roomId')}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
                    >
                      {copiedRoomId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>

                  <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-[9px] text-slate-400 uppercase tracking-wider block">PASSWORD</span>
                      <span className="font-bold text-amber-400 text-sm">{room.roomPassword}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(room.roomPassword, 'roomPass')}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
                    >
                      {copiedRoomPass ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-slate-400">
                  {!isVerified 
                    ? 'Room ID & Password are locked until the Tournament Admin confirms your payment.' 
                    : 'Custom room credentials will broadcast here 10-15 minutes prior to match launch.'}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Print Entry Pass</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold border border-slate-800 transition-all cursor-pointer"
            >
              Close
            </button>
            {onNavigateToMatch && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToMatch();
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs font-extrabold shadow-md shadow-orange-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>Go to Match Desk</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
