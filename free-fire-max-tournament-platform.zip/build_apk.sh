#!/bin/bash
set -e

echo "=== 1. Setting up JDK 21 and essential build tools ==="
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq openjdk-21-jdk-headless unzip wget curl

export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
java -version

echo "=== 2. Setting up Android SDK ==="
export ANDROID_HOME=/opt/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    cd /tmp
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdline-tools.zip
    unzip -q cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
    mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
    rm -f cmdline-tools.zip
fi

export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH

echo "Accepting Android SDK licenses..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "Installing Android SDK platforms and build tools..."
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools" >/dev/null 2>&1

echo "=== 3. Installing Capacitor & Building Web Assets ==="
cd /app/applet
npm install --save @capacitor/core @capacitor/cli @capacitor/android

cat << 'EOF' > capacitor.config.json
{
  "appId": "com.freefire.tournament",
  "appName": "Free Fire MAX Tournament Platform",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  }
}
EOF

npm run build

echo "=== 4. Adding/Syncing Android Platform ==="
rm -rf android
npx cap add android
npx cap sync android

echo "sdk.dir=/opt/android-sdk" > android/local.properties

echo "=== 5. Compiling Android APK with Gradle assembleDebug ==="
cd android
./gradlew assembleDebug --no-daemon

APK_PATH="/app/applet/android/app/build/outputs/apk/debug/app-debug.apk"

if [ ! -f "$APK_PATH" ]; then
    echo "ERROR: APK not generated at $APK_PATH"
    find /app/applet/android/app/build/outputs -name "*.apk"
    exit 1
fi

echo "=== 6. Copying APK to required output destinations ==="
cd /app/applet
mkdir -p .build-outputs
mkdir -p APK_DOWNLOAD

cp "$APK_PATH" .build-outputs/app-debug.apk
cp "$APK_PATH" APK_DOWNLOAD/app-debug.apk

echo "=== 7. Verifying APK Outputs ==="
ls -lh .build-outputs/app-debug.apk
ls -lh APK_DOWNLOAD/app-debug.apk

echo "Inspecting APK contents..."
unzip -l APK_DOWNLOAD/app-debug.apk | head -n 35

echo "APK Build Complete Successfully!"
