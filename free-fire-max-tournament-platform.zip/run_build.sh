#!/bin/bash
set -e

export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

export ANDROID_HOME=/opt/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo "Downloading Android Command Line Tools..."
    cd /tmp
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdline-tools.zip
    unzip -q cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
    mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
    rm -f cmdline-tools.zip
fi

export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH

echo "Accepting licenses..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "Installing Android SDK platforms and build tools..."
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools" >/dev/null 2>&1

cd /app/applet

cat << 'EOF' > capacitor.config.json
{
  "appId": "com.freefire.tournament",
  "appName": "Free Fire MAX Tournament Platform",
  "webDir": "dist",
  "server": {
    "androidScheme": "https"
  }
}
EOF

echo "Building Vite web bundle..."
npm run build

echo "Syncing Capacitor Android project..."
rm -rf android
./node_modules/.bin/cap add android
./node_modules/.bin/cap sync android

echo "sdk.dir=/opt/android-sdk" > android/local.properties

echo "Compiling Android APK with Gradle assembleDebug..."
cd android
./gradlew assembleDebug --no-daemon

APK_PATH="/app/applet/android/app/build/outputs/apk/debug/app-debug.apk"

if [ ! -f "$APK_PATH" ]; then
    echo "ERROR: APK not found at $APK_PATH"
    find /app/applet/android -name "*.apk"
    exit 1
fi

echo "Copying APK to required output destinations..."
cd /app/applet
mkdir -p .build-outputs
mkdir -p APK_DOWNLOAD

cp "$APK_PATH" .build-outputs/app-debug.apk
cp "$APK_PATH" APK_DOWNLOAD/app-debug.apk

echo "=== Verification ==="
ls -lh .build-outputs/app-debug.apk
ls -lh APK_DOWNLOAD/app-debug.apk

echo "APK Size check:"
SIZE=$(stat -c%s "APK_DOWNLOAD/app-debug.apk")
echo "Size in bytes: $SIZE"

if [ "$SIZE" -lt 1048576 ]; then
    echo "ERROR: APK is smaller than 1MB!"
    exit 1
fi

echo "APK file list (sample):"
unzip -l APK_DOWNLOAD/app-debug.apk | head -n 30

echo "ALL STEPS COMPLETED SUCCESSFULLY!"
